<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();

            $table->bigInteger('user_id')->unsigned();
            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->string('fileToUpload_v_insurance')->nullable();
            $table->date('end_date_insurance')->nullable();
            $table->string('vehicle_type')->nullable();
            $table->string('v_model')->nullable();
            $table->string('v_number')->nullable();
            $table->string('v_out__front_images')->nullable();
            $table->string('v_out_back_images')->nullable();
            $table->string('v_out_right_images')->nullable();
            $table->string('v_out_left_images')->nullable();
            $table->string('v_in_front_images')->nullable();
            $table->string('v_in_back_images')->nullable();
            $table->string('v_book')->nullable();
            $table->string('vehicle_rent_own')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};

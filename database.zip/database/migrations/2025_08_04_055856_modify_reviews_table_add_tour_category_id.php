<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ModifyReviewsTableAddTourCategoryId extends Migration
{
    public function up()
    {
        Schema::table('reviews', function (Blueprint $table) {
            // Add tour_category_id as a foreign key
            $table->unsignedBigInteger('tour_category_id')->nullable()->after('rating');
            $table->foreign('tour_category_id')->references('id')->on('tour_category')->onDelete('set null');
            
            // Make tour_photos nullable
            $table->string('tour_photos')->nullable()->change();
        });
    }

    public function down()
    {
        Schema::table('reviews', function (Blueprint $table) {
            // Drop foreign key and column
            $table->dropForeign(['tour_category_id']);
            $table->dropColumn('tour_category_id');
            
            // Revert tour_photos to non-nullable (adjust based on original schema)
            $table->string('tour_photos')->nullable(false)->change();
        });
    }
}
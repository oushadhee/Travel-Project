<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Review extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [
        'user_id',
        'comment_jot',
        'suggestions_jot',
        'selected_guide',
        'comment_guide',
        'suggestions_guide',
        'rating',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
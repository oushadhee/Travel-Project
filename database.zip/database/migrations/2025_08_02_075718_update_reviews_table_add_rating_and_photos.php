
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->unsigned();
            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');
            $table->text('comment_jot')->nullable();
            $table->text('suggestions_jot')->nullable();
            $table->string('selected_guide')->nullable();
            $table->text('comment_guide')->nullable();
            $table->text('suggestions_guide')->nullable();
            $table->integer('rating')->nullable()->between(1, 5);
            $table->json('tour_photos')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reviews');
    }
};

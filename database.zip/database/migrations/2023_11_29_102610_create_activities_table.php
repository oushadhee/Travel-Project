<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('activities', function (Blueprint $table) {
            $table->id();

            $table->string('place_name');

            $table->bigInteger('main_category_id')->unsigned();
            $table->foreign('main_category_id')
                ->references('id')->on('activity_categories')
                ->onDelete('cascade')
                ->onUpdate('cascade');

//            $table->integer('main_category_id');

            $table->bigInteger('sub_category_id')->unsigned();
            $table->foreign('sub_category_id')
                ->references('id')->on('activity_categories')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->string('description');
            $table->string('map_link');
            $table->string('activity_image');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('activities');
    }
};

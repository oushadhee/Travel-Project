<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tours', function (Blueprint $table) {
            $table->id();

            $table->string('tour_name');

            $table->bigInteger('main_category_id')->unsigned();
            $table->foreign('main_category_id')
                ->references('id')->on('tour_categories')
                ->onDelete('cascade')
                ->onUpdate('cascade');

//            $table->integer('main_category_id');

            $table->bigInteger('sub_category_id')->unsigned();
            $table->foreign('sub_category_id')
                ->references('id')->on('tour_categories')
                ->onDelete('cascade')
                ->onUpdate('cascade');

//            $table->integer('sub_category_id');

            $table->string('description');
            $table->string('tour_image');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tours');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateReviewsTable extends Migration
{
    public function up()
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id(); // Auto-increment primary key
            $table->string('tour_type')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->string('country')->nullable();
            $table->integer('rating')->nullable();
            $table->json('tour_photos')->nullable(); // JSON for storing photo data
            $table->text('comment_jot')->nullable();
            $table->text('suggestions_jot')->nullable();
            $table->text('comment_guide')->nullable();
            $table->text('suggestions_guide')->nullable();
            $table->timestamps(); // created_at & updated_at
        });
    }

    public function down()
    {
        Schema::dropIfExists('reviews');
    }
}

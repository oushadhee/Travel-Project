<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ModifyReviewsTableTourPhotosNullable extends Migration
{
    public function up()
    {
        Schema::table('reviews', function (Blueprint $table) {
            $table->string('tour_photos')->nullable()->change();
            $table->unsignedBigInteger('tour_category_id')->nullable()->after('rating');
            $table->foreign('tour_category_id')->references('id')->on('tour_category')->onDelete('set null');
        });
    }

    public function down()
    {
        Schema::table('reviews', function (Blueprint $table) {
            $table->string('tour_photos')->nullable(false)->change();
            $table->dropForeign(['tour_category_id']);
            $table->dropColumn('tour_category_id');
        });
    }
}
<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class AgentRegisterEmail extends Mailable
{
    use Queueable, SerializesModels;

   public $tourist_data;
   //public $agentDetails;


    /**
     * Create a new message instance.
     */
    public function __construct($tourist_data)
    {
        //
        $this->tourist_data=$tourist_data;

        

        //$this->agentDetails = $agentDetails;
    }

    /**
     * Get the message envelope.
     */


    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Agent Register Email',
        );
    }

    /**
     * Get the message content definition.
     */


     public function content(): Content
     {
        return new Content(
            view: 'email.agent_register_email',
        );


     }



    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}

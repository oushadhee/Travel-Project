<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use Illuminate\Http\Request;

class ActivityAddController extends Controller
{
    //add activity details function

    public function addActivityDetails(Request $request){

        $imageActivity=$request->file('activity_image');
        $imageDataActivity=$imageActivity->getClientOriginalName();
        $imageActivity->storeAs('public/image/admin/activity',$imageDataActivity);

       Activity::query()->create([

            'place_name'=>$request->place_name,
            'main_category_id'=>$request->main_category_id,
            'sub_category_id'=>$request->sub_category_id,
            'description'=>$request->description,
            'map_link'=>$request->map_link,
            'activity_image'=>$imageDataActivity,

        ]);

        return redirect('/add-activity')->withSuccess('You are registered successfully');

    }
}

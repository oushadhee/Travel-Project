<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;

class EventAddController extends Controller
{
    //Add Event Details function


    public function addEventDetails(Request $request){

        $imageEvent=$request->file('image');
        $imageDataEvent=$imageEvent->getClientOriginalName();
        $imageEvent->storeAs('public/image/admin/event',$imageDataEvent);

        Event::query()->create([

            'event_name'=>$request->event_name,
            'time_period'=>$request->time_period,
            'date'=>$request->date,
            'place'=>$request->place,
            'description'=>$request->description,
            'image'=>$imageDataEvent,

        ]);

        return redirect('/add-event')->withSuccess('You are registered successfully');

    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Excursion;
use Illuminate\Http\Request;

class ExcursionsAddController extends Controller
{
    //add Excursion Details function

    public function addExcursionDetails(Request $request){

        $imageExcursion=$request->file('image');
        $imageDataExcursion=$imageExcursion->getClientOriginalName();
        $imageExcursion->storeAs('public/image/admin/excursion',$imageDataExcursion);

        Excursion::query()->create([

            'excursion_name'=>$request->excursion_name,
            'district'=>$request->district,
            'province'=>$request->province,
            'description'=>$request->description,
            'map_link'=>$request->map_link,
            'image'=>$imageDataExcursion,

        ]);

        return redirect('/add-tour')->withSuccess('You are registered successfully');

    }
}

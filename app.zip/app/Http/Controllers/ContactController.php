<?php

namespace App\Http\Controllers;

use App\Mail\ContactMail;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use App\Models\Country;



class ContactController extends Controller
{
    //contact us function

       public function contact_us(){
        $country_lists = Country::all(); // Fetch all countries
        return view('pages.nav-bar-pages.contactus', compact('country_lists'));
    }


//send email function

    public function sendEmail(Request $request){

//        dd($password,$hashedPassword);

        $data=[

            'firstName'=>$request->firstName,
            'lastName'=>$request->lastName,
            'email'=>$request->email,
            'm_phone_1_country_code'=>$request->m_phone_1_country_code,
            'm_phone_1'=>$request->m_phone_1,
            'message'=>$request->message
        ];

        Mail::to('hello@jumpontravels.com')->send(new ContactMail($data));

        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Contact Mails ',
             'subject' => 'ContactMail',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);

        return redirect('/contactus')->with('success','Your message successfully sent');

    }
}

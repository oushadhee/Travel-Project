<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Log in the user.
     *
     * @param  Request  $request
     * @return RedirectResponse
     */
//     public function login_user(Request $request): RedirectResponse
//     {
//         $input = $request->all();

//         $this->validate($request, [
//             'email' => 'required|email',
//             'password' => 'required',
//         ]);

//         $user = User::where('email', $input['email'])->first();
// // here new code....
//         if (!$user) {
//             return redirect()->route('login')->with('error', 'The email or password is incorrect');
//         }
//         if ($user->status == 'Successful') {
//             return redirect()->route('login')->with('error', 'Your account is pending approval');
//         }
//         if ($user->status == 'Unsuccessful') {
//             return redirect()->route('login')->with('error', 'Your account is pending approval');
//         }
//         if ($user->status == 'Pending') {
//             return redirect()->route('login')->with('error', 'Your account is pending approval.');
//         }

//         if ($user->status == 'Rejected') {
//             return redirect()->route('login')->with('error', 'Your account has been rejected.');
//         }

//         if (Auth::attempt(['email' => $input['email'], 'password' => $input['password']])) {
//             if (auth()->user()->user_type == 'tourer') {
//                 return redirect()->route('tourist-profile');
//             } else {
//                 return redirect()->route('guide-profile');
//             }
//         } else {
//             return redirect()->route('login')->with('error', ' The email or password is incorrect.');
//         }
//     }

// public function login_user(Request $request): RedirectResponse
//     {
//         $input = $request->all();

//         $this->validate($request, [
//             'email' => 'required|email',
//             'password' => 'required',
//         ]);

//         $user = User::where('email', $input['email'])->first();
//         // here new code....
//         if (!$user) {
//             return redirect()->route('login')->with('error', 'The email or password is incorrect');
//         }

//         if ($user->user_type == 'guide') {

//             if ($user->status == 'Pending') {
//                 return redirect()->route('login')->with('error', 'Your account is pending approval.');
//             }

//             if ($user->status == 'Rejected') {
//                 return redirect()->route('login')->with('error', 'Your account has been rejected.');
//             }
//         }

//         if (Auth::attempt(['email' => $input['email'], 'password' => $input['password']])) {
//             if (auth()->user()->user_type == 'tourer') {
//                 return redirect()->route('tourist-profile');
//             } else {
//                 return redirect()->route('guide-profile');
//             }

//         } else {
//             return redirect()->route('login')->with('error', ' The email or password is incorrect.');
//         }
//     }
public function login_user(Request $request): RedirectResponse
{
    $input = $request->all();

    $this->validate($request, [
        'email' => 'required|email',
        'password' => 'required',
    ]);

    $user = User::where('email', $input['email'])->first();

    if (!$user) {
        return redirect()->route('login')->with('error', 'The email or password is incorrect');
    }

    if (!$user->email_verified_at) {
        return redirect()->route('login')->with('error', 'Please verify your email before logging in.');
    }

    if ($user->user_type == 'guide') {
        if ($user->status == 'Pending') {
            return redirect()->route('login')->with('error', 'Your account is pending approval.');
        }

        if ($user->status == 'Rejected') {
            return redirect()->route('login')->with('error', 'Your account has been rejected.');
        }
    }

    if (Auth::attempt(['email' => $input['email'], 'password' => $input['password']])) {
        if (auth()->user()->user_type == 'tourer') {
            return redirect()->route('tourist-profile');
        } else {
            return redirect()->route('guide-profile');
        }
    } else {
        return redirect()->route('login')->with('error', 'The email or password is incorrect.');
    }
}





    //new part logout
    public function logout(Request $request)
{
    $this->guard()->logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect('/login'); // Redirect the user back to the login page
}
}





<?php

namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\ResetPasswordRequest;
use App\Models\User;
use App\Models\Agent;
use App\Mail\AgentVerifyEmail;
use App\Mail\AgentRegisterEmail;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;


class ForgotPasswordManager extends Controller
{
     //add new code
     function forgotPassword(){
        return view("forgot-password");
     }

     function forgotPasswordPost(Request $request){

         $request->validate([

             'email' =>"required|email|exists:users",
         ]);

         $token = Str:: random(64);

         DB:: table('password_resets')->insert([

             'email' => $request->email,
             'token' => $token,
             'created_at' => Carbon::now()
         ]);

         Mail::send("email.forgot-password", ['token'=> $token], function($message) use ($request){
             $message->to($request->email);
             $message->subject("Reset Password");

         });

         return redirect()->to(route("forgot.password"))->with("success","We have send an email to reset password ");

     }

     function resetPassword($token){
       return view("new-password", compact('token'));

     }

     public function reset_Password(ResetPasswordRequest $request)
{
    $user = User::where('email', $request->email)->first();

    // Update the user's password
    $user->password = Hash::make($request->password);
    $user->save();

    // Perform any additional actions, such as logging in the user or sending a notification

    // Redirect the user to a success page or return a response
    return redirect()->route('password.reset.success');
}
     function resetPasswordPost(Request $request){
         $request->validate([

             'email' => "required|email|exists:users",
             'password' =>"required|string|min:6|confirmed",
             'password_confirmation' => "required"
         ]);

         $updatePassword = DB::table('password_resets')->where([
           'email' => $request->email,
           'token' => $request->token,
         ])->first();

         /*$updatePassword = DB::table('password_resets')->where([
             'email' => $request->email,
             'token' => $request->input('token'),
         ])->first();*/

         if(!$updatePassword){
            return redirect()->to(route("reset.password"))->with("error", "Invalid");
           }

 User::where("email", $request->email)->update(["password" => Hash::make($request->password) ]);


 DB::table("password_resets")->where(["email"=>$request->email])->delete();

 return redirect()->to(route("login"))->with("success", "password reset success");

 //return redirect()->route('login')->with("success", "password reset success");
     }

     //...................................................................//



      //login_agent part
      public function login_agent()
      {
          return view('login_agent'); // Redirect the user back to the login page
      }



      public function agent_form()
      {
          return view('agent_form'); // Redirect the user back to the login page
      }



      public function agent_login(Request $request)
      {

          $validatedData = $request->validate([
              'email' => 'required|email'
          ]);

          $user = User::where('email', $validatedData['email'])
                      ->whereNotNull('agent_id')
                      ->where('user_type', 'tourer')
                      ->first();

          if ($user) {
              // User found, retrieve data
              $userData = [
                  'f_name' => $user->f_name,
                  'l_name' => $user->l_name,
                  'm_phone_1_country_code' => $user->m_phone_1_country_code,
                  'm_phone_1' => $user->m_phone_1,
                  'email' => $user->email,
                  'address' => $user->address,
                  'country' => $user->country,
              ];

              // Redirect to agent_form page with user data
              return view('agent_form', compact('userData'));
          } else {
              // User not found, redirect back to login_agent page with error message
              return redirect()->route('login_agent')->with('error', 'This email has not been registered. Please enter the correct email.');
          }

      }



      public function agent_submit(Request $request)
      {

          $validator = Validator::make($request->all(), [
              'f_name' => 'required',
              'l_name' => 'required',
              'm_phone_1_country_code' => 'required',
              'm_phone_1' => 'required',
              'email' => 'required|email',
              'address' => 'required',
              'country' => 'required',
              'password' => 'required|confirmed|min:6|max:10',
          ]);

          if ($validator->fails()) {

              $user = User::where('email', $request['email'])
                      ->whereNotNull('agent_id')
                      ->where('user_type', 'tourer')
                      ->first();

          if ($user) {
              // User found, retrieve data
              $userData = [
                  'f_name' => $user->f_name,
                  'l_name' => $user->l_name,
                  'm_phone_1_country_code' => $user->m_phone_1_country_code,
                  'm_phone_1' => $user->m_phone_1,
                  'email' => $user->email,
                  'address' => $user->address,
                  'country' => $user->country,
              ];
          }

          // var_dump('yessss'); die();password kiyala '' enna one
          return view('agent_form', compact('userData'))->withErrors(['' => 'The passwords do not match.']);

           }
          // Retrieve the user based on the provided email
          $user = User::where('email', $request['email'])->first();
          $remember_token = Str::random(60);
          if ($user) {
              // Update the user's information
              $user->update([
                  'f_name' => $request['f_name'],
                  'l_name' => $request['l_name'],
                  'm_phone_1_country_code' => $request['m_phone_1_country_code'],
                  'm_phone_1' => $request['m_phone_1'],
                  'email'=> $request['email'],
                  'address' => $request['address'],
                  'country' => $request['country'],
                  'password' => bcrypt($request['password']),
                  'remember_token' => $remember_token, // Hash the password
              ]);



          // Retrieve the agent_id from the User table

              $tourist_data=[

                  'f_name'=>$request->f_name,
                  'l_name'=>$request->l_name,
                  'email'=>$request->email,
                  'country'=>$request->country,
                  'address'=>$request->address,
                  'm_phone_1_country_code'=>$request->m_phone_1_country_code,
                  'm_phone_1'=>$request->m_phone_1,



              ];

              $email_verify_tourist=[

                  'f_name'=>$request->f_name,
                  'l_name'=>$request->l_name,

                  'remember_token' => $remember_token,
                  'email_verified_at' => null,

              ];



              Mail::to('hello@jumpontravels.com')->send(new AgentRegisterEmail($tourist_data));
              DB::table('email')->insert([
                  // 'user_id' => $user->id,
                   'title'=>'Register Mails',
                   'subject' => 'AgentRegisterEmail',
                   'status' => 'unread',
                   'created_at' => now(),
                   'updated_at' => now(),
               ]);


              Mail::to($request->email)->send(new AgentVerifyEmail($email_verify_tourist));

              return redirect()->route('login')->with('success', 'You have been successfully registered. We have sent an email to your email, to verify your account. Please check your inbox.');
          } else {

              // User not found, return error message
              return redirect()->back()->with('error', 'User not found.');
          }
      }

      public function verify_tourist_agent($token){

          $tourist = User :: where ('remember_token', '=', $token)->first();

          if(!empty($tourist))
          {
              $tourist->email_verified_at = date('Y-m-d H:i:s');
  //            $tourist-> remember_token = Str::random(60);
              $tourist->save();

              return redirect('login')->with('success','Your account is successfully verified.');

          }
          else
          {
  //            abort(404);
              return redirect('login')->with('error','Your account is not verified.');
          }

      }



// use App\Http\Controllers\Controller;
// use Illuminate\Http\Request;
// use App\Http\Requests\ResetPasswordRequest;
// use App\Models\User;
// use Illuminate\Support\Carbon;
// use Illuminate\Support\Facades\DB;
// use Illuminate\Support\Facades\Hash;
// use Illuminate\Support\Facades\Mail;
// use Illuminate\Support\Str;
// use Illuminate\Support\Facades\Validator;

// class ForgotPasswordManager extends Controller
// {
//      //add new code
//      function forgotPassword(){
//         return view("forgot-password");
//      }

//      function forgotPasswordPost(Request $request){

//          $request->validate([

//              'email' =>"required|email|exists:users",
//          ]);

//          $token = Str:: random(64);

//          DB:: table('password_resets')->insert([

//              'email' => $request->email,
//              'token' => $token,
//              'created_at' => Carbon::now()
//          ]);

//          Mail::send("email.forgot-password", ['token'=> $token], function($message) use ($request){
//              $message->to($request->email);
//              $message->subject("Reset Password");

//          });

//          return redirect()->to(route("forgot.password"))->with("success","We have send an email to reset password ");

//      }

//      function resetPassword($token){
//        return view("new-password", compact('token'));

//      }

//      public function reset_Password(ResetPasswordRequest $request)
//      {
//         $user = User::where('email', $request->email)->first();

//         // Update the user's password
//         $user->password = Hash::make($request->password);
//         $user->save();

//         // Perform any additional actions, such as logging in the user or sending a notification

//         // Redirect the user to a success page or return a response
//         return redirect()->route('password.reset.success');
//      }

//      function resetPasswordPost(Request $request){
//          $request->validate([

//              'email' => "required|email|exists:users",
//              'password' =>"required|string|min:6|confirmed",
//              'password_confirmation' => "required"
//          ]);

//          $updatePassword = DB::table('password_resets')->where([
//            'email' => $request->email,
//            'token' => $request->token,
//          ])->first();

//          /*$updatePassword = DB::table('password_resets')->where([
//              'email' => $request->email,
//              'token' => $request->input('token'),
//          ])->first();*/

//          if(!$updatePassword){
//             return redirect()->to(route("reset.password"))->with("error", "Invalid");
//            }

//         User::where("email", $request->email)->update(["password" => Hash::make($request->password) ]);


//         DB::table("password_resets")->where(["email"=>$request->email])->delete();

//         return redirect()->to(route("login"))->with("success", "password reset success");

//      }

//     //login_agent part
//     public function login_agent()
//     {
//         return view('login_agent'); // Redirect the user back to the login page
//     }


//     public function agent_form()
//     {
//         return view('agent_form'); // Redirect the user back to the login page
//     }


//     public function agent_login(Request $request)
//     {

//         $validatedData = $request->validate([
//             'email' => 'required|email'
//         ]);

//         $user = User::where('email', $validatedData['email'])
//             ->whereNotNull('agent_id')
//             ->where('user_type', 'tourer')
//             ->first();

//         if ($user) {
//             // User found, retrieve data
//             $userData = [
//                 'f_name' => $user->f_name,
//                 'l_name' => $user->l_name,
//                 'm_phone_1_country_code' => $user->m_phone_1_country_code,
//                 'm_phone_1' => $user->m_phone_1,
//                 'email' => $user->email,
//                 'address' => $user->address,
//                 'country' => $user->country,
//             ];

//             // Redirect to agent_form page with user data
//             return view('agent_form', compact('userData'));
//         } else {
//             // User not found, redirect back to login_agent page with error message
//             return redirect()->route('login_agent')->with('error', 'This email has not been registered. Please enter the correct email.');
//         }}

//     public function agent_submit(Request $request)
//     {

//         $validator = Validator::make($request->all(), [
//             'f_name' => 'required',
//             'l_name' => 'required',
//             'm_phone_1_country_code' => 'required',
//             'm_phone_1' => 'required',
//             'email' => 'required|email',
//             'address' => 'required',
//             'country' => 'required',
//             'password' => 'required|confirmed|min:6|max:10',
//         ]);

//         if ($validator->fails()) {

//             $user = User::where('email', $request['email'])
//                 ->whereNotNull('agent_id')
//                 ->where('user_type', 'tourer')
//                 ->first();

//             if ($user) {
//                 // User found, retrieve data
//                 $userData = [
//                     'f_name' => $user->f_name,
//                     'l_name' => $user->l_name,
//                     'm_phone_1_country_code' => $user->m_phone_1_country_code,
//                     'm_phone_1' => $user->m_phone_1,
//                     'email' => $user->email,
//                     'address' => $user->address,
//                     'country' => $user->country,
//                 ];
//             }

//             // var_dump('yessss'); die();password kiyala '' enna one
//             return view('agent_form', compact('userData'))->withErrors(['' => 'The passwords do not match.']);

//         }
//         // Retrieve the user based on the provided email
//         $user = User::where('email', $request['email'])->first();

//         if ($user) {
//             // Update the user's information
//             $user->update([
//                 'f_name' => $request['f_name'],
//                 'l_name' => $request['l_name'],
//                 'm_phone_1_country_code' => $request['m_phone_1_country_code'],
//                 'm_phone_1' => $request['m_phone_1'],
//                 'email'=> $request['email'],
//                 'address' => $request['address'],
//                 'country' => $request['country'],
//                 'password' => bcrypt($request['password']), // Hash the password
//             ]);

//             return redirect()->route('login')->with('success', 'You are registerd successfully!');
//         } else {

//             // User not found, return error message
//             return redirect()->back()->with('error', 'User not found.');
//         }
//     }

// }
// public function agent_submit(Request $request)
// {

//     $validator = Validator::make($request->all(), [
//         'f_name' => 'required',
//         'l_name' => 'required',
//         'm_phone_1_country_code' => 'required',
//         'm_phone_1' => 'required',
//         'email' => 'required|email',
//         'address' => 'required',
//         'country' => 'required',
//         'password' => 'required|confirmed|min:6|max:10',
//     ]);

//     if ($validator->fails()) {

//         $user = User::where('email', $request['email'])
//                 ->whereNotNull('agent_id')
//                 ->where('user_type', 'tourer')
//                 ->first();

//     if ($user) {
//         // User found, retrieve data
//         $userData = [
//             'f_name' => $user->f_name,
//             'l_name' => $user->l_name,
//             'm_phone_1_country_code' => $user->m_phone_1_country_code,
//             'm_phone_1' => $user->m_phone_1,
//             'email' => $user->email,
//             'address' => $user->address,
//             'country' => $user->country,
//         ];
//     }

//     // var_dump('yessss'); die();password kiyala '' enna one
//     return view('agent_form', compact('userData'))->withErrors(['' => 'The passwords do not match.']);

//      }
//     // Retrieve the user based on the provided email
//     $user = User::where('email', $request['email'])->first();
//     $remember_token = Str::random(60);
//     if ($user) {
//         // Update the user's information
//         $user->update([
//             'f_name' => $request['f_name'],
//             'l_name' => $request['l_name'],
//             'm_phone_1_country_code' => $request['m_phone_1_country_code'],
//             'm_phone_1' => $request['m_phone_1'],
//             'email'=> $request['email'],
//             'address' => $request['address'],
//             'country' => $request['country'],
//             'password' => bcrypt($request['password']),
//             'remember_token' => $remember_token, // Hash the password
//         ]);



//     // Retrieve the agent_id from the User table

//         $tourist_data=[

//             'f_name'=>$request->f_name,
//             'l_name'=>$request->l_name,
//             'email'=>$request->email,
//             'country'=>$request->country,
//             'address'=>$request->address,
//             'm_phone_1_country_code'=>$request->m_phone_1_country_code,
//             'm_phone_1'=>$request->m_phone_1,



//         ];

//         $email_verify_tourist=[

//             'f_name'=>$request->f_name,
//             'l_name'=>$request->l_name,

//             'remember_token' => $remember_token,
//             'email_verified_at' => null,

//         ];



//         Mail::to('hello@jumpontravels.com')->send(new AgentRegisterEmail($tourist_data));
//         DB::table('email')->insert([
//             // 'user_id' => $user->id,
//              'title'=>'Register Mails',
//              'subject' => 'AgentRegisterEmail',
//              'status' => 'unread',
//              'created_at' => now(),
//              'updated_at' => now(),
//          ]);


//         Mail::to($request->email)->send(new AgentVerifyEmail($email_verify_tourist));

//         return redirect()->route('login')->with('success', 'You have been successfully registered. We have sent an email to your email, to verify your account. Please check your inbox.');
//     } else {

//         // User not found, return error message
//         return redirect()->back()->with('error', 'User not found.');
//     }
// }

// public function verify_tourist_agent($token){

//     $tourist = User :: where ('remember_token', '=', $token)->first();

//     if(!empty($tourist))
//     {
//         $tourist->email_verified_at = date('Y-m-d H:i:s');
// //            $tourist-> remember_token = Str::random(60);
//         $tourist->save();

//         return redirect('login')->with('success','Your account is successfully verified.');

//     }
//     else
//     {
// //            abort(404);
//         return redirect('login')->with('error','Your account is not verified.');
//     }

// }

}

<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\BookNowMail;
use App\Mail\GuideRegisteredMail;
use App\Mail\TouristRegisteredMail;
use App\Mail\VerificationMailGuide;
use App\Mail\VerifyBookNowMail;
use App\Models\BookNow;
use App\Models\GuideDetails;
use App\Models\SelectedLocations;
use App\Models\Vehicle;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use App\Rules\ValidEmailDomain;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\DB;

//use Str;

use App\Mail\VerificationMail;

use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

//    /**
//     * Get a validator for an incoming registration request.
//     *
//     * @param  array  $data
//     * @return \Illuminate\Contracts\Validation\Validator
//     */
//    protected function validator(array $data)
//    {
//        return Validator::make($data, [
//            'name' => ['required', 'string', 'max:255'],
//            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
//            'password' => ['required', 'string', 'min:8', 'confirmed'],
//        ]);
//    }
//
//    /**
//     * Create a new user instance after a valid registration.
//     *
//     * @param  array  $data
//     * @return \App\Models\User
//     */
//    protected function create(array $data)
//    {
//        return User::create([
//            'name' => $data['name'],
//            'email' => $data['email'],
//            'password' => Hash::make($data['password']),
//        ]);
//    }


    //Register_Tourist

    public function registerTourist(Request $request){
        //    var_dump('yes 1');
                $request->validate([

                    'f_name' => 'required',
                    'l_name' => 'required',

        //            'country_code_1' => 'required',
                    'm_phone_1_country_code' => 'required',
                    'm_phone_1'=> 'required',
        //            'email' => 'required|email|unique:users',
                    'email' => ['required', 'email', 'unique:users', 'string', new ValidEmailDomain],
                    'address' => 'required',
                    'country' => 'required',

                    'password' => 'required|confirmed|min:6|max:10',
        //            'password_repeat' => 'required'

                ]);

        //        var_dump('yes 2');die();
                $password=$request->password;
                $hashedPassword = Hash::make($password);

                $remember_token = Str::random(60);

        //        var_dump($remember_token); die();
        //        dd($password,$hashedPassword);
                User::query()->create([

                    'user_type'=>'tourer',
                    'f_name'=>$request->f_name,
                    'l_name'=>$request->l_name,

                    'm_phone_1_country_code'=>$request->m_phone_1_country_code,
                    'm_phone_1'=>$request->m_phone_1,
        //            'country_code_2',
                    'm_phone_2_country_code',
                    'm_phone_2',
                    'email'=>$request->email,
                    'address'=>$request->address,
                    'country'=>$request->country,
                    'l_number_country_code',
                    'l_number',
                    'ec_name',
                    'ec_number_country_code',
                    'ec_number',

                    'password'=>$hashedPassword,

                    'remember_token' => $remember_token,
        //            'remember_token' => str_random(40),
                    'email_verified_at' => null,

                ]);

        //        var_dump('yes');die();
                $tourist_data=[

                    'f_name'=>$request->f_name,
                    'l_name'=>$request->l_name,
                    'email'=>$request->email,
                    'country'=>$request->country,
                    'address'=>$request->address,
                    'm_phone_1_country_code'=>$request->m_phone_1_country_code,
                    'm_phone_1'=>$request->m_phone_1
                ];

                $email_verify_tourist=[

                    'f_name'=>$request->f_name,
                    'l_name'=>$request->l_name,

                    'remember_token' => $remember_token,
                   // 'email_verified_at' => null,

                ];

                //dd($tourist_data);
                Mail::to('adminstarluxe@keenrabbits.biz')->send(new TouristRegisteredMail($tourist_data));

                Mail::to($request->email)->send(new VerificationMail($email_verify_tourist));

                DB::table('email')->insert([
                    // 'user_id' => $user->id,
                     'title'=>'Register Mails',
                     'subject' => 'TouristRegisteredMail',
                     'status' => 'unread',
                     'created_at' => now(),
                     'updated_at' => now(),
                 ]);

                return redirect('/login')->with('success','You have been successfully registered. We have sent an email to your email, to verify your account. Please check your inbox.');

            }

            public function verify_tourist($token){

                $tourist = User :: where ('remember_token', '=', $token)->first();

                if(!empty($tourist))
                {
                    $tourist->email_verified_at = date('Y-m-d H:i:s');
        //            $tourist-> remember_token = Str::random(60);
                    $tourist->save();

                    return redirect('/login')->with('success', 'Your account is successfully verified.');
    } else {
        return redirect('/login')->with('error', 'Invalid verification link.');
    }

            }
    //------------------------------------------------------------------------------------------------------------------

    //Book Now

    public function saveBookNow(Request $request)
    {
//        var_dump($request->all());die();

        $request->validate([

//            'start_date'=> 'required',
//            'end_date'=> 'required',
//            'expected_country'=> 'required',
//            'expected_location'=> 'required',

            'f_name' => 'required',
            'l_name' => 'required',

//            'country_code_1' => 'required',
            'm_phone_1_country_code' => 'required',
            'm_phone_1' => 'required',
            'email' => 'required|email|unique:users',
            'address' => 'required',
            'country' => 'required',

            'password' => 'required|confirmed|min:6|max:10',
//            'password_repeat' => 'required'

        ]);

        $password=$request->password;
        $hashedPassword = Hash::make($password);

        $remember_token = Str::random(60);

        $BookedUser=User::query()->create([

            'user_type'=>'tourer',
            'f_name'=>$request->f_name,
            'l_name'=>$request->l_name,
//            'country_code_1'=>$request->country_code_1,
            'm_phone_1_country_code'=>$request->m_phone_1_country_code,
            'm_phone_1'=>$request->m_phone_1,
//            'country_code_2',
            'm_phone_2_country_code',
            'm_phone_2',
            'email'=>$request->email,
            'address'=>$request->address,
            'country'=>$request->country,
            'l_number_country_code',
            'l_number',
            'ec_name',
            'ec_number_country_code',
            'ec_number',

            'password'=>$hashedPassword,

            'remember_token' => $remember_token,
            'email_verified_at' => null,

        ]);

        $airTicket = $request->input('air_tickets');

        $booking = BookNow::query()->create([

//            'user_type'=>'tourer',
            'user_id'=>$BookedUser->id,

            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
            'number_of_days'=>$request->number_of_days,

            'expected_country'=>$request->expected_country,
            'expected_location'=>$request->expected_location,
            'tour_package'=>$request->tour_package,

            'number_of_people'=>$request->number_of_people,
            'number_of_adults'=>$request->number_of_adults,
            'number_of_children'=>$request->number_of_children,
//            'baby_type'=>$request->baby_type,
            'number_of_toddlers'=>$request->number_of_toddlers,
            'number_of_infants'=>$request->number_of_infants,
            'number_of_newborns'=>$request->number_of_newborns,
//            'number_of_babies'=>$request->number_of_babies,
            'requirements_for_babies'=>$request->requirements_for_babies,

            'property_type'=>$request->property_type,
            'star_ratings'=>$request->star_ratings,
            'vehicle_type'=>$request->vehicle_type,

            'budget_range_from'=>$request->budget_range_from,
            'budget_range_to'=>$request->budget_range_to,

            'travel_destination'=>$request->travel_destination,
            'air_tickets' => $airTicket,
            'requirements_for_tour'=>$request->requirements_for_tour,

        ]);


        $bookingId = $booking->id;
        $selectedExcursions = $request->input('selected_excursions');
        SelectedLocations::create([
            'booked_id' => $bookingId,
            'location' => $selectedExcursions,
        ]);

        $booked_tourist=[

            'f_name'=>$request->f_name,
            'l_name'=>$request->l_name,

            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
            'number_of_days'=>$request->number_of_days,

            'expected_country'=>$request->expected_country,
//            'expected_location'=>$request->expected_location,
            'location' => $selectedExcursions,
            'tour_package'=>$request->tour_package,

            'number_of_people'=>$request->number_of_people,
            'number_of_adults'=>$request->number_of_adults,
            'number_of_children'=>$request->number_of_children,
//            'baby_type'=>$request->baby_type,
            'number_of_toddlers'=>$request->number_of_toddlers,
            'number_of_infants'=>$request->number_of_infants,
            'number_of_newborns'=>$request->number_of_newborns,
//            'number_of_babies'=>$request->number_of_babies,
            'requirements_for_babies'=>$request->requirements_for_babies,

            'property_type'=>$request->property_type,
            'star_ratings'=>$request->star_ratings,
            'vehicle_type'=>$request->vehicle_type,

            'budget_range_from'=>$request->budget_range_from,
            'budget_range_to'=>$request->budget_range_to,

            'travel_destination'=>$request->travel_destination,
            'air_tickets' => $airTicket,
            'requirements_for_tour'=>$request->requirements_for_tour,

            'email'=>$request->email,
            'country'=>$request->country,
            'address'=>$request->address,
            'm_phone_1_country_code'=>$request->m_phone_1_country_code,
            'm_phone_1'=>$request->m_phone_1

        ];

        $email_verify_booked_tourist=[

            'f_name'=>$request->f_name,
            'l_name'=>$request->l_name,

            'remember_token' => $remember_token,
            'email_verified_at' => null,

        ];

        Mail::to('adminstarluxe@keenrabbits.biz')->send(new BookNowMail($booked_tourist));

        Mail::to($request->email)->send(new VerifyBookNowMail($email_verify_booked_tourist));

        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Booking Tours',
             'subject' => 'BookNowMail',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);

        return redirect('/login')->with('success','You have been successfully registered. We have sent an email to your email, to verify your account. Please check your inbox.');

    }

    public function verify_booked_tourist($token_booked){

        $tourist_booked = User :: where ('remember_token', '=', $token_booked)->first();

        if(!empty($tourist_booked))
        {
            $tourist_booked->email_verified_at = date('Y-m-d H:i:s');
            $tourist_booked->save();

            return redirect('/login')->with('success','Your account successfully verified.');

        }
        else
        {
//            abort(404);
            return redirect('/login')->with('error','Your account is not verified.');
        }

    }

//----------------------------------------------------------------------------------------------------------------------

    //Register_Guide

    public function registerGuide(Request $request){

        //var_dump($request->all());die();

        $request->validate([

            'f_name' => 'required',
            'l_name' => 'required',

            'm_phone_1_country_code' => 'required',
            'm_phone_1' => 'required',

            'm_phone_2_country_code' => 'required',
            'm_phone_2' => 'required',

            'email' => 'required|email|unique:users',
            'address' => 'required',

            'l_number_country_code' => 'required',
            'l_number' => 'required',

            'ec_name' => 'required',
            'ec_number_country_code' => 'required',
            'ec_number' => 'required',

            'about' => 'required|min:20',
            'language' => 'required',

            'w_experience' => 'required',
            'guides_photos_pass_size' => 'required',
            'guides_photos_normal' => 'required',
            'guide_license_f' => 'required',
            'guide_license_b' => 'required',
            'driving_license_f' => 'required',
            'driving_license_b' => 'required',
            'nic_f' => 'required',
            'nic_b' => 'required',
            'guide_category' => 'required',

            'fileToUpload_v_insurance_f' => 'required',
            'fileToUpload_v_insurance_b' => 'required',
            'v_book_f' => 'required',
            'v_book_b' => 'required',
            'end_date_insurance' => 'required|date',
            'vehicle_type' => 'required',
            'v_model' => 'required',
            'v_number' => 'required',
            'v_out__front_images' => 'required',
            'v_out_back_images' => 'required',
            'v_out_right_images' => 'required',
            'v_out_left_images' => 'required',
            'v_in_front_images' => 'required',
            'v_in_back_images' => 'required',
            'vehicle_rent_own' => 'required',

            'password' => 'required|confirmed|min:6|max:10',

        ]);

        //var_dump('yes');die();

        //dd($request->all());
        $password=$request->password;
        $hashedPassword = Hash::make($password);

        $remember_token = Str::random(60);

        $imageFront = $request->file('v_out__front_images');
        $imageExtension = $imageFront->getClientOriginalExtension();
        $imageNameFront = time() . mt_rand(100, 999) . '.' . $imageExtension;
        $filePathVOUTF = 'storage/image/guide/vehicle/front/';
        $fullPath = public_path($filePathVOUTF);
        $imageFront->move($fullPath, $imageNameFront);


//        $imageFront=$request->file('v_out__front_images');
//        $imageNameFront=$imageFront->getClientOriginalName();
//        $imageFront->storeAs('public/image/guide/vehicle/front',$imageNameFront);

        // For v_out_back_images
        $imageBack = $request->file('v_out_back_images');
        $imageExtensionBack = $imageBack->getClientOriginalExtension();
        $imageNameBack = time() . mt_rand(100, 999) . '.' . $imageExtensionBack;
        $filePathVOUTB = 'storage/image/guide/vehicle/back/';
        $fullPath = public_path($filePathVOUTB);
        $imageBack->move($fullPath, $imageNameBack);

        // For v_out_left_images
        $imageLeft = $request->file('v_out_left_images');
        $imageExtensionLeft = $imageLeft->getClientOriginalExtension();
        $imageNameLeft = time() . mt_rand(100, 999) . '.' . $imageExtensionLeft;
        $filePathVOUTL = 'storage/image/guide/vehicle/left/';
        $fullPath = public_path($filePathVOUTL);
        $imageLeft->move($fullPath, $imageNameLeft);

        // For v_out_right_images
        $imageRight = $request->file('v_out_right_images');
        $imageExtensionRight = $imageRight->getClientOriginalExtension();
        $imageNameRight = time() . mt_rand(100, 999) . '.' . $imageExtensionRight;
        $filePathVOUTR = 'storage/image/guide/vehicle/right/';
        $fullPath = public_path($filePathVOUTR);
        $imageRight->move($fullPath, $imageNameRight);

        // For v_in_front_images
        $imageIN_Front = $request->file('v_in_front_images');
        $imageExtensionInFront = $imageIN_Front->getClientOriginalExtension();
        $imageNameInFront = time() . mt_rand(100, 999) . '.' . $imageExtensionInFront;
        $filePathVINF = 'storage/image/guide/vehicle/inside/front/';
        $fullPath = public_path($filePathVINF);
        $imageIN_Front->move($fullPath, $imageNameInFront);

        // For v_in_back_images
        $imageIN_Back = $request->file('v_in_back_images');
        $imageExtensionInBack = $imageIN_Back->getClientOriginalExtension();
        $imageNameInBack = time() . mt_rand(100, 999) . '.' . $imageExtensionInBack;
        $filePathVINB = 'storage/image/guide/vehicle/inside/back/';
        $fullPath = public_path($filePathVINB);
        $imageIN_Back->move($fullPath, $imageNameInBack);


        //-----------------------------------------------------------------------------------------

        // For fileToUpload_v_insurance_f
        $pdf_v_insurance_f = $request->file('fileToUpload_v_insurance_f');
        $pdfExtension_v_insurance_f = $pdf_v_insurance_f->getClientOriginalExtension();
        $pdfName_v_insurance_f = time() . mt_rand(100, 999) . '.' . $pdfExtension_v_insurance_f;
        $filePathINSUF = 'storage/document/guide/insurance/front/';
        $fullPath = public_path($filePathINSUF);
        $pdf_v_insurance_f->move($fullPath, $pdfName_v_insurance_f);

        // For fileToUpload_v_insurance_b
        $pdf_v_insurance_b = $request->file('fileToUpload_v_insurance_b');
        $pdfExtension_v_insurance_b = $pdf_v_insurance_b->getClientOriginalExtension();
        $pdfName_v_insurance_b = time() . mt_rand(100, 999) . '.' . $pdfExtension_v_insurance_b;
        $filePathINSUB = 'storage/document/guide/insurance/back/';
        $fullPath = public_path($filePathINSUB);
        $pdf_v_insurance_b->move($fullPath, $pdfName_v_insurance_b);

        // For v_book_f
        $pdf_v_book_f = $request->file('v_book_f');
        $pdfExtension_v_book_f = $pdf_v_book_f->getClientOriginalExtension();
        $pdfName_v_book_f = time() . mt_rand(100, 999) . '.' . $pdfExtension_v_book_f;
        $filePathVBF = 'storage/document/guide/v_book/front/';
        $fullPath = public_path($filePathVBF);
        $pdf_v_book_f->move($fullPath, $pdfName_v_book_f);

        // For v_book_b
        $pdf_v_book_b = $request->file('v_book_b');
        $pdfExtension_v_book_b = $pdf_v_book_b->getClientOriginalExtension();
        $pdfName_v_book_b = time() . mt_rand(100, 999) . '.' . $pdfExtension_v_book_b;
        $filePathVBB = 'storage/document/guide/v_book/back/';
        $fullPath = public_path($filePathVBB);
        $pdf_v_book_b->move($fullPath, $pdfName_v_book_b);


        //----------------------------------------------------------------------

        // For guides_photos_pass_size
        $imagePassportSize = $request->file('guides_photos_pass_size');
        $imageExtensionPassportSize = $imagePassportSize->getClientOriginalExtension();
        $imageNamePassportSize = time() . mt_rand(100, 999) . '.' . $imageExtensionPassportSize;
        $filePathPASS = 'storage/image/guide/personal/passport_size/';
        $fullPath = public_path($filePathPASS);
        $imagePassportSize->move($fullPath, $imageNamePassportSize);

        // For guides_photos_normal
        $imageGuideNormal = $request->file('guides_photos_normal');
        $imageExtensionGuideNormal = $imageGuideNormal->getClientOriginalExtension();
        $imageGuideNormalPhoto = time() . mt_rand(100, 999) . '.' . $imageExtensionGuideNormal;
        $filePathNOR = 'storage/image/guide/personal/normal/';
        $fullPath = public_path($filePathNOR);
        $imageGuideNormal->move($fullPath, $imageGuideNormalPhoto);

        //-------------------------------------------------------------------------------------------------

        // For guide_license_f
        $pdf_guide_license_f = $request->file('guide_license_f');
        $pdfExtensionGuideLicenseF = $pdf_guide_license_f->getClientOriginalExtension();
        $pdfNameGuideLicenseF = time() . mt_rand(100, 999) . '.' . $pdfExtensionGuideLicenseF;
        $filePathGLF = 'storage/document/guide/personal/guide_license/front/';
        $fullPath = public_path($filePathGLF);
        $pdf_guide_license_f->move($fullPath, $pdfNameGuideLicenseF);

        // For guide_license_b
        $pdf_guide_license_b = $request->file('guide_license_b');
        $pdfExtensionGuideLicenseB = $pdf_guide_license_b->getClientOriginalExtension();
        $pdfNameGuideLicenseB = time() . mt_rand(100, 999) . '.' . $pdfExtensionGuideLicenseB;
        $filePathGLB = 'storage/document/guide/personal/guide_license/back/';
        $fullPath = public_path($filePathGLB);
        $pdf_guide_license_b->move($fullPath, $pdfNameGuideLicenseB);

        // For driving_license_f
        $pdf_driving_license_f = $request->file('driving_license_f');
        $pdfExtensionDrivingLicenseF = $pdf_driving_license_f->getClientOriginalExtension();
        $pdfNameDrivingLicenseF = time() . mt_rand(100, 999) . '.' . $pdfExtensionDrivingLicenseF;
        $filePathDLF = 'storage/document/guide/personal/driving_license/front/';
        $fullPath = public_path($filePathDLF);
        $pdf_driving_license_f->move($fullPath, $pdfNameDrivingLicenseF);

        // For driving_license_b
        $pdf_driving_license_b = $request->file('driving_license_b');
        $pdfExtensionDrivingLicenseB = $pdf_driving_license_b->getClientOriginalExtension();
        $pdfNameDrivingLicenseB = time() . mt_rand(100, 999) . '.' . $pdfExtensionDrivingLicenseB;
        $filePathDLB = 'storage/document/guide/personal/driving_license/back/';
        $fullPath = public_path($filePathDLB);
        $pdf_driving_license_b->move($fullPath, $pdfNameDrivingLicenseB);

        // For nic_f
        $pdf_nic_f = $request->file('nic_f');
        $pdfExtensionNicF = $pdf_nic_f->getClientOriginalExtension();
        $pdfNameNicF = time() . mt_rand(100, 999) . '.' . $pdfExtensionNicF;
        $filePathNICF = 'storage/document/guide/personal/nic/front/';
        $fullPath = public_path($filePathNICF);
        $pdf_nic_f->move($fullPath, $pdfNameNicF);

        // For nic_b
        $pdf_nic_b = $request->file('nic_b');
        $pdfExtensionNicB = $pdf_nic_b->getClientOriginalExtension();
        $pdfNameNicB = time() . '_' . mt_rand(100, 999) . '.' . $pdfExtensionNicB; // Add a random number between 1000 and 9999
        $filePathNICB = 'storage/document/guide/personal/nic/back/';
        $fullPath = public_path($filePathNICB);
        $pdf_nic_b->move($fullPath, $pdfNameNicB);

        $languages = $request->input('language');

        // Convert the array of languages to a comma-separated string
        $languages_known = implode(',', $languages);

        //dd($imagePath);
        //var_dump('yes');die();

        $User=User::query()->create([

            'user_type'=>'guide',
            'f_name'=>$request->f_name,
            'l_name'=>$request->l_name,

            'm_phone_1_country_code'=>$request->m_phone_1_country_code,
            'm_phone_1'=>$request->m_phone_1,

            'm_phone_2_country_code'=>$request->m_phone_2_country_code,
            'm_phone_2'=>$request->m_phone_2,

            'email'=>$request->email,
            'address'=>$request->address,
            'country'=>'null',
            'l_number_country_code'=>$request->l_number_country_code,
            'l_number'=>$request->l_number,
            'ec_name'=>$request->ec_name,
            'ec_number_country_code'=>$request->ec_number_country_code,
            'ec_number'=>$request->ec_number,

            'password'=>$hashedPassword,

            'remember_token' => $remember_token,
            'email_verified_at' => null,
        ]);

        //dd($User);

        Vehicle::query()->create([

            'user_id'=>$User->id,
            'fileToUpload_v_insurance_f'=>$filePathINSUF.$pdfName_v_insurance_f,
            'fileToUpload_v_insurance_b'=>$filePathINSUB.$pdfName_v_insurance_b,
            'v_book_f'=>$filePathVBF.$pdfName_v_book_f,
            'v_book_b'=>$filePathVBB.$pdfName_v_book_b,
            'end_date_insurance'=>$request->end_date_insurance,
            'vehicle_type'=>$request->vehicle_type,
            'v_model'=>$request->v_model,
            'v_number'=>$request->v_number,
            'v_out__front_images'=>$filePathVOUTF.$imageNameFront,
            'v_out_back_images'=>$filePathVOUTB.$imageNameBack,
            'v_out_right_images'=>$filePathVOUTR.$imageNameRight,
            'v_out_left_images'=>$filePathVOUTL.$imageNameLeft,
            'v_in_front_images'=>$filePathVINF.$imageNameInFront,
            'v_in_back_images'=>$filePathVINB.$imageNameInBack,
            'vehicle_rent_own'=>$request->vehicle_rent_own,

        ]);

        GuideDetails::query()->create([

            'user_id'=>$User->id,
            'about'=>$request->about,
            'language'=>$languages_known,
            'w_experience'=>$request->w_experience,
            'guides_photos_pass_size'=>$filePathPASS.$imageNamePassportSize,
            'guides_photos_normal'=>$filePathNOR.$imageGuideNormalPhoto,
            'guide_license_f'=>$filePathGLF.$pdfNameGuideLicenseF,
            'guide_license_b'=>$filePathGLB.$pdfNameGuideLicenseB,
            'driving_license_f'=>$filePathDLF.$pdfNameDrivingLicenseF,
            'driving_license_b'=>$filePathDLB.$pdfNameDrivingLicenseB,
            'nic_f'=>$filePathNICF.$pdfNameNicF,
            'nic_b'=>$filePathNICB.$pdfNameNicB,
            'guide_category'=>$request->guide_category

        ]);

        //var_dump('yes');die();
        $guide_data=[

            'f_name'=>$request->f_name,
            'l_name'=>$request->l_name,
            'm_phone_1_country_code'=>$request->m_phone_1_country_code,
            'm_phone_1'=>$request->m_phone_1,
            'email'=>$request->email,
            'about'=>$request->about,
            'address'=>$request->address,
            'language'=>$languages_known,
            'w_experience'=>$request->w_experience,
            'guide_category'=>$request->guide_category,

            'guides_photos_pass_size'=>$imageNamePassportSize,
            'guides_photos_normal'=>$imageGuideNormalPhoto,
            'guide_license_f'=>$pdfNameGuideLicenseF,
            'guide_license_b'=>$pdfNameGuideLicenseB,
            'driving_license_f'=>$pdfNameDrivingLicenseF,
            'driving_license_b'=>$pdfNameDrivingLicenseB,
            'nic_f'=>$pdfNameNicF,
            'nic_b'=>$pdfNameNicB,

            'fileToUpload_v_insurance_f'=>$pdfName_v_insurance_f,
            'fileToUpload_v_insurance_b'=>$pdfName_v_insurance_b,
            'v_book_f'=>$pdfName_v_book_f,
            'v_book_b'=>$pdfName_v_book_b,
            'end_date_insurance'=>$request->end_date_insurance,
            'vehicle_type'=>$request->vehicle_type,
            'v_model'=>$request->v_model,
            'v_number'=>$request->v_number,
            'v_out__front_images'=>$imageNameFront,
            'v_out_back_images'=>$imageNameBack,
            'v_out_right_images'=>$imageNameRight,
            'v_out_left_images'=>$imageNameLeft,
            'v_in_front_images'=>$imageNameInFront,
            'v_in_back_images'=>$imageNameInBack,
            'vehicle_rent_own'=>$request->vehicle_rent_own,

        ];

        $email_verify_guide=[

            'f_name'=>$request->f_name,
            'l_name'=>$request->l_name,

            'remember_token' => $remember_token,
            'email_verified_at' => null,

        ];

//        dd($guide_data);
        Mail::to('adminstarluxe@keenrabbits.biz')->send(new GuideRegisteredMail($guide_data));

        Mail::to($request->email)->send(new VerificationMailGuide($email_verify_guide));

        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Register Mails',
             'subject' => 'GuideRegisteredMail',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);


//        return redirect('/login')->withSuccess('You are registered successfully verify your email address');
        return redirect('/login')->with('success','You have been successfully registered. We have sent an email to your email, to verify your account. Please check your inbox.');

//        return redirect('/coming-soon')->withSuccess('You are registered successfully');

    }

    public function verify_guide($token_g){

        $guide = User :: where ('remember_token', '=', $token_g)->first();

        if(!empty($guide))
        {
            $guide->email_verified_at = date('Y-m-d H:i:s');
            $guide->save();

            return redirect('/login')->with('success','Your account successfully verified.');

        }
        else
        {
//            abort(404);
            return redirect('/login')->with('error','Your account is not verified.');
        }

    }
}

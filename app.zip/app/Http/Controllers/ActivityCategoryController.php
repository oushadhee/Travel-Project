<?php

namespace App\Http\Controllers;

use App\Models\ActivityCategory;
use Illuminate\Http\Request;

class ActivityCategoryController extends Controller
{
    //add activity category function

    public function addActivityCategory(Request $request){

        $imageActivityCategory=$request->file('activity_image');
        $imageDataActivityCategory=$imageActivityCategory->getClientOriginalName();
        $imageActivityCategory->storeAs('public/image/admin/activityCategory',$imageDataActivityCategory);

        ActivityCategory::query()->create([

            'category_name'=>$request->category_name,
            'parent_id'=>$request->parent_id,
            'activity_image'=>$imageDataActivityCategory

        ]);

        return redirect('/add-activity-category')->withSuccess('You are registered successfully');
    }
}

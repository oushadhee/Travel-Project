<?php

namespace App\Http\Controllers;

use App\Mail\BookNowMail;
use App\Mail\BookNowMailRegistered;
use App\Mail\ContactMail;
use App\Mail\EditBookNowMailRegistered;
use App\Mail\TourerDocumentUploaded;
use App\Mail\TouristRegisteredMail;
use App\Mail\TourCancelledMail;
use App\Models\BookingConfirmed;
use App\Models\BookNow;
use App\Models\Excursion;
use App\Models\SelectedLocations;
use App\Models\Tourist;
use App\Models\Unexplored;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use App\Models\TourCategory; 
use function Laravel\Prompts\password;

class TouristController extends Controller
{
    //
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }

//    public function tourist_profile(){
//
//        return view('pages.dashboards.tourist-profile');
//    }


//tourist profile function
    public function tourist_profile(){

        $user = Auth::user();

        // Fetch the relevant data from the database
        $bookNow = BookNow::where('status', 'Confirmed')
            ->where('user_id', $user->id)
            ->first();
              $tourCategories = TourCategory::all();


        return view('pages.dashboards.tourist-profile', compact('bookNow', 'tourCategories'));
    }

    public function saveReview(Request $request)
    {
        $validatedData = $request->validate([
            'user_id' => 'required|exists:users,id',
            'tour_type' => 'required|in:Cultural,Wildlife,Eco',
            'rating' => 'required|integer|between:1,5',
            'comment_jot' => 'required|string|max:1000',
            'suggestions_jot' => 'required|string|max:1000',
            'start_date' => 'required|date|before_or_equal:end_date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'country' => 'required|string|max:255',
            'tour_photos.*' => 'nullable|file|mimes:jpeg,png,jpg,gif|max:2048',
            'tour_category_id' => 'nullable|exists:tour_categories,id',
            'selected_guide' => 'nullable|string|max:255',
            'comment_guide' => 'nullable|string|max:1000',
            'suggestions_guide' => 'nullable|string|max:1000',
        ]);

        $tourPhotos = [];
        if ($request->hasFile('tour_photos')) {
            foreach ($request->file('tour_photos') as $photo) {
                $fileName = time() . '_' . $photo->getClientOriginalName();
                $photo->move(public_path('storage/images/reviews/'), $fileName);
                $tourPhotos[] = 'storage/images/reviews/' . $fileName;
            }
        }

        Review::create([
            'user_id' => $validatedData['user_id'],
            'tour_type' => $validatedData['tour_type'],
            'rating' => $validatedData['rating'],
            'comment_jot' => $validatedData['comment_jot'],
            'suggestions_jot' => $validatedData['suggestions_jot'],
            'start_date' => $validatedData['start_date'],
            'end_date' => $validatedData['end_date'],
            'country' => $validatedData['country'],
            'tour_photos' => !empty($tourPhotos) ? json_encode($tourPhotos) : null,
            'tour_category_id' => $validatedData['tour_category_id'] ?? null,
            'selected_guide' => $validatedData['selected_guide'] ?? null,
            'comment_guide' => $validatedData['comment_guide'] ?? null,
            'suggestions_guide' => $validatedData['suggestions_guide'] ?? null,
        ]);

        return redirect()->back()->with('success', 'Your review has been submitted successfully.');
    }

    //login function
    public function login(){

        return view('pages.nav-bar-pages.login');
    }

    //register function
    public function register(){

        return view('auth.register');
    }

    //book now function
    public function book_now(){

        return view('pages.book-now.book-now-form');
    }

    //view booked tours function
    public function view_booked_tours(){

        return view('pages.dashboards.view_booked_tours');
    }

    //cancel tours function
    public function cancel_tour($id)
    {
        $tour = BookNow::findOrFail($id);

        if ($tour && $tour->user_id == Auth::user()->id) {
            $tour->status = 'Cancelled';
            $tour->save();

            // Get the user details
            $user = User::find(Auth::user()->id);

            // Send the cancellation email
            Mail::to('adminstarluxe@keenrabbits.biz')->send(new TourCancelledMail($tour, $user));


            // Set a success message in the session
            return redirect()->route('view_booked_tours')->with('success', 'You have successfully canceled your booking.');
        }

        return redirect()->route('view_booked_tours')->with('error', 'Failed to cancel the booking.');
    }

    //view create tourist function
    public function view_create_tourist(){

        return view('pages.dashboards.create_tourist');
    }

   //excursoin list function
    public function excursions_list()
{
    $excursions = \App\Models\Excursion::whereNull('is_deleted')->paginate(6);

    // Fetch the selected excursion IDs from the session or another source
    $selectedExcursionIds = session('selectedExcursionIds', []);

    return view('pages.book-now.excursions_list', compact('excursions', 'selectedExcursionIds'));
}

//edit book function

public function edit_book_now_form($id, Request $request) {
    $bookedTour = \App\Models\BookNow::find($id);
    $selectedLocation = \App\Models\SelectedLocations::where('booked_id', $id)->first();

    if ($request->has('selected_excursions')) {
        $selectedExcursions = array_unique(array_filter(explode(',', $request->input('selected_excursions'))));
        $selectedLocation->location = implode(',', $selectedExcursions);
        $selectedLocation->save();
    }

    $selectedExcursions = $selectedLocation ? array_unique(array_filter(explode(',', $selectedLocation->location))) : [];

    return view('pages.dashboards.edit_book_now_form', compact('bookedTour', 'selectedLocation', 'selectedExcursions'));
}

//edit excrusion list function
public function edit_excursion_list($id) {
    $bookedTour = \App\Models\BookNow::find($id);
    $selectedLocation = \App\Models\SelectedLocations::where('booked_id', $id)->first();

    // Fetch the initially selected excursions
    $initiallySelectedExcursions = [];
    if ($selectedLocation) {
        $excursionNames = explode(',', $selectedLocation->location);
        $initiallySelectedExcursions = \App\Models\Excursion::whereIn('excursion_name', $excursionNames)->whereNull('is_deleted')->get();
    }

    return view('pages.dashboards.edit_excursion_list', compact('selectedLocation', 'bookedTour', 'id', 'initiallySelectedExcursions'));
}

//edit book now function
public function edit_book_now(Request $request, $id)
{

    $bookedTour = BookNow::findOrFail($id);

    $airTicket = $request->input('air_tickets');

    $bookedTour->update([

        'start_date'=>$request->start_date,
        'end_date'=>$request->end_date,
        'number_of_days'=>$request->number_of_days,

        'expected_country'=>$request->expected_country,
        'expected_location'=>$request->expected_location,
        'tour_package'=>$request->tour_package,

        'number_of_people'=>$request->number_of_people,
        'number_of_adults'=>$request->number_of_adults,
        'number_of_children'=>$request->number_of_children,
        'number_of_toddlers'=>$request->number_of_toddlers,
        'number_of_infants'=>$request->number_of_infants,
        'number_of_newborns'=>$request->number_of_newborns,
        'requirements_for_babies'=>$request->requirements_for_babies,

        'property_type'=>$request->property_type,
        'star_ratings'=>$request->star_ratings,
        'vehicle_type'=>$request->vehicle_type,

        'budget_range_from'=>$request->budget_range_from,
        'budget_range_to'=>$request->budget_range_to,

        'travel_destination'=>$request->travel_destination,
        'air_tickets' => $airTicket,
        'requirements_for_tour'=>$request->requirements_for_tour,



    ]);


    $bookingId = $bookedTour->id;
    $selectedExcursions = $request->input('selected_excursions');

    SelectedLocations::where('booked_id', $bookingId)->update([
        'location' => $selectedExcursions,
    ]);

    $RegisteredUser = auth()->user();

    $edit_booked_tour=[

        'f_name'=>$RegisteredUser->f_name,
        'l_name'=>$RegisteredUser->l_name,

        'start_date'=>$request->start_date,
        'end_date'=>$request->end_date,
        'number_of_days'=>$request->number_of_days,

        'expected_country'=>$request->expected_country,
        'expected_location'=>$request->expected_location,
        'location' => $selectedExcursions,
        'tour_package'=>$request->tour_package,

        'number_of_people'=>$request->number_of_people,
        'number_of_adults'=>$request->number_of_adults,
        'number_of_children'=>$request->number_of_children,
        'number_of_toddlers'=>$request->number_of_toddlers,
        'number_of_infants'=>$request->number_of_infants,
        'number_of_newborns'=>$request->number_of_newborns,
        'requirements_for_babies'=>$request->requirements_for_babies,

        'property_type'=>$request->property_type,
        'star_ratings'=>$request->star_ratings,
        'vehicle_type'=>$request->vehicle_type,

        'budget_range_from'=>$request->budget_range_from,
        'budget_range_to'=>$request->budget_range_to,

        'travel_destination'=>$request->travel_destination,
        'air_tickets' => $airTicket,
        'requirements_for_tour'=>$request->requirements_for_tour,

    ];
    //var_dump($edit_booked_tour); die();

    Mail::to('adminstarluxe@keenrabbits.biz')->send(new EditBookNowMailRegistered($edit_booked_tour));
    DB::table('email')->insert([
        // 'user_id' => $user->id,
         'title'=>'Booking Tours',
         'subject' => 'EditBookNowMailRegistered',
         'status' => 'unread',
         'created_at' => now(),
         'updated_at' => now(),
     ]);


    // Redirect with success message
    return back()->with(['success' => 'You have successfully updated your tour']);

}

//save book now registered function
    public function saveBookNowRegistered(Request $request)
    {

        $RegisteredUser = auth()->user();

        $airTicket = $request->input('air_tickets');

//        var_dump($RegisteredUser->id); die();
        $booking = BookNow::query()->create([

//            'user_type'=>'tourer',
            'user_id'=>$RegisteredUser->id,

            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
            'number_of_days'=>$request->number_of_days,

            'expected_country'=>$request->expected_country,
            'expected_location'=>$request->expected_location,
            'tour_package'=>$request->tour_package,

            'number_of_people'=>$request->number_of_people,
            'number_of_adults'=>$request->number_of_adults,
            'number_of_children'=>$request->number_of_children,
            'number_of_toddlers'=>$request->number_of_toddlers,
            'number_of_infants'=>$request->number_of_infants,
            'number_of_newborns'=>$request->number_of_newborns,
            'requirements_for_babies'=>$request->requirements_for_babies,

            'property_type'=>$request->property_type,
            'star_ratings'=>$request->star_ratings,
            'vehicle_type'=>$request->vehicle_type,

            'budget_range_from'=>$request->budget_range_from,
            'budget_range_to'=>$request->budget_range_to,

            'travel_destination'=>$request->travel_destination,
            'air_tickets' => $airTicket,
            'requirements_for_tour'=>$request->requirements_for_tour,

        ]);


        $bookingId = $booking->id;
        $selectedExcursions = $request->input('selected_excursions');
        SelectedLocations::create([
            'booked_id' => $bookingId,
            'location' => $selectedExcursions,
        ]);


        $booked_tourist_registered=[

            'f_name'=>$RegisteredUser->f_name,
            'l_name'=>$RegisteredUser->l_name,

            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
            'number_of_days'=>$request->number_of_days,

            'expected_country'=>$request->expected_country,
//            'expected_location'=>$request->expected_location,
            'location' => $selectedExcursions,
            'tour_package'=>$request->tour_package,

            'number_of_people'=>$request->number_of_people,
            'number_of_adults'=>$request->number_of_adults,
            'number_of_children'=>$request->number_of_children,
            'number_of_toddlers'=>$request->number_of_toddlers,
            'number_of_infants'=>$request->number_of_infants,
            'number_of_newborns'=>$request->number_of_newborns,
            'requirements_for_babies'=>$request->requirements_for_babies,

            'property_type'=>$request->property_type,
            'star_ratings'=>$request->star_ratings,
            'vehicle_type'=>$request->vehicle_type,

            'budget_range_from'=>$request->budget_range_from,
            'budget_range_to'=>$request->budget_range_to,

            'travel_destination'=>$request->travel_destination,
            'air_tickets' => $airTicket,
            'requirements_for_tour'=>$request->requirements_for_tour,

        ];


        Mail::to('adminstarluxe@keenrabbits.biz')->send(new BookNowMailRegistered($booked_tourist_registered));

        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Booking Tours',
             'subject' => 'BookNowMailRegistered',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);

        return redirect('/tourist-profile')->with('success','Your tour has been booked successfully.');

    }
//save portfolio function

    public function saveProfile_picture(Request $request)
    {
        $request->validate([
            'profile_pic' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imageProfilePic = $request->file('profile_pic');
        $imageExtension = $imageProfilePic->getClientOriginalExtension();
//        $imageProfilePicture = time() . '.' . $imageExtension;
//        $imageProfilePic->storeAs('public/image/tourer/profile_picture', $imageProfilePicture);

        $imageProfilePicture = time() . mt_rand(100, 999) . '.' . $imageExtension;
        $filePathPP = 'storage/image/tourer/profile_picture/';
        $fullPath = public_path($filePathPP);
        $imageProfilePic->move($fullPath, $imageProfilePicture);

        $user = User::find(auth()->user()->id);

        if ($user) {
            $user->update([
                'profile_pic' => $filePathPP.$imageProfilePicture,
            ]);

            return redirect()->route('tourist-profile')
                ->with('success', 'Your profile picture has been uploaded successfully.')
                ->with('profile_pic', $imageProfilePicture);
        }

        return redirect()->back()->with('error', 'Failed to upload profile picture.');
    }

    //create tourist function
    public function create_tourist($id){

        $booking_id=$id;

        return view('pages.dashboards.create_tourist')->with('booking_id', $booking_id);

    }

    //tour confirmed kist function
    public function touer_confirmed_list(){

        $user = Auth::user();

        // Fetch confirmed bookings related to the current user
        $confirmedBookings = BookNow::where('user_id', $user->id)
            ->where('status', 'Confirmed')
            ->get();


        return view('pages.dashboards.touer_confirmed_list',compact('confirmedBookings'));

    }

    //save booking data function
    public function save_booking_data(Request $request){

        $validatedData = $request->validate([
            'passport_copy.*' => 'required|file|mimes:jpeg,png,jpg,gif,pdf|max:2048',
            'air_tickets_copy.*' => 'required|file|mimes:jpeg,png,jpg,gif,pdf|max:2048',
        ]);

        $bookedId = $request->booked_id;

        $passportCopies = [];
        foreach ($request->file('passport_copy') as $passportCopy) {
            $passportFileName = time() . '_' . $passportCopy->getClientOriginalName();
            $passportCopy->move(public_path('storage/image/tourer/passport/'), $passportFileName);
            $passportCopies[] = 'storage/image/tourer/passport/' . $passportFileName;
        }

        $airTicketCopies = [];
        foreach ($request->file('air_tickets_copy') as $airTicketCopy) {
            $airTicketFileName = time() . '_' . $airTicketCopy->getClientOriginalName();
            $airTicketCopy->move(public_path('storage/image/tourer/air_tickets_copies/'), $airTicketFileName);
            $airTicketCopies[] = 'storage/image/tourer/air_tickets_copies/' . $airTicketFileName;
        }

        BookingConfirmed::create([
            'booked_id' => $bookedId,
            'passport_copy' => json_encode($passportCopies),
            'air_ticket_copy' => json_encode($airTicketCopies)
        ]);

        $tourer_data = [
            'passport_copy' => $passportCopies,
            'air_ticket_copy' => $airTicketCopies
        ];

        // Assuming TourerDocumentUploaded is a Mailable class
        Mail::to('adminstarluxe@keenrabbits.biz')->send(new TourerDocumentUploaded($bookedId, $tourer_data));

        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Tourer Documents',
             'subject' => 'TourerDocumentUploaded',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);

        return redirect()->back()->with('success', 'Documents saved successfully!');

    }


}

<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\User;
use App\Rules\ValidEmailDomain;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    //Admin dashboard view function

    public function admin_dashboard_view()
    {
        if (auth()->check()) {
            // User is logged in, redirect to the admin dashboard
            return view('backend.admin-dashboard-view');
        } else {
            // User is not logged in, redirect to the login form
            return view('backend.admin.admin-login');
        }
    }


    //Admin register  function

    public function admin_register(){

        return view('backend.admin.admin-register');
    }


    //Admin login function

    public function admin_login(){

        return view('backend.admin.admin-login');
    }


    //Admin login check and logout function
    
    public function adminLogout(){

        Session::flush();
        Auth::logout();
        return redirect('admin-login');
    }

//register_admin function

    public function register_admin(Request $request){

        $request->validate([

            'admin_name' => 'required',
            'admin_email' => ['required', 'email', 'unique:users', 'string', new ValidEmailDomain],

            'admin_pass' => 'required|min:6|max:10',

        ]);

        $password=$request->admin_pass;
        $hashedPassword = Hash::make($password);

//        dd($password,$hashedPassword);
        Admin::query()->create([

            'admin_name'=>$request->admin_name,
            'admin_email'=>$request->admin_email,

            'admin_pass'=>$hashedPassword

        ]);

        return redirect('/admin-login')->withSuccess('You are registered successfully');

    }

//    
}

<?php

namespace App\Http\Controllers;

use App\Models\UserCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class TwoFAController extends Controller
{
    //index function

    public function index()
    {
        return view('2fa');
    }


    //store data save function

    public function store(Request $request)
    {
        $request->validate([
            'code' => 'required',
        ]);

        $find = UserCode::where('admin_id', auth('admin')->user()->id)
            ->where('code', $request->code)
            ->where('updated_at', '>=', now()->subMinutes(2))
            ->first();

        if (!is_null($find)) {
            Session::put('admin_2fa', auth('admin')->user()->id);
            return redirect()->route('admin.home'); // Adjust the route for the admin home page
        }

        return back()->with('error', 'You entered the wrong code.');
    }

    //resent function
    public function resend()
    {
        auth('admin')->user()->generateCode();

        return back()->with('success', 'We sent you a code to your email.'); // Adjust the success message
    }



//    
}

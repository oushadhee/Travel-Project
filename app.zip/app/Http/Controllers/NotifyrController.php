<?php

namespace App\Http\Controllers;

use App\Mail\ConfirmQuotationMail;
use App\Mail\NegotiateCommentMail;
use App\Models\BookNow;
use Illuminate\Http\Request;
use App\Models\QuotationDetails;
use App\Models\QuotationPlacesDetails;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\View;


class NotifyrController extends Controller
{
  //quotation notification function
    public function quotation_notification()
    {
        $totalAmounts = []; // Initialize the array

       
        $quotationDetails = QuotationDetails::select('id')->get();

       
        foreach ($quotationDetails as $quotation) {
            $totalAmounts[$quotation->id] = $this->calculateTotalExpense($quotation->id);
        }

        
        return View::make('pages.dashboards.quotation_notification', compact('totalAmounts'));
    }

    //calculatetotalexpense function
    private function calculateTotalExpense($id)
    {
        // Retrieve QuotationDetails for the given ID
        $quotDetails = QuotationDetails::findOrFail($id);

        // Calculate the total expense
        $totalExpense = $quotDetails->air_tickets_expense +
                        $quotDetails->accommodation_expense +
                        $quotDetails->garlands_expense +
                        $quotDetails->vehicle_expense +
                        $quotDetails->guide_expense +
                        $quotDetails->driver_expense;

        // Retrieve QuotationPlacesDetails for the given ID
        $tourQuotation = QuotationPlacesDetails::whereNull('is_deleted')
                            ->where('quotation_id', $id)
                            ->get();

        // Calculate total expense for QuotationPlacesDetails
        foreach ($tourQuotation as $quotation) {
            $totalExpense += $quotation->parking_tickets_expense ?? 0;
            $totalExpense += $quotation->sightseeing_tickets_expense ?? 0;
            $totalExpense += $quotation->highway_tickets_expense ?? 0;
            $totalExpense += $quotation->refreshments_expense ?? 0;
        }

        return $totalExpense;
    }


//amount function
    public function amount($id)
    {
        // Retrieve the total amount for the specified $id
        $totalAmount = $this->calculateTotalExpense($id);

        // Return the total amount as a response
        return $totalAmount;
    }
    
  

    //get notification count function
    public function getNotificationCount()
    {
        $notificationCount = QuotationDetails::whereIn('booked_id', function ($query) {
            $query->select('id')
                ->from('book_nows')
                ->where('user_id', Auth::user()->id);
        })
            ->where('status', 'Submitted to Tourist')
            ->where('status2', 'unread')
            ->count();

        return response()->json(['count' => $notificationCount]);
    }

    //marknotification read function
    public function markNotificationAsRead(Request $request)
    {
        $notificationId = $request->input('notification_id');

        // $notification = QuotationDetails::find($notificationId);
        // if ($notification) {
        //     $notification->status2 = 'read';
        //     $notification->save();
        $notification = QuotationDetails::find($notificationId);
        if ($notification && $notification->status2 === 'unread') {
            $notification->status2 = 'read';
            $notification->save();

            return response()->json(['success' => true, 'message' => 'Notification marked as read.']);
        }

        return response()->json(['success' => false, 'message' => 'Notification not found.']);
    }

//quotation comment function
    public function quotation_comments($id)
    {

        return view('pages.dashboards.quotation_comments', compact('id'));
    }

        //add negotiate comment function

    public function add_negotiate_comment(Request $request)
    {
        $request->validate([
            'quotation_id' => 'required|integer',
            'message' => 'required',
        ]);

        $quotationId = (int) $request->input('quotation_id');
        $comments = $request->input('message');

        // Update the status column in the quotation_details table
        DB::table('quotation_details')
            ->where('id', $quotationId)
            ->update(['status' => 'Negotiated by Tourist']);

        // Insert the negotiate_details
        $query = DB::table('negotiate_details')->insert([
            'quotation_id' => $quotationId,
            'comments' => $comments,
        ]);

        if ($query) {

            $bookedId = DB::table('quotation_details')
                ->where('id', $quotationId)
                ->value('booked_id');

            $bookNow = BookNow::find($bookedId);
            if ($bookNow) {
                $bookNow->status = 'Negotiating';
                $bookNow->save();
            }
            $this->sendNegotiateCommentMail($quotationId, $comments);
            return back()->with('success', 'Your Comments Successfuly added.');
        } else {
            return back()->with('fail', 'Something went wrong.');
        }
    }

   // sendnegotiatecommentmail function
    protected function sendNegotiateCommentMail($quotationId, $comments)
    {
        $bookedId = DB::table('quotation_details')
            ->where('id', $quotationId)
            ->value('booked_id');



        $userId = DB::table('book_nows')
            ->where('id', $bookedId)
            ->value('user_id');

        $userName = DB::table('users')
                ->where('id', $userId)
                ->value('f_name') . ' ' . DB::table('users')->where('id', $userId)->value('l_name');


        $data = [
            'quotation_id' => $quotationId,
            'comments' => $comments,
            'user_name' => $userName,
        ];

        Mail::to('adminstarluxe@keenrabbits.biz')->send(new NegotiateCommentMail($data));
        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Quotations Mails',
             'subject' => 'NegotiateCommentMail',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);
    }

//confirm button details
    public function status_confirm(Request $request)
    {

        $id = $request->input('id');
        $quotationDetail = QuotationDetails::find($id);

        if (!$quotationDetail) {

        }

        $quotationDetail->status = 'Confirmed by Tourist';
        $quotationDetail->save();

        $bookedId = $quotationDetail->booked_id;
        //new add
        $bookNow = BookNow::find($bookedId);
        if ($bookNow) {
            $bookNow->status = 'Confirmed';
            $bookNow->save();
        }

        $userId = DB::table('book_nows')
            ->where('id', $bookedId)
            ->value('user_id');

        $userName = DB::table('users')
                ->where('id', $userId)
                ->value('f_name') . ' ' . DB::table('users')->where('id', $userId)->value('l_name');

        $data = [
            'quotation_id' => $id,
            'user_name' => $userName,
        ];


        Mail::to('adminstarluxe@keenrabbits.biz')->send(new ConfirmQuotationMail( $data));

        DB::table('email')->insert([
            // 'user_id' => $user->id,
             'title'=>'Quotations Mails',
             'subject' => 'ConfirmQuotationMail',
             'status' => 'unread',
             'created_at' => now(),
             'updated_at' => now(),
         ]);

        return back()->with('success', 'Confiranmation Succseesfully Update.');

        // Redirect or return a response as needed
    }


    //tourer payment function
    public function tourer_payment()
{
    $totalAmounts = [];
    $quotationDetails = QuotationDetails::select('id')->get();

    foreach ($quotationDetails as $quotation) {
        $totalAmounts[$quotation->id] = $this->calculatePayment($quotation->id);
    }

    return View::make('pages.dashboards.tourer_payment', compact('totalAmounts'));
}

//calculatepayment function
            private function calculatePayment($id)
            {

                $quotDetails = QuotationDetails::findOrFail($id);

                // Calculate the total expense
                $totalExpense = $quotDetails->air_tickets_expense +
                                $quotDetails->accommodation_expense +
                                $quotDetails->garlands_expense +
                                $quotDetails->vehicle_expense +
                                $quotDetails->guide_expense +
                                $quotDetails->driver_expense;

                // Retrieve QuotationPlacesDetails for the given ID
                $tourQuotation = QuotationPlacesDetails::whereNull('is_deleted')
                                    ->where('quotation_id', $id)
                                    ->get();

                // Calculate total expense for QuotationPlacesDetails
                foreach ($tourQuotation as $quotation) {
                    $totalExpense += $quotation->parking_tickets_expense ?? 0;
                    $totalExpense += $quotation->sightseeing_tickets_expense ?? 0;
                    $totalExpense += $quotation->highway_tickets_expense ?? 0;
                    $totalExpense += $quotation->refreshments_expense ?? 0;
                }
                return $totalExpense;
            }


//payment function
        public function payment($id)
    {
        // Retrieve the total amount for the specified $id
        $totalAmount = $this->calculateTotalExpense($id);

        // Return the total amount as a response
        return $totalAmount;
    }


}





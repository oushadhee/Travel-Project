<?php

namespace App\Http\Controllers;

use App\Models\Gallery;
use App\Models\Review;
use Illuminate\Http\Request;
use App\Models\QuotationDetails;
use Illuminate\Support\Facades\File;

class ReviewController extends Controller
{

    //jot review function
    public function jot_reviews(Request $request)
{
 $validatedData = $request->validate([
    'tour_type' => 'required|string|in:Cultural,Wildlife,Eco',
    'rating' => 'required|integer|min:1|max:5',
    'comment_jot' => 'required|string|max:1000',
    'suggestions_jot' => 'required|string|max:1000',
    'start_date' => 'required|date',
    'end_date' => 'required|date|after_or_equal:start_date',
    'country' => 'required|string|max:255',
    'tour_photos.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
    'tour_category_id' => 'nullable|integer|exists:tour_categories,id',
]);


    $user = auth()->user();
    $photoPaths = [];

    if ($request->hasFile('tour_photos')) {
        foreach ($request->file('tour_photos') as $tourImage) {
            $imageExtension = $tourImage->getClientOriginalExtension();
            $fileName = time() . mt_rand(100, 999) . '.' . $imageExtension;

            $filePath = 'storage/image/admin/gallery/tourer/';
            $tourImage->move(public_path($filePath), $fileName);

            $photoPaths[] = $filePath . $fileName;

            // Optionally save to Gallery here if you want
        }
    }

   Review::create([
    'user_id' => $user->id,
    'tour_category_id' => $request->tour_category_id,
    'tour_type' => $request->tour_type,
    'comment_jot' => $request->comment_jot,
    'suggestions_jot' => $request->suggestions_jot,
    'rating' => $request->rating,
    'start_date' => $request->start_date,
    'end_date' => $request->end_date,
    'country' => $request->country,
    'tour_photos' => json_encode($photoPaths),
]);


    return redirect('/tourist-profile')->with('success', 'Your comments and images are successfully saved');
}

    //guide reviews function

    public function guide_reviews(Request $request)
    {
//    var_dump('yes 1');
        $request->validate([

            'selected_guide' => 'required',
            'comment_guide' => 'required',
            'suggestions_guide' => 'required',
            'rating' => 'required',

        ]);

        Review::query()->create([

            'user_id'=>$request->id,
            'selected_guide'=>$request->selected_guide,
            'comment_guide'=>$request->comment_guide,
            'suggestions_guide'=>$request->suggestions_guide,
            'rating' => $request->rating,

        ]);

        return redirect('/tourist-profile')->with('success','Your comments are successfully Saved');

    }

    //guide tour images function
    public function guide_tour_images(Request $request)
    {
        $request->validate([
            'start_date' => 'required',
            'end_date' => 'required',
            'tour_photos.*' => 'required|image|mimes:jpeg,png,jpg,gif', // Assuming these are image files
        ]);

        $user = auth()->user();

        foreach ($request->file('tour_photos') as $guideImage) {
            $imageExtension = $guideImage->getClientOriginalExtension();
            $guideTourImagesSave =  time() . mt_rand(100, 999) . '.' . $imageExtension;

            $filePath = 'storage/image/admin/gallery/guide/';
            $fullPath = public_path($filePath);

            $guideImage->move($fullPath, $guideTourImagesSave);

            Gallery::create([
                'user_id' => $user->id, // Using the authenticated user's ID
                'start_date' => $request->start_date,
                'end_date' => $request->end_date,
                'tour_photos' => $filePath . $guideTourImagesSave,
            ]);
        }

        return redirect('/guide-profile')->with('success', 'Your images are successfully Saved');
    }

   //pay reviews function

    public function pay_reviews(Request $request)
    {
        $request->validate([
            'id' => 'required|exists:quotation_details,id',
            'swift_copy.*' => 'required|image|mimes:jpeg,png,jpg,gif', // Assuming these are image files
        ]);

        $id = $request->input('id');
        $user = auth()->user();

        foreach ($request->file('swift_copy') as $swiftImage) {
            $imageExtension = $swiftImage->getClientOriginalExtension();
            $swiftSwiftImagesSave = time() . mt_rand(100, 999) . '.' . $imageExtension;

            $filePath = 'storage/image/admin/payment/swift/';
            $fullPath = public_path($filePath);

            $swiftImage->move($fullPath, $swiftSwiftImagesSave);

            // Update or save the 'swift_copy' column in the 'quotation_details' table
            $quotationDetails = QuotationDetails::findOrFail($id);
            $quotationDetails->swift_copy = $filePath . $swiftSwiftImagesSave;
            $quotationDetails->save();

            return redirect('/tourer_payment')->with('success', 'Your swift copy successfully saved.' );
        }

    }

    //edit image function

    public function edit_image($id)
    {
        $quotationDetails = QuotationDetails::findOrFail($id);
        return view('edit_image', compact('quotationDetails'));
    }


    //uplord image function
    public function update_image(Request $request, $id)
    {
        $request->validate([
            'swift_copy' => 'required|image|mimes:jpeg,png,jpg,gif', // Assuming these are image files
        ]);

        $quotationDetails = QuotationDetails::findOrFail($id);

        // Delete the existing image file
        if (File::exists($quotationDetails->swift_copy)) {
            File::delete($quotationDetails->swift_copy);
        }

        $swiftImage = $request->file('swift_copy');
        $imageExtension = $swiftImage->getClientOriginalExtension();
        $swiftSwiftImageSave = time() . mt_rand(100, 999) . '.' . $imageExtension;

        $filePath = 'storage/image/admin/payment/swift/';
        $fullPath = public_path($filePath);

        $swiftImage->move($fullPath, $swiftSwiftImageSave);

        // Update the 'swift_copy' column in the 'quotation_details' table
        $quotationDetails->swift_copy = $filePath . $swiftSwiftImageSave;
        $quotationDetails->save();

        return redirect('/tourer_payment')->with('success', 'Image updated successfully.');
    }

}

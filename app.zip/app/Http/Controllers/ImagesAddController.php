<?php

namespace App\Http\Controllers;

use App\Models\Gallery;
use Illuminate\Http\Request;

class ImagesAddController extends Controller
{
    //add image function

    public function addImages(Request $request){

        $imageGallery=$request->file('image');
        $imageDataGallery=$imageGallery->getClientOriginalName();
        $imageGallery->storeAs('public/image/admin/gallery',$imageDataGallery);

        Gallery::query()->create([

            'place_name'=>$request->place_name,
            'map_link'=>$request->map_link,
            'image'=>$imageDataGallery,

        ]);

        return redirect('/add-images')->withSuccess('You are registered successfully');

    }

    
}

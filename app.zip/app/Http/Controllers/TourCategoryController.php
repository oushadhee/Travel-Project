<?php

namespace App\Http\Controllers;


use App\Models\TourCategory;
use App\Models\Country;
use Illuminate\Http\Request;

class TourCategoryController extends Controller
{
    //addtourcategory function

    public function addTourCategory(Request $request)
    {

        $imageTourCategory = $request->file('tour_image');
        $imageDataTourCategory = $imageTourCategory->getClientOriginalName();
        $imageTourCategory->storeAs('public/image/admin/tour_category', $imageDataTourCategory);

        TourCategory::query()->create([

            'category_name' => $request->category_name,
            'parent_id' => $request->parent_id,
            'description' => $request->description,
            'tour_image' => $imageDataTourCategory

        ]);

        return redirect('/add-tour-category')->withSuccess('You are registered successfully');
    }

//countrytours functon
    public function countryTours($id)
    {
      
        $country = Country::findOrFail($id);
        $tourCategories = $country->activeTourCategories()->get();
        
        
        return view('pages.tours.country_tours', compact('country', 'tourCategories'));
    }

    //category tours function
    public function categoryTours($id)
    {
        
        $category = TourCategory::findOrFail($id);
        $country = $category->country;
        
      
        
        return view('pages.tours.country_categories', compact('category', 'country'));

    }
}
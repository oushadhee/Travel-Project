<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Models\Country;
use App\Models\TourCategory;
use App\Models\Tour;


class TourController extends Controller
{
 

//Country wise tours controller

// public function countryTours($id)
// {
//     $country = \App\Models\Country::findOrFail($id);
//     $tours = \App\Models\Tour::with('country')
//                 ->where('country_id', $id)
//                 ->whereNull('is_deleted')
//                 ->get();

//     return view('pages.tours.country_tours', compact('country', 'tours'));
// }


// public function countryTours($id)
// {
//     $country = \App\Models\Country::findOrFail($id);

//     // Fetch tour categories for the country
//     $tourCategories = \App\Models\TourCategory::where('country_id', $id)
//                         ->where(function ($query) {
//                             $query->whereNull('is_deleted')
//                                   ->orWhere('is_deleted', '!=', 'yes');
//                         })
//                         ->get();

//     return view('pages.tours.country_tours', compact('country', 'tourCategories'));
// }


public function showByCountryAndCategory($country_id, $category_id)
{
    $tours = \App\Models\Tour::where('country_id', $country_id)
        ->where('main_category_id', $category_id)
        ->whereNull('is_deleted')
        ->get();

    return view('pages.tours.category_view', compact('tours'));
}


//country category function

public function countryCategories($country_id)
{
    $country = \App\Models\Country::findOrFail($country_id);
    
    $categories = \App\Models\TourCategory::where('country_id', $country_id)
                    ->whereNull('parent_id') // main categories only
                    ->where('status', 'active')
                    ->get();

    return view('pages.tours.country_categories', [
        'country' => $country,
        'categories' => $categories
    ]);
}
//catgeory tours function
public function categoryTours($country_id, $category_id)
{
    $country = Country::findOrFail($country_id);
    $category = TourCategory::findOrFail($category_id);
    
    $tours = Tour::where('country_id', $country_id)
                ->where('main_category_id', $category_id) // Changed to main_category_id
                ->where('status', 'active')
                ->with(['images', 'inclusions'])
                ->paginate(12);

    return view('pages.tours.categorytours', [
        'country' => $country,
        'category' => $category,
        'tours' => $tours
    ]);
}

}
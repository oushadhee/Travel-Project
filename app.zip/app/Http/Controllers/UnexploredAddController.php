<?php

namespace App\Http\Controllers;

use App\Models\Unexplored;
use Illuminate\Http\Request;

class UnexploredAddController extends Controller
{
    //add unexplored details function

    public function addUnexploredDetails(Request $request){

        $imageUnexplored=$request->file('image');
        $imageDataUnexplored=$imageUnexplored->getClientOriginalName();
        $imageUnexplored->storeAs('public/image/admin/unexplored',$imageDataUnexplored);

        Unexplored::query()->create([

            'unexplored_name'=>$request->unexplored_name,
            'district'=>$request->district,
            'province'=>$request->province,
            'description'=>$request->description,
            'map_link'=>$request->map_link,
            'image'=>$imageDataUnexplored,

        ]);

        return redirect('/add-unexplored')->withSuccess('You are registered successfully');

    }
}

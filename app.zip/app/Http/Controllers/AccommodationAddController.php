<?php

namespace App\Http\Controllers;

use App\Models\Accommodation;
use Illuminate\Http\Request;

class AccommodationAddController extends Controller
{
    
//Add accommodation details function
    public function addAccommodationDetails(Request $request){

        $imageAccommodation=$request->file('image');
        $imageDataAccommodation=$imageAccommodation->getClientOriginalName();
        $imageAccommodation->storeAs('public/image/admin/accommodation',$imageDataAccommodation);

        Accommodation::query()->create([

            'hotel_name'=>$request->hotel_name,
            'description'=>$request->description,
            'image'=>$imageDataAccommodation,

        ]);

        return redirect('/add-accommodation')->withSuccess('You are registered successfully');

    }
}

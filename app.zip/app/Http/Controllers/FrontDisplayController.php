<?php

namespace App\Http\Controllers;

use App\Models\Tour;
use App\Models\TourCategory;
use App\Models\Country;
use App\Models\TourMoreDetails;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\GuideDetails;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class FrontDisplayController extends Controller
{
    public function home()
    {
        $guideCount = GuideDetails::count();
        $customerCount = User::count();
        $tourCount = Tour::count();
        $tourCategoryCount = TourCategory::count();

        // Count tours for each category using main_category_id
        $culturalTourCount = Tour::where('main_category_id', 1)->whereNull('is_deleted')->count();
        $wildlifeTourCount = Tour::where('main_category_id', 2)->whereNull('is_deleted')->count();
        $ecoTourCount = Tour::where('main_category_id', 3)->whereNull('is_deleted')->count();

        // Fetch tours to display in the carousel or deals section
        $tours = Tour::whereNull('is_deleted')->orderByDesc('updated_at')->take(6)->get();

        // Fetch tours for Wildlife and Eco Tours sections
        $wildlife_tours = Tour::where('main_category_id', 2)->whereNull('is_deleted')->orderByDesc('updated_at')->take(6)->get();
        $eco_tours = Tour::where('main_category_id', 3)->whereNull('is_deleted')->orderByDesc('updated_at')->take(6)->get();

        // Fetch the latest tour with image per main category
        $culturalTour = Tour::where('main_category_id', 1)
            ->whereNull('is_deleted')
            ->whereNotNull('tour_image')
            ->inRandomOrder()
            ->first();

        $wildlifeTour = Tour::where('main_category_id', 2)
            ->whereNull('is_deleted')
            ->whereNotNull('tour_image')
            ->inRandomOrder()
            ->first();

        $ecoTour = Tour::where('main_category_id', 3)
            ->whereNull('is_deleted')
            ->whereNotNull('tour_image')
           ->inRandomOrder()
            ->first();

            

        // Debug Eco Tour data
        Log::info('Eco Tour Data:', [$ecoTour ? $ecoTour->toArray() : 'No Eco Tour found']);

        return view('pages.index', [
            'guide_count' => $guideCount,
            'customer_count' => $customerCount,
            'tour_count' => $tourCount,
            'tour_category_count' => $tourCategoryCount,
            'cultural_tour_count' => $culturalTourCount,
            'wildlife_tour_count' => $wildlifeTourCount,
            'eco_tour_count' => $ecoTourCount,
            'tours' => $tours,
            'wildlife_tours' => $wildlife_tours,
            'eco_tours' => $eco_tours,
            'cultural_tour' => $culturalTour,
            'wildlife_tour' => $wildlifeTour,
            'eco_tour' => $ecoTour,
        ]);
    }

    public function excursions()
    {
        return view('pages.nav-bar-pages.excursions', ['excursions' => \App\Models\Excursion::whereNull('is_deleted')->get()]);
    }

    public function unexplored()
    {
        return view('pages.nav-bar-pages.unexplored', ['unexplored' => \App\Models\Unexplored::whereNull('is_deleted')->get()]);
    }

    public function special_events()
    {
        return view('pages.nav-bar-pages.special-events', ['special_events' => \App\Models\Event::whereNull('is_deleted')->get()]);
    }

    public function all_activities()
    {
        return view('pages.activities.all-activities', [
            'all_activities_display' => \App\Models\ActivityCategory::where('parent_id', 0)->get(),
        ]);
    }

    public function adventure()
    {
        return view('pages.activities.adventure', [
            'adventure' => \App\Models\ActivityCategory::whereNull('is_deleted')->get(),
        ]);
    }

    public function fun()
    {
        return view('pages.activities.fun', ['fun' => \App\Models\Activity::whereNull('is_deleted')->where('main_category_id', 2)->get()]);
    }

    public function park()
    {
        return view('pages.activities.park', ['park' => \App\Models\Activity::whereNull('is_deleted')->where('main_category_id', 3)->get()]);
    }

    public function activities_place_display($id)
{
    $title = \App\Models\ActivityCategory::where('id', $id)->first(); // Get one, not a collection
    return view('pages.activities.activities-place-display', [
        'activity' => \App\Models\Activity::whereNull('is_deleted')->where('sub_category_id', $id)->get(),
        'title' => $title, // Pass as object, not array
    ]);
}


    public function all_tours()
    {
        $all_tours_display = TourCategory::where('parent_id', 0)->get();
        $country = null;
        if ($all_tours_display->isNotEmpty()) {
            $first = $all_tours_display->first();
            $country = $first->country ?? null;
        }
        return view('pages.tours.all-tours', [
            'all_tours_display' => $all_tours_display,
            'country' => $country,
        ]);
    }

    public function allCountry()
    {
        $all_countries_display = Country::whereHas('tourCategories', function ($query) {
            $query->whereNotNull('country_id');
        })->get();
        return view('pages.tours.all-country', compact('all_countries_display'));
    }

    public function allsubtours(Request $request)
    {
        $countryId = $request->id;
        $country = Country::findOrFail($countryId);
        $all_tours_display = TourCategory::where('country_id', $countryId)
            ->where('parent_id', 0)
            ->get();
        return view('pages.tours.all-tours', compact('country', 'all_tours_display'));
    }

    public function cultural_tours($id)
    {
        $title = \App\Models\TourCategory::where('id', $id)->get();
        return view('pages.tours.cultural-tours', [
            'cultural_tours' => \App\Models\TourCategory::where('parent_id', $id)->get(),
            'tittle' => $title,
        ]);
    }

    public function cultural_tours_display($id)
    {
        $title = \App\Models\TourCategory::where('id', $id)->get();
        return view('pages.tours.tour-packages.cultural-tours-display', [
            'tours' => \App\Models\Tour::whereNull('is_deleted')->where('sub_category_id', $id)->get(),
            'tittle' => $title,
        ]);
    }

   public function get_path($id)
{
    $getTour = Tour::find($id);
    $mainCategoryID = $getTour->main_category_id;
    $subCategoryID = $getTour->sub_category_id;
    $getMainCategory = TourCategory::where('id', $mainCategoryID)->get()->toArray();
    $getSubCategories = TourCategory::where('id', $subCategoryID)->get();
    $title = \App\Models\Tour::where('id', $id)->get();

    // Determine the route based on main_category_id
    switch ($mainCategoryID) {
        case 1:
            $route = route('tour_categories', ['id' => $mainCategoryID]);
            break;
        case 2:
            $route = route('wildlife-tours');
            break;
        case 3:
            $route = route('eco-tours');
            break;
        case 38:
            $route = route('business-tours');
            break;
        case 41:
            $route = route('medical-n-wellness');
            break;
        case 47:
            $route = route('sport-tours');
            break;
        case 56:
            $route = route('educational-tours');
            break;
        default:
            $route = '#'; // Fallback
            break;
    }

    return [
        'tour_details' => TourMoreDetails::whereNull('is_deleted')->where('tour_id', $id)->get(),
        'MainCategories' => $getMainCategory,
        'sub_categories' => $getSubCategories,
        'tittle' => $title,
        'category_name' => $getSubCategories[0]->category_name ?? 'Category',
        'main_category_name' => $getMainCategory[0]['category_name'] ?? 'Main Category',
        'route' => $route, // Add the computed route to the returned data
    ];
}

    public function tours_display($id)
    {
        $data = $this->get_path($id);
        return view('pages.tours.tour-package-details.tour-package-details-display', $data);
    }

    public function wildlife_tours()
    {
        return view('pages.tours.wildlife-tours', ['wildlife_tours' => \App\Models\TourCategory::where('parent_id', 2)->get()]);
    }

    public function wildlife_tours_display($id)
    {
        $title = \App\Models\TourCategory::where('id', $id)->pluck('category_name');
        return view('pages.tours.tour-packages.wildlife-tours-display', [
            'tours' => \App\Models\Tour::whereNull('is_deleted')->where('sub_category_id', $id)->get(),
            'tittle' => $title,
        ]);
    }

    public function eco_tours()
    {
        return view('pages.tours.eco-tours', ['eco_tours' => \App\Models\TourCategory::where('parent_id', 3)->get()]);
    }

    public function eco_tours_display($id)
    {
        $title = \App\Models\TourCategory::where('id', $id)->pluck('category_name');
        return view('pages.tours.tour-packages.eco-tours-display', [
            'tours' => \App\Models\Tour::whereNull('is_deleted')->where('sub_category_id', $id)->get(),
            'tittle' => $title,
        ]);
    }

    public function business_tours()
    {
        return view('pages.tours.business-tours', ['business_tours' => \App\Models\TourCategory::where('parent_id', 14)->get()]);
    }

    public function medical_n_wellness()
    {
        return view('pages.tours.medical-n-wellness', ['medical_n_wellness' => \App\Models\TourCategory::where('parent_id', 15)->get()]);
    }

    public function educational_tours()
    {
        return view('pages.tours.educational-tours', ['educational_tours' => \App\Models\TourCategory::where('parent_id', 16)->get()]);
    }

    public function culinary_tours()
    {
        return view('pages.tours.culinary-tours', ['culinary_tours' => \App\Models\TourCategory::where('parent_id', 17)->get()]);
    }

    public function sport_tours()
    {
        return view('pages.tours.sport-tours', ['sport_tours' => \App\Models\TourCategory::where('parent_id', 18)->get()]);
    }
}
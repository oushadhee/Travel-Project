<?php

namespace App\Http\Controllers;



use App\Models\Tour;
use App\Models\User;
use Illuminate\Http\Request;

class ToursAddController extends Controller
{
    //add tour function
    public function addTour(Request $request){

        return view('backend.sidebar.tours.add-tour');
    }
    public function fetch_tour_category(Request $request){
        $data = "<option value='null' disabled selected>Choose Sub Category</option>";
        if($request->ajax()) {
            foreach (\App\Models\TourCategory::where('parent_id', $request->id)->orderby('category_name', 'asc')->get() as $row) {
                $data .= "<option value='" . $row->category_name . "' data-id='".$row->id."'>" . $row->category_name . "</option>";
            }
        }
        return response()->json($data);
    }

    //add tour details function
    public function addTourDetails(Request $request){

        $imageTour=$request->file('tour_image');
        $imageDataTour=$imageTour->getClientOriginalName();
        $imageTour->storeAs('public/image/admin/tours',$imageDataTour);

        Tour::query()->create([

            'tour_name'=>$request->tour_name,
            'main_category_id'=>$request->main_category_id,
            'sub_category_id'=>$request->sub_category_id,
            'description'=>$request->description,
            'tour_image'=>$imageDataTour,

        ]);

        return redirect('/add-tour')->withSuccess('You are registered successfully');

    }
}

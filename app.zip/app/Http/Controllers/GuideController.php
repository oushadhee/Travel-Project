<?php

namespace App\Http\Controllers;

use App\Mail\GuideRegisteredMail;
use App\Mail\TouristRegisteredMail;
use App\Models\GuideDetails;
use App\Models\User;
use App\Models\Vehicle;
use App\Models\Review;
use App\Models\Gallery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class GuideController extends Controller
{
    //guide profile function

    public function guide_profile()
    {
        //new code guider comment
        $comments = Review::where('selected_guide', Auth::user()->id)->get();
        return view('pages.dashboards.guide-profile', ['comments' => $comments]);
    }

    //guide profile edit function
    public function guide_profile_edit()
    {
        return view('pages.dashboards.guide-profile-edit');
    }

    //guid eprofile display function
    public function guide_profile_display($id)
    {
        $images = Gallery::where('user_id', $id)
            ->whereNull('galleries.is_deleted')
            ->join('users', 'galleries.user_id', '=', 'users.id')
            ->where('users.user_type', 'guide')
            ->get();


        $comments = Review::where('selected_guide',$id)->get();

        $guideName = \App\Models\User::find($id);

        return view('pages.dashboards.guide-profile-display', compact('images', 'comments', 'guideName'));
    }

    //register function
    public function register(){

        return view('pages.nav-bar-pages.guide-registration');
    }

    //login function
    public function login(){

        return view('pages.nav-bar-pages.login');
    }

//    public function logout_guide(){
//        var_dump('yes'); die();
//        Auth::logout();
//        return redirect('/login');
//
//    }

//    public function registerGuide(Request $request){
//
//        //var_dump($request->all());die();
//
//        $request->validate([
//
//            'f_name' => 'required',
//            'l_name' => 'required',
////            'country_code_1' => 'required',
////            'm_phone_1_country_code' => 'required',
//            'm_phone_1' => 'required',
////            'country_code_2' => 'required',
////            'm_phone_2_country_code' => 'required',
//            'm_phone_2' => 'required',
//            'email' => 'required',
//            'address' => 'required',
////            'l_number_country_code' => 'required',
//            'l_number' => 'required',
//            'ec_name' => 'required',
////            'ec_number_country_code' => 'required',
//            'ec_number' => 'required',
//
////            'about' => 'required',
////            //'language' => 'required',
//////            'languages' => 'required|array',
////            'w_experience' => 'required',
////            'guides_photos_pass_size' => 'required',
////            'guides_photos_normal' => 'required',
////            'guide_license_f' => 'required',
////            'guide_license_b' => 'required',
////            'driving_license_f' => 'required',
////            'driving_license_b' => 'required',
////            'nic_f' => 'required',
////            'nic_b' => 'required',
////            'guide_category' => 'required',
////
////            'fileToUpload_v_insurance_f' => 'required',
////            'fileToUpload_v_insurance_b' => 'required',
////            'v_book_f' => 'required',
////            'v_book_b' => 'required',
////            'end_date_insurance' => 'required',
////            'vehicle_type' => 'required',
////            'v_model' => 'required',
////            'v_number' => 'required',
////            'v_out__front_images' => 'required',
////            'v_out_back_images' => 'required',
////            'v_out_right_images' => 'required',
////            'v_out_left_images' => 'required',
////            'v_in_front_images' => 'required',
////            'v_in_back_images' => 'required',
////            'vehicle_rent_own' => 'required',
//
////            'password' => 'required|max:8|min:6|confirmed',
//
//        ]);
//
//      //var_dump('yes');die();
//
//        //dd($request->all());
//        $password=$request->password;
//        $hashedPassword = Hash::make($password);
//
//        $imageFront=$request->file('v_out__front_images');
//        $imageNameFront=$imageFront->getClientOriginalName();
//        $imageFront->storeAs('public/image/guide/vehicle/front',$imageNameFront);
//
//        $imageBack=$request->file('v_out_back_images');
//        $imageNameBack=$imageBack->getClientOriginalName();
//        $imageBack->storeAs('public/image/guide/vehicle/back',$imageNameBack);
//
//        $imageLeft=$request->file('v_out_left_images');
//        $imageNameLeft=$imageLeft->getClientOriginalName();
//        $imageLeft->storeAs('public/image/guide/vehicle/left',$imageNameLeft);
//
//        $imageRight=$request->file('v_out_right_images');
//        $imageNameRight=$imageRight->getClientOriginalName();
//        $imageRight->storeAs('public/image/guide/vehicle/right',$imageNameRight);
//
//        $imageIN_Front=$request->file('v_in_front_images');
//        $imageNameInFront=$imageIN_Front->getClientOriginalName();
//        $imageIN_Front->storeAs('public/image/guide/vehicle/inside/front',$imageNameInFront);
//
//        $imageIN_Back=$request->file('v_in_back_images');
//        $imageNameInBack=$imageIN_Back->getClientOriginalName();
//        $imageIN_Back->storeAs('public/image/guide/vehicle/inside/back',$imageNameInBack);
//
//        $pdf_v_insurance_f=$request->file('fileToUpload_v_insurance_f');
//        $pdfName_v_insurance_f=$pdf_v_insurance_f->getClientOriginalName();
//        $pdf_v_insurance_f->storeAs('public/document/guide/insurance/front',$pdfName_v_insurance_f);
//
//        $pdf_v_insurance_b=$request->file('fileToUpload_v_insurance_b');
//        $pdfName_v_insurance_b=$pdf_v_insurance_b->getClientOriginalName();
//        $pdf_v_insurance_b->storeAs('public/document/guide/insurance/back',$pdfName_v_insurance_b);
//
//        $pdf_v_book_f=$request->file('v_book_f');
//        $pdfName_v_book_f=$pdf_v_book_f->getClientOriginalName();
//        $pdf_v_book_f->storeAs('public/document/guide/v_book/front',$pdfName_v_book_f);
//
//        $pdf_v_book_b=$request->file('v_book_b');
//        $pdfName_v_book_b=$pdf_v_book_b->getClientOriginalName();
//        $pdf_v_book_b->storeAs('public/document/guide/v_book_b',$pdfName_v_book_b);
//
//        //----------------------------------------------------------------------
//
//        $imagePassportSize=$request->file('guides_photos_pass_size');
//        $imageNamePassportSize=$imagePassportSize->getClientOriginalName();
//        $imagePassportSize->storeAs('public/image/guide/personal/passport_size',$imageNamePassportSize);
//
//        $imageGuideNormal=$request->file('guides_photos_normal');
//        $imageNamePassportSize=$imageGuideNormal->getClientOriginalName();
//        $imageGuideNormal->storeAs('public/image/guide/personal/normal',$imageNamePassportSize);
//
//        $pdf_guide_license_f=$request->file('guide_license_f');
//        $pdfName_guide_license_f=$pdf_guide_license_f->getClientOriginalName();
//        $pdf_guide_license_f->storeAs('public/document/guide/guide_license/front',$pdfName_guide_license_f);
//
//        $pdf_guide_license_b=$request->file('guide_license_b');
//        $pdfName_guide_license_b=$pdf_guide_license_b->getClientOriginalName();
//        $pdf_guide_license_b->storeAs('public/document/guide/guide_license/back',$pdfName_guide_license_b);
//
//        $pdf_driving_license_f=$request->file('driving_license_f');
//        $pdfName_driving_license_f=$pdf_driving_license_f->getClientOriginalName();
//        $pdf_driving_license_f->storeAs('public/document/guide/personal/driving_license/front',$pdfName_driving_license_f);
//
//        $pdf_driving_license_b=$request->file('driving_license_b');
//        $pdfName_driving_license_b=$pdf_driving_license_b->getClientOriginalName();
//        $pdf_driving_license_b->storeAs('public/document/guide/personal/driving_license/back',$pdfName_driving_license_b);
//
//        $pdf_nic_f=$request->file('nic_f');
//        $pdfName_nic_f=$pdf_nic_f->getClientOriginalName();
//        $pdf_nic_f->storeAs('public/document/guide/personal/nic/front',$pdfName_nic_f);
//
//        $pdf_nic_b=$request->file('nic_b');
//        $pdfName_nic_b=$pdf_nic_b->getClientOriginalName();
//        $pdf_nic_b->storeAs('public/document/guide/personal/nic/back',$pdfName_nic_b);
//
//
//////dd($imageName);
////
//        //$image->move(public_path('images/guide/guide_images'),$imageName);
//
////dd($imagePath);
//        //var_dump('yes');die();
//
//        $User=User::query()->create([
//
//            'user_type'=>'guide',
//            'f_name'=>$request->f_name,
//            'l_name'=>$request->l_name,
////            'country_code_1'=>'+94',
//            'm_phone_1_country_code'=>$request->m_phone_1_country_code,
//            'm_phone_1'=>$request->m_phone_1,
//            'm_phone_2_country_code'=>$request->m_phone_2_country_code,
//            'm_phone_2'=>$request->m_phone_2,
//            'email'=>$request->email,
//            'address'=>$request->address,
//            'country'=>'null',
//            'l_number_country_code'=>$request->l_number_country_code,
//            'l_number'=>$request->l_number,
//            'ec_name'=>$request->ec_name,
//            'ec_number_country_code'=>$request->ec_number_country_code,
//            'ec_number'=>$request->ec_number,
//
//            'password'=>$hashedPassword
//        ]);
//        //dd($User);
//
//        Vehicle::query()->create([
//
//            'user_id'=>$User->id,
//            'fileToUpload_v_insurance_f'=>$pdfName_v_insurance_f,
//            'fileToUpload_v_insurance_b'=>$pdfName_v_insurance_b,
//            'v_book_f'=>$pdfName_v_book_f,
//            'v_book_b'=>$pdfName_v_book_b,
//            'end_date_insurance'=>$request->end_date_insurance,
//            'vehicle_type'=>$request->vehicle_type,
//            'v_model'=>$request->v_model,
//            'v_number'=>$request->v_number,
//            'v_out__front_images'=>$imageNameFront,
//            'v_out_back_images'=>$imageNameBack,
//            'v_out_right_images'=>$imageNameLeft,
//            'v_out_left_images'=>$imageNameRight,
//            'v_in_front_images'=>$imageNameInFront,
//            'v_in_back_images'=>$imageNameInBack,
//            'vehicle_rent_own'=>$request->vehicle_rent_own,
//
//        ]);
//
//        GuideDetails::query()->create([
//
//            'user_id'=>$User->id,
//            'about'=>$request->about,
//            'language'=>$request->language,
//            'w_experience'=>$request->w_experience,
//            'guides_photos_pass_size'=>$imageNamePassportSize,
//            'guides_photos_normal'=>$imageNamePassportSize,
//            'guide_license_f'=>$pdfName_guide_license_f,
//            'guide_license_b'=>$pdfName_guide_license_b,
//            'driving_license_f'=>$pdfName_driving_license_f,
//            'driving_license_b'=>$pdfName_driving_license_b,
//            'nic_f'=>$pdfName_nic_f,
//            'nic_b'=>$pdfName_nic_b,
//            'guide_category'=>$request->vehicle_rent_own
//
//        ]);
//
//        //var_dump('yes');die();
//        $guide_data=[
//
//            'f_name'=>$request->f_name,
//            'l_name'=>$request->l_name,
//            'm_phone_1'=>$request->m_phone1,
//            'email'=>$request->email,
//            'about'=>$request->about,
//            'language'=>$request->language,
//            'w_experience'=>$request->w_experience
//
//        ];
//        //dd($tourist_data);
//        Mail::to('user@gmail.com')->send(new GuideRegisteredMail($guide_data));
//
//        return redirect('/login')->withSuccess('You are registered successfully');
////        return redirect('/coming-soon')->withSuccess('You are registered successfully');
//
//    }

//    public function loginCheck(Request $request)
//    {
//
//        $data=[
//            "email"=>$request->email,
//            "password"=>$request->password, // Assuming the request contains the password directly
//            'user_type'=>'guide',
//        ];
//
//        $tourist = User::query()
//            ->where('email', $data['email'])
//            ->first();
//
//        // Check if the tourist exists and if the provided password matches the hashed password
//        if($tourist && Hash::check($data['password'], $tourist->password)) {
//            auth('user')->login($tourist);
//            $request->session()->regenerate();
//            return redirect()->intended(route('guide-profile'));
//        }
//
//        return back()->withErrors([
//            'email' => 'The provided credentials do not match our records.',
//        ])->onlyInput('email');
//
//    }


}

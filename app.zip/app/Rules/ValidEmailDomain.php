<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class ValidEmailDomain implements ValidationRule
{
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        //
        $domain = explode('@', $value)[1];

        // Check if the domain has a valid MX record (mail exchange record)
        if (!checkdnsrr($domain, 'MX')) {
            $fail("The {$attribute} must have a valid email domain.");
        }
    }
}

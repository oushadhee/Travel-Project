<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuotationPlacesDetails extends Model
{
    use HasFactory;

    protected $fillable = [

        'quotation_id',
        'parking_tickets_place',
        'parking_tickets_expense',
        'sightseeing_tickets_place',
        'sightseeing_tickets_expense',
        'highway_tickets_place',
        'highway_tickets_expense',
        'refreshments_name',
        'refreshments_expense'

    ];
}

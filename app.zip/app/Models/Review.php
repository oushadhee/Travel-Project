<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Review extends Model
{
    use HasFactory;

   protected $fillable = [
     'user_id',
        'tour_type',
        'comment_jot',
        'suggestions_jot',
        'rating',
        'start_date',
        'end_date',
        'country',
        'tour_photos',
        'tour_category_id', // Nullable, if not provided in form
        'selected_guide',  // Nullable, if not provided in form
        'comment_guide',   // Nullable, if not provided in form
        'suggestions_guide', // Nullable, if not provided in form
];


    protected $casts = [
        'tour_photos' => 'array', // Cast tour_photos to array for JSON storage
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Vehicle extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'user_id',
        'fileToUpload_v_insurance_f',
        'fileToUpload_v_insurance_b',
        'v_book_f',
        'v_book_b',
        'end_date_insurance',
        'vehicle_type',
        'v_model',
        'v_number',
        'v_out__front_images',
        'v_out_back_images',
        'v_out_right_images',
        'v_out_left_images',
        'v_in_front_images',
        'v_in_back_images',
        'vehicle_rent_own'

    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

}

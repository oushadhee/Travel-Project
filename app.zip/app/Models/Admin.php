<?php

namespace App\Models;

use App\Mail\SendCodeMail;
use Exception;
use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Mail;

class Admin extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'admin_name',
        'admin_email',
        'admin_pass'

    ];

    public function generateCode()
    {
        $code = rand(1000, 9999);

        UserCode::updateOrCreate(
            ['admin_id' => auth('admin')->user()->id],
            ['code' => $code]
        );

        try {

            $details = [
                'title' => 'Mail from ItSolutionStuff.com',
                'code' => $code
            ];

            Mail::to(auth('admin')->user()->admin_email)->send(new SendCodeMail($details));

        } catch (Exception $e) {
            info("Error: " . $e->getMessage());
        }
    }


//    public function generateCode()
//    {
//        $code = rand(1000, 9999);
//
//        UserCode::updateOrCreate(
//            [ 'user_id' => auth()->user()->id ],
//            [ 'code' => $code ]
//        );
//
//        try {
//
//            $details = [
//                'title' => 'Mail from ItSolutionStuff.com',
//                'code' => $code
//            ];
//
//            Mail::to(auth()->user()->admin_email)->send(new SendCodeMail($details));
//
//        } catch (Exception $e) {
//            info("Error: ". $e->getMessage());
//        }
//    }

}

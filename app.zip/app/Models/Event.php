<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'event_name',
        'time_period',
        'date',
        'place',
        'description',
        'image'

    ];
}

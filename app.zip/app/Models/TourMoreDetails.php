<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TourMoreDetails extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'tour_id',
        'sequence',
        'description'

    ];

}

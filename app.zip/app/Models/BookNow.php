<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookNow extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'user_id',
        'start_date',
        'end_date',
        'number_of_days',
        'expected_country',
        'expected_location',
        'tour_package',
        'number_of_people',
        'number_of_adults',
        'number_of_children',
        'number_of_toddlers',
        'number_of_infants',
        'number_of_newborns',
        'requirements_for_babies',
        'property_type',
        'star_ratings',
        'vehicle_type',
        'budget_range_from',
        'budget_range_to',
        'travel_destination',
        'air_tickets',
        'requirements_for_tour',
        'status'

    ];
}

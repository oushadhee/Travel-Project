<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Gallery extends Model
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'user_id',
//        'review_id',
        'start_date',
        'end_date',
        'country',
        'tour_photos',
        'place_name',
        'map_link',
        'video_path',


    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}

<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GuideDetails extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'user_id',
        'about',
        'language',
        'w_experience',
        'guides_photos_pass_size',
        'guides_photos_normal',
        'guide_license_f',
        'guide_license_b',
        'driving_license_f',
        'driving_license_b',
        'nic_f',
        'nic_b',
        'guide_category'

    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

}

<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'place_name',
        'main_category_id',
        'sub_category_id',
        'description',
        'map_link',
        'activity_image'

    ];
}

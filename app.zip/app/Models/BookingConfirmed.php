<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookingConfirmed extends Model
{
    use HasFactory;

    protected $table = 'bookingconfirmed';
    protected $fillable = [
        'booked_id',
        'passport_copy',
        'air_ticket_copy'
    ];
}

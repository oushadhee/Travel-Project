<?php

// app/Models/Tour.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tour extends Model
{
    protected $table = 'tours'; 

   public function category() {
    return $this->belongsTo(TourCategory::class, 'main_category_id');
}

}

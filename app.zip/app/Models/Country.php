<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $table = 'country';
    public $timestamps = false;
    

public function tourCategories()
{
    return $this->hasMany(TourCategory::class, 'country_id'); 
}

public function activeTourCategories()
    {
        return $this->hasMany(TourCategory::class, 'country_id')
                    // ->where('is_deleted', 0)
                    // ->where('parent_id', 0)
                    ->orderBy('category_name');
    }
}


<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Agent extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_type',
        // 'user_id',
        'p_id',
        'p_idImageF',
        'p_idImageB',
        'city',
        'street',
        'citizenship',
        'z_code',
        'gender',
        'y_exp',
        'p_imageAgent',
        't_c',
        'com_name',
        'contact_person_name',
        'reg_num',
        'v_license',
        'l_img_f',
        'l_img_b',
    ];

    public function user()
    {
        return $this->hasOne(User::class, 'agent_id');
    }
    
    
}



<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticateContracts;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Location extends Model implements AuthenticateContracts
{
    use HasFactory;
    use Authenticatable;

    protected $fillable = [

        'district_and_province_name',
        'parent_id',

    ];

    public function district(): HasMany
    {
        return $this->hasMany(Excursion::class, 'district','id');
    }
    public function province(): HasMany
    {
        return $this->hasMany(Excursion::class, 'province','id');
    }
}

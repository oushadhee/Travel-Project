<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class QuotationDetails extends Model
{
    use HasFactory;

    protected $fillable = [

        'booked_id',
        'air_tickets_expense',
        'accommodation_expense',
        'garlands_expense',
        'vehicle_expense',
        'guide_expense',
        'driver_expense',
        'status',
        'swift_copy',
        'notification_link',
        'notification_text'


    ];

    public function booknow(): BelongsTo
    {
        return $this->belongsTo(BookNow::class, 'booked_id', 'id');
    }


}

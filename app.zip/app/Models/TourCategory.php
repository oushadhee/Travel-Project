<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TourCategory extends Model
{
    protected $table = 'tour_categories';
    public $timestamps = false;

  
public function country()
{
    return $this->belongsTo(Country::class, 'country_id'); 
}


public function tours()
{
    return $this->hasMany(Tour::class, 'category_id','sub_category_id',); 
}



}
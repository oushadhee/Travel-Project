@extends('layouts.front', ['main_page' => 'yes'])
@section('content')



<section class="loginform" style="background-color: #333; padding: 20px; display: flex; justify-content: center; align-items: center; height: 100vh; padding-top: 180px; background-image: url('assets/images/banner/login_bg.jpg'); background-size: cover; background-position: center;">
    <div class="loginform-box" style="background-color: rgba(255, 255, 255, 0.8); border-radius: 10px; padding: 30px; width: 400px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);margin-top:-50px;">
        @if(session('error'))
            <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px;">
                <button type="button" class="close" data-dismiss="alert" style="background: none; border: none; color: inherit;">&times;</button>
                {{ session('error') }}
            </div>
        @endif

        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block" style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px;">
                <button type="button" class="close" data-dismiss="alert" style="background: none; border: none; color: inherit;">&times;</button>
                <strong>{{ $message }}</strong>
            </div>
        @endif

        <h1 style="color: #f67a59; font-weight: bold; text-align: center;font-family:'roboto';">Starluxe Travels</h1><br>

        <form action="{{ route('loginCheck') }}" method="POST">
            @csrf
            <div class="login-form-group" style="margin-bottom: 20px;">
                <label for="email" style="font-size: 14px; font-weight: bold;">EMAIL:</label>
                <input type="email" id="email" name="email" class="@error('email') is-invalid @enderror" required style="width: 100%; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc;">
                @error('email')
                    <span class="invalid-feedback" role="alert" style="color: #e74c3c; font-size: 12px;">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="login-form-group" style="margin-bottom: 20px;">
                <label for="password" style="font-size: 14px; font-weight: bold;">PASSWORD:</label>
                <input type="password" id="password" name="password" class="@error('password') is-invalid @enderror" required style="width: 100%; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc;">
                @error('password')
                    <span class="invalid-feedback" role="alert" style="color: #e74c3c; font-size: 12px;">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="login-form-group" style="text-align: center;">
                <button type="submit" style="background-color: #fe7524; color: white; font-weight: bold; padding: 10px 20px; border: none; border-radius: 5px;">LOGIN</button>
            </div>

            <div style="text-align: center; margin-top: 10px;">
                <a href="{{ route('forgot.password') }}" style="color: #fe7524; text-decoration: none;">Forgot Password?</a>
            </div>

            <p class="have_account" style="text-align: center; font-size: 14px; color: #333; margin-top: 20px;">Don't have an account? <br>
                <a href="{{ route('register') }}" class="sign-up-link" style="color: #fe7524; font-weight: bold;">Sign Up</a> as a Tourist
            </p>
        </form>

        <!-- <div class="footer__logo" style="text-align: center; margin-top: 30px;">
            <a href="/"><figure class="logo_B"><img src="{{ asset('assets/images/logo/LOGO-JOT - Footer.png') }}" alt="Logo" style="width: 100px;"></figure></a>
        </div> -->
    </div>
</section>



@endsection
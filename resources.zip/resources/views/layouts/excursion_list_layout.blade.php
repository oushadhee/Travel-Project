<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Starluxe Travels</title>

    <!-- Fav Icon -->
    <link rel="icon" href="{{ asset('assets/images/icons/TitleIcon_FB_Blue.png') }}" type="image/x-icon">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Permanent+Marker&family=Source+Serif+Pro:wght@400;600&display=swap" rel="stylesheet">

    <!-- Stylesheets -->
    <link href="{{ asset('assets/css/font-awesome-all.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/fontawesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/flaticon_save_us.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/fonts/flaticon.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/owl.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/slick-theme.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/slick.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/jquery.fancybox.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/progresscircle.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/color.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/nice-select.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/global.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/swiper.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/responsive.css') }}" rel="stylesheet">


    <!-- wtsp -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">

    <!-- viber -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8j5+3i5XnApxXCWPViP8s5/Xy5VntE+m5h5B+Uxf4654i5cRP754Z2r5uOH2t6YT5H5x5X5Yr/Ao54sBwnEw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- top bar -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- top bar -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- login form -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- country codes -->
    <link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/css/intlTelInput.css"/>
    <script src="https://cdn.tutorialjinni.com/intl-tel-input/17.0.19/js/intlTelInput.min.js"></script>

    <!-- country codes -->
    <link rel="stylesheet" href="path/to/bootstrap.min.css">
    <script src="path/to/jquery.min.js"></script>
    <script src="path/to/bootstrap.min.js"></script>


    <!-- for models -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</head>

<!-- page wrapper -->
<body>

@yield('topbar', view('components.topbar'))

@yield('content')
@yield('footer', view('components.footer'))

{{--Book Now--}}
{{--<section>--}}
{{--    <div class="book-now-btn-container">--}}
{{--        <a class="book-now-btn" href="{{ route('book-now-form') }}">--}}
{{--            <img class="book-now-btn" src="{{ asset('assets/images/icons/BookNow_FB_Blue.png') }}" alt="book_now"></a>--}}
{{--    </div>--}}
{{--</section>--}}
{{--end--}}

{{--viber--}}
<section>
    <div class="viber-btn-container">
        <a class="viber-btn" href="viber://chat?number=94707009666"><i class="fab fa-viber"></i></a>
        <span>Contact Us</span>
    </div>
</section>
{{--end--}}

{{-- whatsApp --}}
<section>
    <div class="whatsapp-btn-container">
        <a class="whatsapp-btn" href="https://wa.me/94707009666"><i class="fab fa-whatsapp"></i></a>
        <span >Contact Us</span>
    </div>
</section>
{{--end--}}

{{--scroll to up--}}
<a href="#" class="scrollToTop">
    <i class="fa-solid fa-arrow-up" style="align-items: center"></i>
</a>
{{--end--}}


<!-- jequery plugins -->
<script src="{{ asset('assets/js/jquery.js') }}"></script>
<script src="{{ asset('assets/js/popper.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/fontawesome.min.js') }}"></script>
<script src="{{ asset('assets/js/all.min.js') }}"></script>
<script src="{{ asset('assets/js/owl.js') }}"></script>
<script src="{{ asset('assets/js/wow.js') }}"></script>
<script src="{{ asset('assets/js/slick.min.js') }}"></script>
<script src="{{ asset('assets/js/validation.js') }}"></script>
<script src="{{ asset('assets/js/progresscircle.js') }}"></script>
<script src="{{ asset('assets/js/scrollbar.js') }}"></script>
<script src="{{ asset('assets/js/appear.js') }}"></script>
<script src="{{ asset('assets/js/jquery.nice-select.min.js') }}"></script>
<script src="{{ asset('assets/js/swiper.min.js') }}"></script>
<script src="{{ asset('assets/js/parallax.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.fancybox.js') }}"></script>
<script src="{{ asset('assets/js/jquery.magnific-popup.js') }}"></script>
<script src="{{ asset('assets/js/parallax-scroll.js') }}"></script>
<script src="{{ asset('assets/js/jquery.paroller.min.js') }}"></script>

<!-- main-js -->
<script src="{{ asset('assets/js/script.js') }}"></script>

{{--gallery--}}
<script src="https://cdn.jsdelivr.net/jquery.mixitup/latest/jquery.mixitup.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var scrollToTopBtn = document.querySelector('.scrollToTop');
        var rootElement = document.documentElement;

        function handleScroll() {
            // Do something on scroll
            var scrollTotal = rootElement.scrollHeight - rootElement.clientHeight;
            if ((rootElement.scrollTop / scrollTotal) > 0.20) {
                // Show button
                scrollToTopBtn.style.display = 'block';
            } else {
                // Hide button
                scrollToTopBtn.style.display = 'none';
            }
        }

        function scrollToTop() {
            // Scroll to top logic
            rootElement.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        scrollToTopBtn.addEventListener('click', scrollToTop);
        document.addEventListener('scroll', handleScroll);
    });
</script>

{{--card slider--}}
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function(){
        var slider = $('.slider');
        var card = $('.card');
        var cardWidth = card.outerWidth(true);
        var cardCount = card.length;

        slider.width(cardWidth * cardCount);

        var currentSlide = 0;

        function nextSlide() {
            currentSlide++;
            if (currentSlide >= cardCount) {
                currentSlide = 0;
            }
            slider.animate({
                marginLeft: -currentSlide * cardWidth
            }, 500);
        }

        setInterval(nextSlide, 10000); // Change slide every 3 seconds
    });
</script>

</body><!-- End of .page_wrapper -->
</html>

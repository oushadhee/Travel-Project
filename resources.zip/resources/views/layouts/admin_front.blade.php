<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>JOT-Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="{{ asset('assets/backend/vendors/mdi/css/materialdesignicons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/backend/vendors/base/vendor.bundle.base.css') }}">
    <!-- endinject -->
    <!-- plugin css for this page -->
{{--    <link rel="stylesheet" href="{{ asset('assets/backend/vendors/datatables.net-bs4/dataTables.bootstrap4.css') }}">--}}
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="{{ asset('assets/backend/css/style.css') }}">
    <!-- endinject -->
    <link rel="shortcut icon" href="{{ asset('assets/backend/images/favicon.png') }}" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="path/to/bootstrap/css/bootstrap.min.css') }}">

{{--    <!-- user login form -->--}}
{{--    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">--}}


    {{--guide and tour display tables--}}

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css" integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" />

    {{--guide see more--}}
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

    {{--tables for form--}}

    <!-- Custom styles for this page -->
    <link href="vendors/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    {{--end--}}

    <!-- Bootstrap JS and Popper.js (required for Bootstrap) -->
    <script src="path/to/jquery.min.js"></script>
    <script src="path/to/popper.min.js"></script>
    <script src="path/to/bootstrap/js/bootstrap.min.js"></script>

</head>

<body>

<div class="container-scroller">

    <!-- partial:partials/_navbar.html -->
    @yield('navbar', view('backend.components.admin_navbar'))
    <!-- partial -->

        <div class="container-fluid page-body-wrapper">

            <!-- partial:partials/_sidebar.html -->
            @yield('sidebar', view('backend.components.admin_sidebar'))
            <!-- partial -->

            <div class="main-panel">
                <!-- content-wrapper -->
                @yield('content')
                <!-- content-wrapper ends -->
            </div>
            <!-- main-panel ends -->
        </div>

    <!-- partial:partials/_footer.html -->
    @yield('footer', view('backend.components.admin_footer'))
    <!-- partial -->

    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->

<!-- plugins:js -->
<script src="{{ asset('assets/backend/vendors/base/vendor.bundle.base.js') }}"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="{{ asset('assets/backend/vendors/chart.js/Chart.min.js') }}"></script>
<script src="{{ asset('assets/backend/vendors/datatables.net/jquery.dataTables.js') }}"></script>
<script src="{{ asset('assets/backend/vendors/datatables.net-bs4/dataTables.bootstrap4.js') }}"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="{{ asset('assets/backend/js/off-canvas.js') }}"></script>
<script src="{{ asset('assets/backend/js/hoverable-collapse.js') }}"></script>
<script src="{{ asset('assets/backend/js/template.js') }}"></script>
<!-- endinject -->

<!-- Custom js for this page-->
<script src="{{ asset('assets/backend/js/dashboard.js') }}"></script>

<!-- End custom js for this page-->

<script src="{{ asset('assets/backend/js/jquery.cookie.js') }}" type="text/javascript"></script>

{{--tables--}}

<!-- Page level plugins -->
<script src="vendors/datatables/jquery.dataTables.min.js"></script>
<script src="vendors/datatables/dataTables.bootstrap4.min.js"></script>

</body>

</html>


@extends('layouts.front',['main_page' => 'yes'])

@section('content')

<style>
    .loginform-box {
        width: 500px; /* Adjust the width as needed */
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 40px 80px rgba(0, 0, 0, 0.1);
        font-size: 20px;
        text-align: center;
        background: linear-gradient(to bottom, rgba(0,0, 0, 0.5), rgba(0, 0, 0, 0.5)); /* Use rgba for transparency */
        margin: 100px auto 15px;
    }


    .loginform-box form {
        display: flex;
        flex-direction: column;
    }

    .login-form-group {
        margin-bottom: 15px;
    }

    label {
        color: white;
        font-weight: bolder;
        text-shadow: 5px 5px 5px rgba(0, 0, 0, 0.2); /* Add text shadow */
    }


    input[type="email"],
    input[type="password"] {
        width: 100%;
        padding: 10px 15px;
        margin-top: 8px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 9px;
        box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.1);
        font-size: 18px;
        font-weight: bold;
        color: black;
    }

    button {
        background-color: #05af22;
        color: white;
        font-weight: bold;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

</style>

<section class="loginform" style="font-family: 'Corbel Light'; background-image: url(../assets/images/banner/login_bg.jpg); background-size: cover; height: 800px; background-position: center; background-repeat: no-repeat;">

    <div class="loginform-box" >

    

          @if ($errors->any())
          <div class="alert alert-danger">
              <button type="button" class="close" data-dismiss="alert">×</button>
              <ul>
                  @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                  @endforeach
              </ul>
          </div>
      @endif

        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>{{ $message }}</strong>
            </div>
        @endif

        <main>

    <form action="{{ route('reset.password.post') }}" method="POST">
            @csrf
            <input type="text" name=" token" hidden value="{{$token}}">
            <div class="login-form-group">
                <label for="email">Email address:</label>
                <input type="email" class=" @error('email') is-invalid @enderror"  id="email" name="email" required/>
            </div>

            <div class="login-form-group">
                <label for="email">Enter New Password:</label>
                <input type="password" class=" @error('email') is-invalid @enderror"  id="password" name="password" required>
            </div>

            <div class="login-form-group">
                <label for="email">Confirm Password:</label>
                <input type="password" class=" @error('email') is-invalid @enderror"  id="password" name="password_confirmation" required>
            </div>

            <div class="login-form-group">
                <button type="submit"  style="background-color: #05af22; color: white;font-weight: bold">SUBMIT</button>
            </div>



        </form>

    </main>
    </div>

</section>
@endsection

<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">
        <h2>Booked Tour Information</h2>
        <p>

            Hi, <br>
            I am {{$booked_tourist_registered['f_name']}} {{$booked_tourist_registered['l_name']}}. I need to book a tour.
            <br><br>

            <strong><u>Expected Time Period</u></strong><br>

            <strong>Start and End Date :</strong> {{$booked_tourist_registered['start_date']}} to {{$booked_tourist_registered['end_date']}} <br>
            <strong>Expected Number of Days :</strong> {{$booked_tourist_registered['number_of_days']}} <br><br>

            <strong><u>Expected Location or Tour Package</u></strong><br>

            <strong>Expected Country</strong> {{$booked_tourist_registered['expected_country']}} <br>
            <strong>Expected Locations :</strong> {{$booked_tourist_registered['location']}} <br>
            <strong>Tour Package :</strong> {{$booked_tourist_registered['tour_package']}} <br><br>

            <strong><u>Expected Pax</u></strong><br>

            <strong>Number of People :</strong> {{$booked_tourist_registered['number_of_people']}} <br>
            <strong>Number of Adults :</strong> {{$booked_tourist_registered['number_of_adults']}} <br>
            <strong>Number of Children :</strong> {{$booked_tourist_registered['number_of_children']}} <br>
{{--            <strong>Baby Type :</strong> {{$booked_tourist_registered['baby_type']}} <br>--}}
            <strong>Number of Toddlers :</strong> {{$booked_tourist_registered['number_of_toddlers']}} <br>
            <strong>Number of Infants :</strong> {{$booked_tourist_registered['number_of_infants']}} <br>
            <strong>Number of Newborns :</strong> {{$booked_tourist_registered['number_of_newborns']}} <br>
            <strong style="color: red">Special Requirements :</strong> {{$booked_tourist_registered['requirements_for_babies']}} <br><br>

            <strong><u>Accommodation and Vehicle</u></strong><br>

            <strong>Property Type :</strong> {{$booked_tourist_registered['property_type']}} <br>
            <strong>Star Ratings :</strong> {{$booked_tourist_registered['star_ratings']}} <br>
            <strong>Vehicle Type :</strong> {{$booked_tourist_registered['vehicle_type']}} <br><br>

            <strong><u>Other</u></strong><br>

            <strong>Budget Range From:</strong> {{$booked_tourist_registered['budget_range_from']}} <br>
            <strong>Budget Range To:</strong> {{$booked_tourist_registered['budget_range_to']}} <br>
            <strong>Air Tickets :</strong> {{$booked_tourist_registered['air_tickets']}} <br>
            <strong>Travel Destination :</strong> {{$booked_tourist_registered['travel_destination']}} <br>
{{--            <strong>Budget Range :</strong> {{$booked_tourist_registered['budget_range']}} <br>--}}
            <strong style="color: red">Special Requirements :</strong> {{$booked_tourist_registered['requirements_for_tour']}} <br>

        </p>
    </div>
</body>

<style>
    .card {
    width: 800px;
    margin: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.card-header {
    background-color: #f8f9fa;
    padding: 10px;
    border-bottom: 1px solid #ccc;
}

.card-title {
    text-align: center;
}

.card-body {
    padding: 20px;
}

.card-text {
    margin-bottom: 20px;
}

.list-group {
    margin: 0;
    padding: 0;
    list-style-type: none;
}

.list-group-item {
    border: none;
    padding: 5px 0;
}

</style>

<body>
                   <div class="container">
                    <div class="row">
                        <div class="col-md-6 offset-md-3">
                            <div class="card">
                                   <img src="{{asset('assets/images/logo/LOGO_JOT_FB_Blue.png')}}" alt="logo" class="card-img-top" alt="Booking Image" style="display: block; margin: 0 auto; width: 150px; height:150px;">
                                    <h2 class="card-title">Quotation Confirmation</h2>
                             </div>
                                <div class="card-body">

                                        <p>We are pleased to Inform you that this Quotation has been confirmed by the <strong>{{ $data['user_name'] }}</strong>.</p>

                                    <br>
                                    <p>Thank you</p>
                                </div>
                            </div>
                        </div>
                    </div>


</body>


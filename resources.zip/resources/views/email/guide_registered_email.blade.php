<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">
        <h2>Registered Guide Information</h2>
        <p>
            Hi, <br>
            I am {{$guide_data['f_name']}} {{$guide_data['l_name']}}.<br><br>

            <strong>Name:</strong> {{$guide_data['f_name']}} {{$guide_data['l_name']}} <br>
            <strong>Mobile Number:</strong> (+{{$guide_data['m_phone_1_country_code']}}) {{$guide_data['m_phone_1']}} <br>
            <strong>Email:</strong> {{$guide_data['email']}} <br>
            <strong>Address:</strong> {{$guide_data['address']}} <br>
            <strong>About:</strong> {{$guide_data['about']}} <br>
            <strong>Languages:</strong> {{$guide_data['language']}} <br>

            <br>

            <strong>Work Experience:</strong> {{$guide_data['w_experience']}} <br>
            <strong>Guide Category:</strong> {{$guide_data['guide_category']}} <br>

            <br>

            <strong>Passport Size Image:</strong><br>

            @php
                $fileUrl = asset('storage/image/guide/personal/passport_size/' . $guide_data['guides_photos_pass_size']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Normal Image:</strong><br>

            @php
                $fileUrl = asset('storage/image/guide/personal/normal/' . $guide_data['guides_photos_normal']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Guide License Front:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/personal/guide_license/front/' . $guide_data['guide_license_f']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a data-toggle="modal" data-target="#guideLicenseFrontModal">
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Guide License Back:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/personal/guide_license/back/' . $guide_data['guide_license_b']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Driving License Front:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/personal/driving_license/front/' . $guide_data['driving_license_f']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Driving License Back:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/personal/driving_license/back/' . $guide_data['driving_license_b']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>NIC Front:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/personal/nic/front/' . $guide_data['nic_f']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>NIC Back:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/personal/nic/back/' . $guide_data['nic_b']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br><br>

            <strong>End Date of Vehicle Insurance:</strong> {{$guide_data['end_date_insurance']}} <br>
            <strong>Vehicle Type:</strong> {{$guide_data['vehicle_type']}} <br>
            <strong>Vehicle Model:</strong> {{$guide_data['v_model']}} <br>
            <strong>Vehicle Model:</strong> {{$guide_data['v_number']}} <br>
            <strong>Owner or Rented:</strong> {{$guide_data['vehicle_rent_own']}} <br>

            <br>

            <strong>Vehicle Insurance Front:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/insurance/front/' . $guide_data['fileToUpload_v_insurance_f']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Insurance Back:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/insurance/back/' . $guide_data['fileToUpload_v_insurance_b']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Book Front:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/v_book/front/' . $guide_data['v_book_f']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Book Back:</strong><br>
            @php
                $fileUrl = asset('storage/document/guide/v_book_b/back/' . $guide_data['v_book_b']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br><br>

            <strong>Vehicle Images:</strong>

            <br><br>

            <strong>Vehicle Front Side Image:</strong><br>
            @php
                $fileUrl = asset('storage/image/guide/vehicle/front/' . $guide_data['v_out__front_images']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Back Side Image:</strong><br>
            @php
                $fileUrl = asset('storage/image/guide/vehicle/back/' . $guide_data['v_out_back_images']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Right Side Image:</strong><br>
            @php
                $fileUrl = asset('storage/image/guide/vehicle/right/' . $guide_data['v_out_right_images']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Left Side Image:</strong><br>
            @php
                $fileUrl = asset('storage/image/guide/vehicle/left/' . $guide_data['v_out_left_images']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Inside Front Image:</strong><br>
            @php
                $fileUrl = asset('storage/image/guide/vehicle/inside/front/' . $guide_data['v_in_front_images']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

            <br>

            <strong>Vehicle Inside Back Image:</strong><br>
            @php
                $fileUrl = asset('storage/image/guide/vehicle/inside/back/' . $guide_data['v_in_back_images']);
                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
            @endphp

            <a>
                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))
                    {{-- Display image --}}
                    <img src="{{ $fileUrl }}" alt="Image" style="width: 200px; height: 200px; object-fit: cover;">
                @elseif ($fileExtension === 'pdf')
                    {{-- Display PDF using embed --}}
                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 200px; height: 200px; object-fit: cover;">
                @else
                    {{-- Display generic content using iframe --}}
                    <iframe src="{{ $fileUrl }}" style="width: 200px; height: 200px; object-fit: cover;"></iframe>
                @endif
            </a>

        </p>
    </div>
</body>

<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">
        <h2>Please verify your email address</h2>
        <p>
            <strong> Hello </strong> {{$email_verify_guide['f_name']}} {{$email_verify_guide['l_name']}} <br><br>
            To verify your email, click the button below:
        </p>

        <a href="{{ route('verify_guide',$email_verify_guide['remember_token']) }}"
           style="display:inline-block; padding:10px 20px; background-color:#4CAF50; color:#fff;
               text-decoration:none; border-radius:5px;">
            Verify Your Email
        </a>

        <p>
            Thank You.
        </p>
    </div>
</body>

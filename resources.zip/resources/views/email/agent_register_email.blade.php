<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">
        <h2>Registered Tourist Information through Agents</h2>

        <p>

            You have new register Tourist <br><br>
            
            <strong>Name:</strong> {{$tourist_data['f_name']}} {{$tourist_data['l_name']}} <br>
            <strong>Email:</strong> {{$tourist_data['email']}} <br>
            <strong>Country From:</strong> {{$tourist_data['country']}} <br>
            <strong>Address:</strong> {{$tourist_data['address']}} <br>
            <strong>Mobile Number:</strong> (+{{$tourist_data['m_phone_1_country_code']}}) {{$tourist_data['m_phone_1']}} <br>

        </p>
    </div>
</body>

<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">

        <p>
            Hi, <br>
            I am {{$data['firstName']}} {{$data['lastName']}}. <br><br>

            <strong>First Name:</strong> {{$data['firstName']}} <br>
            <strong>Last Name:</strong> {{$data['lastName']}} <br>
            <strong>Email:</strong> {{$data['email']}} <br>
            <strong>Phone Number:</strong> (+{{$data['m_phone_1_country_code']}}) {{$data['m_phone_1']}} <br>
            <strong>Message:</strong> {{$data['message']}} <br>

        </p>
    </div>
</body>

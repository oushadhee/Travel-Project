<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
<div class="container">
    <h2>Booked Tour Information</h2>
    <p>
        Hi, <br>

        I am {{$booked_tourist['f_name']}} {{$booked_tourist['l_name']}}. I need to book a tour.
        <br><br>

        <strong>Name :</strong> {{$booked_tourist['f_name']}} {{$booked_tourist['l_name']}} <br><br>

        <strong>Mobile Number:</strong> (+{{$booked_tourist['m_phone_1_country_code']}}) {{$booked_tourist['m_phone_1']}} <br>
        <strong>Email:</strong> {{$booked_tourist['email']}} <br>
        <strong>Country From:</strong> {{$booked_tourist['country']}}<br>
        <strong>Address:</strong> {{$booked_tourist['address']}}<br><br>

        <strong><u>Expected Time Period</u></strong><br><br>

        <strong>Start and End Date :</strong> {{$booked_tourist['start_date']}} to {{$booked_tourist['end_date']}} <br>
        <strong>Expected Number of Days :</strong> {{$booked_tourist['number_of_days']}} <br><br>

        <strong><u>Expected Location or Tour Package</u></strong><br><br>

        <strong>Expected Country :</strong> {{$booked_tourist['expected_country']}} <br>
        <strong>Expected Locations :</strong>{{$booked_tourist['location']}} <br>
        <strong>Tour Package :</strong> {{$booked_tourist['tour_package']}} <br><br>

        <strong><u>Expected Pax</u></strong><br><br>

        <strong>Number of People :</strong> {{$booked_tourist['number_of_people']}} <br>
        <strong>Number of Adults :</strong> {{$booked_tourist['number_of_adults']}} <br>
        <strong>Number of Children :</strong> {{$booked_tourist['number_of_children']}} <br>
{{--        <strong>Baby Type :</strong> {{$booked_tourist['baby_type']}} <br>--}}
        <strong>Number of Toddlers :</strong> {{$booked_tourist['number_of_toddlers']}} <br>
        <strong>Number of Infants :</strong> {{$booked_tourist['number_of_infants']}} <br>
        <strong>Number of Newborns :</strong> {{$booked_tourist['number_of_newborns']}} <br>
        <strong style="color: red">Special Requirements :</strong> {{$booked_tourist['requirements_for_babies']}} <br><br>

        <strong><u>Accommodation and Vehicle</u></strong><br><br>

        <strong>Property Type :</strong> {{$booked_tourist['property_type']}} <br>
        <strong>Star Ratings :</strong> {{$booked_tourist['star_ratings']}} <br>
        <strong>Vehicle Type :</strong> {{$booked_tourist['vehicle_type']}} <br><br>

        <strong><u>Other</u></strong><br><br>

        <strong>Budget Range From:</strong> {{$booked_tourist['budget_range_from']}} <br>
        <strong>Budget Range To:</strong> {{$booked_tourist['budget_range_to']}} <br>
        <strong>Travel Destination :</strong> {{$booked_tourist['travel_destination']}} <br>
{{--        <strong>Budget Range :</strong> {{$booked_tourist['budget_range']}} <br>--}}
        <strong style="color: red">Special Requirements :</strong> {{$booked_tourist['requirements_for_tour']}} <br>

    </p>
</div>
</body>



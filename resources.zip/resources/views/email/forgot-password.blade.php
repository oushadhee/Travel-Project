{{-- <h2>Reset Password</h2>
<p>Click the link below to reset the password for your account.</p>

<a href="{{route('reset.password', $token) }}">Reset Password</a> --}}

<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">
        <h2>Please Reset your Password  </h2>
        <p>
            Click the link below to reset the password for your account.
        </p>

        <a href="{{route('reset.password', $token) }}"
           style="display:inline-block; padding:10px 20px; background-color:#4CAF50; color:#fff;
           text-decoration:none; border-radius:5px;">
            Reset Password

        </a>

        <p>
            Thank You.
        </p>

    </div>
</body>




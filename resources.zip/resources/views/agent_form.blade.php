@extends('layouts.front',['main_page' > 'yes'])
@section('content')


<style>
    body {
        font-size: 16px;
    }

    @media screen and (max-width: 768px) {
        body {
            font-size: 14px;
        }
    }

    @media screen and (max-width: 768px) {
        .loginform-box {
            width: 90%; /* Adjust the width for smaller screens */
        }
    }

    .loginform-box {
        /*width: 1200px; !* Adjust the width as needed *!*/
        width: 80%;
        padding: 20px;
        border-radius: 20px;
        box-shadow: 0 40px 80px rgba(0, 0, 0, 0.1);
        font-size: 20px;
        text-align: center;
        background: linear-gradient(to bottom, rgba(8, 102, 255, 0.2), rgba(8, 102, 255, 0.2)); /* Use rgba for transparency */
        /*margin: 40px auto 40px;*/
        margin: 40px auto

    }

    .form-group {
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 8px;
    }

    input[type="date"],
    input[type="file"],
    select {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    /* Center the date input fields */
    .form-group.date-inputs {
        margin-left: 100px;
    }
    .row {
        display: flex;
        flex-wrap: wrap;
        /* Other styles for Flexbox layout */
    }

    input[type="number"] {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
    }

    /* Adjust the register button */
    button[type="submit"] {
        width: 100%; /* Make the button full width */
        padding: 15px;
        background-color: #213771; /* Adjust the background color as needed */
        color: #fff; /* Adjust the text color as needed */
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 18px;
    }

    .m_phone_1-container {
        display: flex;
    }

    .country-code {
        flex: 1; /* Takes up 1/3 of the container */
        margin-right: 5px; /* Adjust spacing */
    }

    .phone-number {
        flex: 2; /* Takes up 2/3 of the container */
    }

</style>


<br><br>

<div class="boxed_wrapper">
    <section class="formregister" style="font-family: 'Corbel Light'; color: #213771; font-weight: 30">

        {{--message--}}
        @if (count($errors) > 0)
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>{{ $message }}</strong>
            </div>
        @endif


        {{--end--}}


        <div class="loginform-box" >

            <br>
            <div class="logo-box" style="text-align: center;">
                <a href="/"> <figure class="logo"><img src="assets/images/logo/LOGO_JOT_FB_Blue.png" alt="" style="width: 150px"></figure></a>
                <h1 style="color: #213771; font-weight: bolder">Escape the Ordinary with Extraordinary Journeys.</h1>
                <h3>Tourist's Registration</h3>
            </div>
            <div class="row">

                <div class="col-sm-12 col-lg-2 col-md-2">

                </div>

                <div class="col-sm-12 col-lg-8 col-md-8" >

                    <br>
                    <br>
                    <form method="POST" enctype="multipart/form-data" action="{{ route('agent_submit') }}">
                        @csrf

                        <div class="form-group">
                            <div class="row">
                                <div class="col-lg-6 col-sm-12">
                                    <label for="f_name">First Name:</label>

                                    <input type="text" class="form-control @error('f_name') is-invalid @enderror" id="f_name" name="f_name" value="{{ $userData['f_name'] }}" required>
                                        @error('f_name')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                </div>

                                <div class="col-lg-6 col-sm-12">
                                    <label for="l_name">Last Name:</label>

                                    <input type="text" class="form-control @error('l_name') is-invalid @enderror" id="l_name" name="l_name" value="{{ $userData['l_name'] }}" required>
                                        @error('l_name')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                </div>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-lg-6 col-sm-12">
                                    <label for="email">Your Email:</label>
                                    {{-- <input type="email" class="form-control @error('email') is-invalid @enderror"  id="email" name="email" required> --}}
                                    <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ $userData['email'] }}"  readonly required>
                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <label for="country">Your Country:</label>

                                    <select class="form-control @error('country') is-invalid @enderror" id="country" name="country"  required>
                                            <?php
                                            $country_lists = App\Models\Country::all();
                                            ?>
                                        @foreach ($country_lists as $country)
                                            <option data-img_src="{{ asset('vendor/blade-flags/country-'.strtolower($country->iso).'.svg') }}" {{ $userData['country'] === $country->nicename ? 'selected' : '' }}>{{ $country->nicename }} </option>
                                        @endforeach
                                    </select>


                                        @error('country')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-lg-6 col-sm-12">
                                    <label for="address">Your Address:</label>
                                    <textarea class="form-control @error('address') is-invalid @enderror" id="address" name="address" rows="8" required>{{ $userData['address'] }}</textarea>

                                    @error('address')
                                    <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 col-sm-12">

                                    <div class="form-group">
                                        <label for="m_phone_1">Phone Number</label>
                                        <div class="m_phone_1-container"><!-- Container for combined input -->
                                            <select class="form-control country-code" id="m_phone_1_country_code" name="m_phone_1_country_code" value="{{ $userData['m_phone_1_country_code'] }}" required>
                                                {{-- <input type="text" class="form-control" id="m_phone_1_country_code" name="m_phone_1_country_code" value="{{ $userData['m_phone_1_country_code'] }}" required> --}}
                                                    <?php
                                                    $country_lists = App\Models\Country::all();
                                                    ?>
                                                @foreach ($country_lists as $country)
                                                    <option value="{{ $country->phonecode }}" data-img_src="{{ asset('vendor/blade-flags/country-'.strtolower($country->iso).'.svg') }}">(+{{ $country->phonecode }})</option>
                                                @endforeach
                                            </select>
                                            <input type="number" class="form-control phone-number @error('m_phone_1') is-invalid @enderror" id="m_phone_1" name="m_phone_1" value="{{ $userData['m_phone_1'] }}" required>
                                    </div>

                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" required autocomplete="new-password" placeholder="At least 6 characters for password">

                                      @error('password')
                                     <span class="invalid-feedback" role="alert">
                                     <strong>{{ $message }}</strong>
                                      </span>
                                      @enderror

                                      <label for="password_confirmation">Confirm Password:</label>
                                     {{-- <input type="password" class="form-control" id="password" name="password_confirmation" required autocomplete="new-password"> --}}
                                    <input type="password" class="form-control" id="password" name="password_confirmation" required autocomplete="new-password">
                                 

                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit">Register</button>
                        </div>
                        <p>Already have an account? <a href="{{ route('login') }}">Sign In</a></p>
                    </form>
                </div>
            </div>
        </div>
    </section>

</div>


 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>

<script type="text/javascript">
    function custom_template(obj){
        var data = $(obj.element).data();
        var text = $(obj.element).text();
        if(data && data['img_src']){
            img_src = data['img_src'];
            template = $("<div><img src=\"" + img_src + "\" style=\"width:25%;height:20px;\"/>" + text + "</div>");
            return template;
        }
    }
    var options = {
        'templateSelection': custom_template,
        'templateResult': custom_template,
    }
    $('#id_select2_example').select2(options);
    $('.select2-container--default .select2-selection--single').css({'height': '25px'});



@endsection




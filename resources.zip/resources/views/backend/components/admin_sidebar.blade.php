<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="{{ route('admin-dashboard-view') }}">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-1" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Tours</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-1">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-tour-category') }}">Add tour category</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-tour') }}">Add tour</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('tour-display-admin-dash') }}">Our tours</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-tour-more-details') }}">Add More Details</a></li>
{{--                    <li class="nav-item"> <a class="nav-link" href="pages/ui-features/typography.html">view Itinerary</a></li>--}}
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-2" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Excursions</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-2">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-excursions') }}">Add excursions</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('excursions-display-admin-dash') }}">View Excursions</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-3" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Unexplored</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-3">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-unexplored') }}">Add unexplored</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('unexplored-display-admin-dash') }}">View unexplored</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-4" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Activities</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-4">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-activity-category') }}">Add activity category</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-activity') }}">Add activity</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('activity-display-admin-dash') }}">Our activities</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-5" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Events</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-5">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-event') }}">Add events</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('event-display-admin-dash') }}">View events</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-6" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Accommodations</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-6">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-accommodation') }}">Add accommodations</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('accommodation-display-admin-dash') }}">View accommodations</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic-7" aria-expanded="false" aria-controls="ui-basic">
                <i class="mdi mdi-circle-outline menu-icon"></i>
                <span class="menu-title">Gallery</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic-7">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="{{ route('add-images') }}">Add photos</a></li>
                    <li class="nav-item"> <a class="nav-link" href="{{ route('gallery-display-admin-dash') }}">View photos</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{ route('inquiries-display-admin-dash') }}">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Inquiries</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{ route('tourers-display-admin-dash') }}">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Tourers</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{ route('guides-display-admin-dash') }}">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Guides</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">
                <i class="mdi mdi-file-document-box-outline menu-icon"></i>
                <span class="menu-title">Settings</span>
            </a>
        </li>
    </ul>
</nav>

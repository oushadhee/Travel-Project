@extends('layouts.front', ['main_page' => 'yes'])

@section('content')

<!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
    <div style="margin-bottom: 10px; font-size: 16px;">
        <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
            Home
        </a>
        <span style="color: #999;">/</span>
        <a href="/gallery" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
            Photos
        </a>
    </div>
    <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
        Travel Moments That Shaped Our Hearts and Souls
    </h3>
</div>

<style>
    a:hover {
        color: #ff6f00 !important;
    }
</style>

<!-- Gallery Grid -->
<section >
    <br>
    <div class="gallery-grid" id="gallery-grid">
        @foreach([
            'G1.jpeg', 'G10.jpeg', 'G17.jpeg', 'G12.jpeg',
            'G5.jpeg', 'G21.jpeg', 'G7.jpeg', 'G8.jpeg',
            'G9.jpeg', 'G23.jpeg','G19.jpeg','G22.jpeg',
            'G2.jpeg','G3.jpeg','G4.jpeg','G6.jpeg'
        ] as $index => $image)
            <div class="gallery-item {{ $index >= 12 ? 'extra-image' : '' }}" style="{{ $index >= 12 ? 'display: none;' : '' }}">
                <a href="{{ asset('assets/images/galleryNew/' . $image) }}" class="lightbox-image" data-fancybox="gallery">
                    <img src="{{ asset('assets/images/galleryNew/' . $image) }}" alt="Gallery Image">
                </a>
            </div>
        @endforeach
    </div>

    <!-- View More / Less Button -->
    <div style="text-align: center; margin-top: 30px;">
        <button id="toggleButton" style="padding: 10px 25px; font-size: 16px; border: none; background-color: #094174; color: white; border-radius: 6px; cursor: pointer;">
            View More
        </button>
        <br>
    </div>

    <style>
        .gallery-section {
            padding: 50px 20px;
            background-color: #f9f9f9;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .gallery-item:hover {
            transform: scale(1.05);
        }

        .gallery-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
            border-radius: 12px;
        }

        @media (max-width: 768px) {
            .gallery-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            .gallery-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const toggleButton = document.getElementById('toggleButton');
            const extraImages = document.querySelectorAll('.extra-image');
            let expanded = false;

            toggleButton.addEventListener('click', function () {
                extraImages.forEach(img => {
                    img.style.display = expanded ? 'none' : 'block';
                });
                toggleButton.textContent = expanded ? 'View More' : 'View Less';
                expanded = !expanded;
            });
        });
    </script>
       <br>
</section>

@endsection

@extends('layouts.front',['main_page' > 'yes'])
@section('content')

    <!-- Excursions  -->
    <section class="popular-ture home3-popular-ture" style="font-family: 'Corbel Light';">
        <div class="sail-image">
            <img src="assets/images/shape/sail.png" alt="shape">
        </div>
        <div class="spring-arrow-r">
            <img src="assets/images/shape/spring-arrow-r.png" alt="arrow">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="align-title">
                        <h5 style="color:#0a3a58; font-family: 'Corbel Light'; font-size: 40px">Accommodations</h5>
{{--                        <h3 style="color: #0a3a58; font-family: 'Corbel Light'">Experience the Wonder of Sri Lanka</h3>--}}
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-1.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 01</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-2.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 02</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-3.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 03</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-4.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 04</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-4.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 05</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-4.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 06</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-4.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 07</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="popular-ture-content fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                        <div class="popular-ture-image">
                            <img src="assets/images/gallery/ture-4.png" alt="image">
                        </div>
                        <div class="popular-ture-overlay">
                            <div class="popular-ture-text">
                                <a href="destination-details.html" style="font-family: 'Corbel Light';">Hotel 08</a>
                                <p style="font-family: 'Corbel Light';">Description</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- popular ture  -->

@endsection

@extends('layouts.front', ['main_page' > 'yes'])
@section('content')
<br><br><br><br><br>
    <section class="package-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-details-right-container">
                        <div class="destination-common-title">
                            <center>
                                <h4>Get in Touch</h4>
                            </center>
                        </div>

                        <div class="package-details-right-form">
                            {{--message--}}
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if ($message = Session::get('success'))
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>{{ $message }}</strong>
                                </div>
                            @endif
                            {{--end--}}

                            <form action="{{ route('send-email') }}" method="POST" class="contact-form form-validate">
                                @csrf

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                    Contact Information<span style="color: red;">*</span>
                                </h5>

                                <!-- Name Fields Row -->
                                <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                    <!-- First Name -->
                                    <div class="form-group" style="flex: 1;">
                                        <div
                                            style="display: flex; align-items: center; border-radius: 4px; padding: 0 10px; height: 44px;">
                                            <i class="fa-solid fa-user" style="margin-right: 10px; color: #ecaa54;"></i>
                                            <input type="text" id="firstName" name="firstName" placeholder="First Name*"
                                                style="flex: 1; border: none; background: transparent; padding: 8px; height: 100%; outline: none;"
                                                required>
                                        </div>
                                    </div>

                                    <!-- Last Name -->
                                    <div class="form-group" style="flex: 1;">
                                        <div
                                            style="display: flex; align-items: center;  border-radius: 4px; padding: 0 10px; height: 44px;">
                                            <i class="fa-solid fa-user" style="margin-right: 10px; color: #ecaa54;"></i>
                                            <input type="text" id="lastName" name="lastName" placeholder="Last Name*"
                                                style="flex: 1; border: none; background: transparent; padding: 8px; height: 100%; outline: none;"
                                                required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Email & Phone Row -->
                                <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                    <!-- Email Field -->
                                    <div class="form-group" style="flex: 1;">
                                        <div
                                            style="display: flex; align-items: center; border-radius: 4px; padding: 0 10px; height: 44px;">
                                            <i class="fa-regular fa-envelope"
                                                style="margin-right: 10px; color: #ecaa54;"></i>
                                            <input type="email" id="email" name="email" placeholder="Your Email*"
                                                style="flex: 1; border: none; background: transparent; padding: 8px; height: 100%; outline: none;"
                                                required>
                                        </div>
                                    </div>

                                    <!-- Phone Field -->
                                    <div class="form-group" style="flex: 1;">
                                        <div
                                            style="display: flex; align-items: center;  border-radius: 4px; padding: 0 10px; height: 44px;">
                                            <i class="fa-solid fa-phone" style="margin-right: 10px; color: #ecaa54;"></i>
                                            <select id="countryCode" name="countryCode"
                                                style="width: 80px; padding: 8px 4px; border: none; background: transparent; height: 100%; appearance: none;">
                                                <option value="+94" selected>+94</option>
                                                <option value="+7">+7</option>
                                                <option value="+20">+20</option>
                                                <option value="+27">+27</option>
                                                <option value="+30">+30</option>
                                                <option value="+31">+31</option>
                                                <option value="+32">+32</option>
                                                <option value="+33">+33</option>
                                                <option value="+34">+34</option>
                                                <option value="+36">+36</option>
                                                <option value="+39">+39</option>
                                                <option value="+40">+40</option>
                                                <option value="+41">+41</option>
                                                <option value="+43">+43</option>
                                                <option value="+44">+44</option>
                                                
                                                <!-- Other country codes... -->
                                            </select>
                                            <input type="tel" id="phone" name="phone" placeholder="Phone Number*"
                                                style="flex: 1; border: none; padding: 8px; height: 100%; outline: none;"
                                                required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Message Field -->
                                <div class="form-row" style="margin-bottom: 15px;">
                                    <div class="form-group">
                                        <div
                                            style="display: flex;  border-radius: 4px; padding: 10px;">
                                            <i class="fa-solid fa-comment"
                                                style="margin-right: 10px; color: #ecaa54; margin-top: 3px;"></i>
                                            <textarea id="message" name="message" placeholder="How can we help?*"
                                                style="flex: 1; border: none; background: transparent; min-height: 120px; outline: none; resize: vertical; width: 1000px;"
                                                required></textarea>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="submit-btn">Submit</button>

                                <div class="contact-info" style="margin-top: 30px; text-align: center;">
                                    <ul style="list-style: none; padding: 0;">
                                        <li class="mb-3">
                                            <span><i class="fas fa-envelope" style="color: #6c757d;"></i>
                                                info@starluxetravels.com</span>
                                        </li>
                                        <li class="mb-3">
                                            <span><i class="fas fa-phone" style="color: #6c757d;"></i> 0707009666</span>
                                        </li>
                                        <li>
                                            <span><i class="fas fa-map-marker-alt" style="color: #6c757d;"></i>
                                                Starluxe Travels, No. 199, 6th Floor, Ward City Shopping Complex,
                                                Marybiso Mawatha, Gampaha, Sri Lanka
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- contact map -->
    <div class="contact-map">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.286953399173!2d79.99597777478797!3d7.092699016287641!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae2f11fd17dd979%3A0xbfe21122171ec899!2sKeen%20Rabbits%20(PVT)%20Ltd!5e0!3m2!1sen!2slk!4v1739265639129!5m2!1sen!2slk"
            width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <!-- contact map -->


@endsection

@extends('layouts.front', ['main_page' => 'yes'])

@section('content')

<!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
    <div style="margin-bottom: 10px; font-size: 16px;">
        <a href="{{ route('home') }}" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
            Home
        </a>
        <span style="color: #999;">/</span>
        <a href="{{ route('videos') }}" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
            Videos
        </a>
       
    </div>
    <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
        Relive the Adventure Through Our Video Gallery
    </h3>
</div>

<style>
    a:hover {
        color: #ff6f00 !important;
    }
</style>
<!-- common banner -->

<!-- Video Grid -->
<section class="gallery-section">
    <div class="gallery-grid" id="gallery-grid">
        @foreach([
            ['video' => '1.mp4', 'poster' => '1.png'],
            ['video' => '2.mp4', 'poster' => '2.png'],
            ['video' => '3.mp4', 'poster' => '3.png'],
            ['video' => '4.mp4', 'poster' => '4.png'],
            ['video' => '5.mp4', 'poster' => '5.png'],
            ['video' => '6.mp4', 'poster' => '6.png'],
            ['video' => '7.mp4', 'poster' => '7.png'],
            ['video' => '8.mp4', 'poster' => '8.png'],
            ['video' => '9.mp4', 'poster' => '9.png'],
            ['video' => '10.mp4', 'poster' => '10.png']
        ] as $index => $item)
            <div class="gallery-item {{ $index >= 8 ? 'extra-video' : '' }}" style="{{ $index >= 8 ? 'display: none;' : '' }}">
                <a href="#" class="video-link" onclick="openVideoPopup('{{ asset('assets/videos/' . $item['video']) }}'); return false;">
                    <img src="{{ asset('assets/videos/posters/' . $item['poster']) }}" alt="Video Thumbnail">
                </a>
            </div>
        @endforeach
    </div>

    <!-- View More / Less Button -->
    <div style="text-align: center; margin-top: 30px;">
        <button id="toggleButton" style="padding: 10px 25px; font-size: 16px; border: none; background-color: #094174; color: white; border-radius: 6px; cursor: pointer;">
            View More
        </button>
    </div>

    <style>
        .gallery-section {
            padding: 50px 20px;
            background-color: #f9f9f9;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .gallery-item:hover {
            transform: scale(1.05);
        }

        .gallery-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
            border-radius: 12px;
        }

        @media (max-width: 768px) {
            .gallery-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            .gallery-grid {
                grid-template-columns: 1fr;
            }
        }

        .swal2-backdrop-show {
            background-color: rgba(0, 0, 0, 0.74) !important;
            backdrop-filter: blur(2px);
        }

        .video-popup {
            width: 510px !important;
            max-width: 80% !important;
            padding: 2px;
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            border-radius: 10px;
        }

        .video-popup .swal2-content {
            padding: 0;
            width: 80%;
            overflow: hidden;
        }

        .video-popup .swal2-close {
            color: #000000 !important;
            font-size: 44px;
            transition: color 0.2s ease;
            background-color: #f67a59;
        }

        .ratio-16x9 {
            position: relative;
            width: 100%;
            max-width: 480px;
            padding-bottom: 56.25%; /* 16:9 aspect ratio */
            margin: 0 auto;
            overflow: hidden;
        }

        .ratio-16x9 video {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
        }

        @media (max-width: 600px) {
            .video-popup {
                width: 98% !important;
                max-width: 98% !important;
            }

            .ratio-16x9 {
                max-width: 100%;
            }
        }
    </style>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script>
        function openVideoPopup(videoUrl) {
            if (!videoUrl.endsWith('.mp4')) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Invalid video URL. Only MP4 files are supported.',
                });
                return;
            }

            Swal.fire({
                html: `
                    <div class="ratio ratio-16x9">
                        <video
                            src="${videoUrl}"
                            width="100%"
                            style="border:none;"
                            autoplay
                            controls
                            muted
                            loop
                        ></video>
                    </div>
                `,
                width: '520px',
                maxWidth: '85%',
                showConfirmButton: false,
                showCloseButton: true,
                backdrop: true,
                allowOutsideClick: false,
                customClass: {
                    popup: 'video-popup'
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            const toggleButton = document.getElementById('toggleButton');
            const extraVideos = document.querySelectorAll('.extra-video');
            let expanded = false;

            toggleButton.addEventListener('click', function () {
                extraVideos.forEach(video => {
                    video.style.display = expanded ? 'none' : 'block';
                });
                toggleButton.textContent = expanded ? 'View More' : 'View Less';
                expanded = !expanded;
            });
        });
    </script>
</section>

@endsection

@extends('layouts.front',['main_page' > 'yes'])
@section('content')


<style>
    body {
    background: linear-gradient(to right, rgba(49, 115, 18, .6), rgba(49, 115, 18, .6));
        background-color: white;
    }
</style>

<br><br>

<div class="boxed_wrapper">
<section class="formregister" style="font-family: 'Corbel Light'; color: #317312; font-weight: 30">

    <div class="logo-box" style="text-align: center;">
        <a href="/"> <figure class="logo"><img src="assets/images/logo/Logo-JOTNew.png" alt="" style="width: 150px"></figure></a>
        <h1 style="color: #317312; font-weight: bolder">Escape the Ordinary with Extraordinary Journeys.</h1>
    </div>
    <div class="row">

        <div class="col-sm-12 col-lg-2 col-md-2">

        </div>

        <div class="col-sm-12 col-lg-8 col-md-8" >

            <br>
            <br>
            <form method="POST" enctype="multipart/form-data" action="{{route('register_tourist')}}">
                @csrf
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                          <label for="f_name">First Name:</label>
                          <input type="text" id="f_name" name="f_name" required>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                          <label for="l_name">Last Name:</label>
                          <input type="text" id="l_name" name="l_name" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <label for="email">Your Email:</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <label for="country">Your Country:</label>
    {{--                                    <select id="country" name="country" required>--}}
    {{--                                        <option value="">Select your country</option>--}}
    {{--                                        <option value="USA">United States of America</option>--}}
    {{--                                        <option value="UK">United Kingdom</option>--}}
    {{--                                        <option value="Canada">Canada</option>--}}
    {{--                                    </select>--}}
                            <input type="text" id="country" name="country" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <label for="address">Your Address:</label>
                            <textarea type="text" id="address" name="address" required></textarea>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <label for="m_phone_1">Phone Number:</label>

{{--                            <input name="phone"  id="phone"/>--}}
                            <input type="tel" id="m_phone_1" name="m_phone_1" style="width: 410px;" required>
                        </div>
                    </div>
                </div>



                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="password" value="{{old('password')}}" required>

                            @if($errors->has('password'))
                                <span class="text-danger">{{$errors->first('password')}}</span>
                            @endif

                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <label for="password_repeat">Confirm Password:</label>
                            <input type="password" id="password" name="password_repeat" required>

                            @if($errors->has('password'))
                                <span class="text-danger">{{$errors->first('password')}}</span>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit">Register</button>
                </div>
                {{--                  <p>Already have an account? <a href="{{ route('login') }}">Sign In</a></p>--}}
            </form>
        </div>
    </div>
</section>
</div>

<script>
    var input = document.querySelector("#m_phone_1");
    window.intlTelInput(input, {
        separateDialCode: true
    });
</script>



@endsection
@extends('layouts.front',['main_page' > 'yes'])
@section('content')

    <br><br><br><br><br>
<!-- tour guide -->
<section class="tour-guide" style="font-family: 'Corbel Light';">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="align-title">
                    <h5 style="font-family: 'Corbel Light';">Tour Guide’s</h5>
                    <h3 style="font-family: 'Corbel Light';">Meet Our Excellent Guide’s</h3>

                    <h4 style="font-family: 'Corbel Light'; font-weight: bolder; color: #f67a59">Want to join with us as a guide ?? <a href="{{ route('guide-registration') }}">Click Here</a></h4>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/gallery/tg-1.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <span>Tour Guide</span>
                        <a href="{{ route('guide-profile-display') }}">Name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/gallery/tg-2.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <span>Tour Guide</span>
                        <a href="tour-guide.html">Name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="2000ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/gallery/tg-3.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <span>Tour Guide</span>
                        <a href="tour-guide.html">Name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="2500ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/gallery/tg-4.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <span>Tour Guide</span>
                        <a href="tour-guide.html">Name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- tour guide -->
@endsection

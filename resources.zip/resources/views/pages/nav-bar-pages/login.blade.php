@extends('layouts.front',['main_page' > 'yes'])
@section('content')

<style>
    .loginform-box {
        width: 500px; /* Adjust the width as needed */
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 40px 80px rgba(0, 0, 0, 0.1);
        font-size: 20px;
        text-align: center;
        background: linear-gradient(to bottom, rgba(110, 187, 45, 0.2), rgba(110, 187, 45, 0.2)); /* Use rgba for transparency */
        margin: 100px auto 50px;
    }


    .loginform-box form {
        display: flex;
        flex-direction: column;
    }

    .login-form-group {
        margin-bottom: 15px;
    }

    label {
        color: white;
        font-weight: bolder;
        text-shadow: 5px 5px 5px rgba(0, 0, 0, 0.2); /* Add text shadow */
    }

    input {
        width: 100%;
        padding: 8px;
        margin-top: 4px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.1); /* Add box shadow */
        font-size: 18px;
    }

    button {
        background-color: white;
        color: #4CAF50;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Add box shadow */
    }

    button:hover {
        background-color: #45a049;
    }

    p {
        text-align: center;
        margin-top: 10px;
        text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2); /* Add text shadow */
    }

    a {
        color: #3498db;
        text-decoration: none;
        text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2); /* Add text shadow */
    }

    a:hover {
        text-decoration: underline;
    }

    .logo_B img {
        display: block;
        margin-left: 130px;
    }

    .blurry-background {

    }

    .sign-up-link {
        display: inline-block;
        text-decoration: none;
        color: #333; /* Adjust the color as needed */
        padding: 5px 10px; /* Adjust the padding as needed */
        background-color: white;
        border-radius: 10px; /* Match the border-radius of the parent for a consistent look */
        transition: background-color 0.3s ease-in-out;
    }

    .sign-up-link:hover {
        background-color: #f4f4f4; /* Adjust the hover background color as needed */
    }

</style>


<section class="loginform" style="font-family: 'Corbel Light'; background-image: url('assets/images/banner/login-bg.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;">

    <div class="loginform-box" >

        <!-- Your existing form code -->
        <form action="{{ route('loginCheck') }}" method="POST">
            @csrf
            <div class="login-form-group">
                <label for="email">EMAIL:</label>
                <input type="email"  id="email" name="email" required>
            </div>

            <div class="login-form-group">
                <label for="password">PASSWORD:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="login-form-group">
                <button type="submit" style="background-color: white; color: #4CAF50">LOGIN</button>
            </div>

            <p style="text-align: center; font-size: 20px; color: white; font-weight: bolder;">Don't have an account?
                <br><a href="{{ route('register') }}" class="sign-up-link">Sign Up</a> as a Tourist
{{--                <br><a href="{{ route('guide-registration') }}">Sign Up</a> as a Guide--}}
            </p>
        </form>

        <div class="footer__logo">
            <a href="/"><figure class="logo_B"><img src="{{asset('assets/images/logo/LOGO-JOT - Footer.png')}}" alt=""></figure></a>
        </div>

    </div>

</section>

@endsection
@extends('layouts.front', ['main_page' => 'yes'])
@section('content')

    <!-- guide registration form -->
    <section class="package-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-details-right-container">
                        <div class="destination-common-title">

                            <center>
                                <h4 style="color: rgb(9, 65, 116); font-weight: bolder;">
                                    Join with Starluxe Travels
                                </h4>
                                {{-- <h3>Guide's Registration</h3> --}}
                                <h3 style="color: black; font-weight: bolder;">
                                    Guide's Registration
                                </h3>
                            </center>
                        </div>

                        <div class="package-details-right-form">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if ($message = Session::get('success'))
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>{{ $message }}</strong>
                                </div>
                            @endif

                            <form method="POST" enctype="multipart/form-data" action="{{route('guide_register')}}">
                                @csrf

                                <!-- Personal Information Section -->
                               
                                 <h4 style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;">
                                    Personal Information
                                </h4>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-user"></i></label>
                                        <input type="text" class="@error('f_name') is-invalid @enderror" id="f_name"
                                            name="f_name" placeholder="First Name*" required>
                                        @error('f_name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-user"></i></label>
                                        <input type="text" class="@error('l_name') is-invalid @enderror" id="l_name"
                                            name="l_name" placeholder="Last Name*" required>
                                        @error('l_name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px; align-items: flex-start;">
                                    <div class="form-label" style="flex: 1; display: flex;">
                                        <label style="margin-right: 10px; margin-top: 8px;"><i
                                                class="fa-solid fa-home"></i></label>
                                        <textarea id="address" name="address" rows="3" placeholder="Your Address*"
                                            style="flex: 1; padding: 8px; border-radius: 4px; min-height: 80px;"
                                            required></textarea>
                                        @error('address')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Contact Information Section -->
                                

                                  <h4 style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;">
                                    Contact Information
                                </h4>

                                <div class="form-row" style="display: flex; gap: 15px; align-items: center;">
                                    <!-- Primary Phone -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></label>
                                        <div style="display: flex; flex: 1; gap: 8px; padding-bottom: 8px;">
                                            <select id="m_phone_1_country_code" name="m_phone_1_country_code"
                                                style="width: 20px; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; font-size: 14px;">
                                                <option value="+7">+7</option>
                                                <option value="+20">+20</option>
                                                <option value="+27">+27</option>
                                                <option value="+30">+30</option>
                                                <option value="+31">+31</option>
                                                <option value="+32">+32</option>
                                                <option value="+33">+33</option>
                                                <option value="+34">+34</option>
                                                <option value="+36">+36</option>
                                                <option value="+39">+39</option>
                                                <option value="+40">+40</option>
                                                <option value="+41">+41</option>
                                                <option value="+43">+43</option>
                                                <option value="+44">+44</option>
                                                <option value="+45">+45</option>
                                                <option value="+46">+46</option>
                                                <option value="+47">+47</option>
                                                <option value="+48">+48</option>
                                                <option value="+49">+49</option>
                                                <option value="+51">+51</option>
                                                <option value="+52">+52</option>
                                                <option value="+53">+53</option>
                                                <option value="+54">+54</option>
                                                <option value="+55">+55</option>
                                                <option value="+56">+56</option>
                                                <option value="+57">+57</option>
                                                <option value="+58">+58</option>
                                                <option value="+60">+60</option>
                                                <option value="+61">+61</option>
                                                <option value="+62">+62</option>
                                                <option value="+63">+63</option>
                                                <option value="+64">+64</option>
                                                <option value="+65">+65</option>
                                                <option value="+66">+66</option>
                                                <option value="+81">+81</option>
                                                <option value="+82">+82</option>
                                                <option value="+84">+84</option>
                                                <option value="+86">+86</option>
                                                <option value="+90">+90</option>
                                                <option value="+91">+91</option>
                                                <option value="+92">+92</option>
                                                <option value="+93">+93</option>
                                                <option value="+94" selected>+94</option>
                                              
                                            </select>
                                            <input type="number" class="@error('m_phone_1') is-invalid @enderror"
                                                id="m_phone_1" name="m_phone_1" placeholder="Phone number*"
                                                style="flex: 1; padding: 8px; border: 1px solid #ced4da; border-radius: 4px;"
                                                required>
                                        </div>
                                        @error('m_phone_1')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>

                                    <!-- Secondary Phone -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></label>
                                        <div style="display: flex; flex: 1; gap: 8px; padding-bottom: 8px;">
                                            <select id="m_phone_2_country_code" name="m_phone_2_country_code"
                                                style="width: 80px; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; font-size: 14px;">
                                               <option value="+7">+7</option>
                                                <option value="+20">+20</option>
                                                <option value="+27">+27</option>
                                                <option value="+30">+30</option>
                                                <option value="+31">+31</option>
                                                <option value="+32">+32</option>
                                                <option value="+33">+33</option>
                                                <option value="+34">+34</option>
                                                <option value="+36">+36</option>
                                                <option value="+39">+39</option>
                                                <option value="+40">+40</option>
                                                <option value="+41">+41</option>
                                                <option value="+43">+43</option>
                                                <option value="+44">+44</option>
                                                <option value="+45">+45</option>
                                                <option value="+46">+46</option>
                                                <option value="+47">+47</option>
                                                <option value="+48">+48</option>
                                                <option value="+49">+49</option>
                                                <option value="+51">+51</option>
                                                <option value="+52">+52</option>
                                                <option value="+53">+53</option>
                                                <option value="+54">+54</option>
                                                <option value="+55">+55</option>
                                                <option value="+56">+56</option>
                                                <option value="+57">+57</option>
                                                <option value="+58">+58</option>
                                                <option value="+60">+60</option>
                                                <option value="+61">+61</option>
                                                <option value="+62">+62</option>
                                                <option value="+63">+63</option>
                                                <option value="+64">+64</option>
                                                <option value="+65">+65</option>
                                                <option value="+66">+66</option>
                                                <option value="+81">+81</option>
                                                <option value="+82">+82</option>
                                                <option value="+84">+84</option>
                                                <option value="+86">+86</option>
                                                <option value="+90">+90</option>
                                                <option value="+91">+91</option>
                                                <option value="+92">+92</option>
                                                <option value="+93">+93</option>
                                                <option value="+94" selected>+94</option>
                                                <option value="+95">+95</option>
                                                <option value="+98">+98</option>
                                                <option value="+212">+212</option>
                                                <option value="+213">+213</option>
                                                <option value="+216">+216</option>
                                                <option value="+218">+218</option>
                                                <option value="+220">+220</option>
                                                <option value="+221">+221</option>
                                                <option value="+222">+222</option>
                                                <option value="+223">+223</option>
                                                <option value="+224">+224</option>
                                                <option value="+225">+225</option>
                                                <option value="+226">+226</option>
                                                <option value="+227">+227</option>
                                                <option value="+228">+228</option>
                                                <option value="+229">+229</option>
                                                <option value="+230">+230</option>
                                                <option value="+231">+231</option>
                                                <option value="+232">+232</option>
                                                <option value="+233">+233</option>
                                                <option value="+234">+234</option>
                                                <option value="+235">+235</option>
                                                <option value="+236">+236</option>
                                                <option value="+237">+237</option>
                                                <option value="+238">+238</option>
                                                <option value="+239">+239</option>
                                                <option value="+240">+240</option>
                                                <option value="+241">+241</option>
                                                <option value="+242">+242</option>
                                                <option value="+243">+243</option>
                                                <option value="+244">+244</option>
                                                <option value="+245">+245</option>
                                                <option value="+246">+246</option>
                                                <option value="+247">+247</option>
                                                <option value="+248">+248</option>
                                                <option value="+249">+249</option>
                                                <option value="+250">+250</option>
                                                <option value="+251">+251</option>
                                                <option value="+252">+252</option>
                                                <option value="+253">+253</option>
                                                <option value="+254">+254</option>
                                                <option value="+255">+255</option>
                                                <option value="+256">+256</option>
                                                <option value="+257">+257</option>
                                                <option value="+258">+258</option>
                                                <option value="+260">+260</option>
                                                <option value="+261">+261</option>
                                                <option value="+262">+262</option>
                                                <option value="+263">+263</option>
                                                <option value="+264">+264</option>
                                                <option value="+265">+265</option>
                                                <option value="+266">+266</option>
                                                <option value="+267">+267</option>
                                                <option value="+268">+268</option>
                                                <option value="+269">+269</option>
                                                <option value="+290">+290</option>
                                                <option value="+291">+291</option>
                                                <option value="+297">+297</option>
                                                <option value="+298">+298</option>
                                                <option value="+299">+299</option>
                                                <option value="+350">+350</option>
                                                <option value="+351">+351</option>
                                                <option value="+352">+352</option>
                                                <option value="+353">+353</option>
                                                <option value="+354">+354</option>
                                                <option value="+355">+355</option>
                                                <option value="+356">+356</option>
                                            </select>
                                            <input type="number" class="@error('m_phone_2') is-invalid @enderror"
                                                id="m_phone_2" name="m_phone_2" placeholder="Secondary phone number"
                                                style="flex: 1; padding: 8px; border: 1px solid #ced4da; border-radius: 4px;">
                                        </div>
                                        @error('m_phone_2')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                {{-- Landline phone --}}
                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-top: 15px;">
                                    <!-- Landline Number -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></label>
                                        <div style="display: flex; flex: 1; gap: 8px; padding-bottom: 8px;">
                                            <select id="l_number_country_code" name="l_number_country_code"
                                                style="width: 80px; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; font-size: 14px;">
                                                <option value="+7">+7</option>
                                                <option value="+20">+20</option>
                                                <option value="+27">+27</option>
                                                <option value="+30">+30</option>
                                                <option value="+31">+31</option>
                                                <option value="+32">+32</option>
                                                <option value="+33">+33</option>
                                                <option value="+34">+34</option>
                                                <option value="+36">+36</option>
                                                <option value="+39">+39</option>
                                                <option value="+40">+40</option>
                                                <option value="+41">+41</option>
                                                <option value="+43">+43</option>
                                                <option value="+44">+44</option>
                                                <option value="+45">+45</option>
                                                <option value="+46">+46</option>
                                                <option value="+47">+47</option>
                                                <option value="+48">+48</option>
                                                <option value="+49">+49</option>
                                                <option value="+51">+51</option>
                                                <option value="+52">+52</option>
                                                <option value="+53">+53</option>
                                                <option value="+54">+54</option>
                                                <option value="+55">+55</option>
                                                <option value="+56">+56</option>
                                                <option value="+57">+57</option>
                                                <option value="+58">+58</option>
                                                <option value="+60">+60</option>
                                                <option value="+61">+61</option>
                                                <option value="+62">+62</option>
                                                <option value="+63">+63</option>
                                                <option value="+64">+64</option>
                                                <option value="+65">+65</option>
                                                <option value="+66">+66</option>
                                                <option value="+81">+81</option>
                                                <option value="+82">+82</option>
                                                <option value="+84">+84</option>
                                                <option value="+86">+86</option>
                                                <option value="+90">+90</option>
                                                <option value="+91">+91</option>
                                                <option value="+92">+92</option>
                                                <option value="+93">+93</option>
                                                <option value="+94" selected>+94</option>
                                                <option value="+95">+95</option>
                                                <option value="+98">+98</option>
                                                <option value="+212">+212</option>
                                                <option value="+213">+213</option>
                                                <option value="+216">+216</option>
                                                <option value="+218">+218</option>
                                                <option value="+220">+220</option>
                                                <option value="+221">+221</option>
                                                <option value="+222">+222</option>
                                                <option value="+223">+223</option>
                                                <option value="+224">+224</option>
                                                <option value="+225">+225</option>
                                                <option value="+226">+226</option>
                                                <option value="+227">+227</option>
                                                <option value="+228">+228</option>
                                                <option value="+229">+229</option>
                                                <option value="+230">+230</option>
                                                <option value="+231">+231</option>
                                                <option value="+232">+232</option>
                                                <option value="+233">+233</option>
                                                <option value="+234">+234</option>
                                                <option value="+235">+235</option>
                                                <option value="+236">+236</option>
                                                <option value="+237">+237</option>
                                                <option value="+238">+238</option>
                                                <option value="+239">+239</option>
                                                <option value="+240">+240</option>
                                                <option value="+241">+241</option>
                                                <option value="+242">+242</option>
                                                <option value="+243">+243</option>
                                                <option value="+244">+244</option>
                                                <option value="+245">+245</option>
                                                <option value="+246">+246</option>
                                                <option value="+247">+247</option>
                                                <option value="+248">+248</option>
                                                <option value="+249">+249</option>
                                                <option value="+250">+250</option>
                                                <option value="+251">+251</option>
                                                <option value="+252">+252</option>
                                                <option value="+253">+253</option>
                                                <option value="+254">+254</option>
                                                <option value="+255">+255</option>
                                                <option value="+256">+256</option>
                                                <option value="+257">+257</option>
                                                <option value="+258">+258</option>
                                                <option value="+260">+260</option>
                                                <option value="+261">+261</option>
                                                <option value="+262">+262</option>
                                                <option value="+263">+263</option>
                                                <option value="+264">+264</option>
                                                <option value="+265">+265</option>
                                                <option value="+266">+266</option>
                                                <option value="+267">+267</option>
                                                <option value="+268">+268</option>
                                                <option value="+269">+269</option>
                                                <option value="+290">+290</option>
                                                <option value="+291">+291</option>
                                                <option value="+297">+297</option>
                                                <option value="+298">+298</option>
                                                <option value="+299">+299</option>
                                                <option value="+350">+350</option>
                                                <option value="+351">+351</option>
                                                <option value="+352">+352</option>
                                                <option value="+353">+353</option>
                                                <option value="+354">+354</option>
                                                <option value="+355">+355</option>
                                                <option value="+356">+356</option>
                                            </select>
                                            <input type="number" class="@error('l_number') is-invalid @enderror"
                                                id="l_number" name="l_number" placeholder="Landline number"
                                                style="flex: 1; padding: 8px; border: 1px solid #ced4da; border-radius: 4px;">
                                        </div>
                                        @error('l_number')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>

                                    <!-- Email -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-regular fa-envelope"></i></label>
                                        <input type="email" class="@error('email') is-invalid @enderror" id="email"
                                            name="email" placeholder="Your Email*" required
                                            style="flex: 1; padding: 8px;  border-radius: 4px;">
                                        @error('email')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Emergency Contact Section -->
                                <h4 style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;">
                                    Emergency Contact
                                </h4>
                              

                                <div class="form-row" style="display: flex; gap: 15px; align-items: center;">
                                    <!-- Emergency Contact Name -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-user"></i></label>
                                        <input type="text" class="@error('ec_name') is-invalid @enderror" id="ec_name"
                                            name="ec_name" placeholder="Emergency Contact Name*" required
                                            style="flex: 1; padding: 8px;  border-radius: 4px;">
                                        @error('ec_name')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>

                                    <!-- Emergency Contact Number -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></label>
                                        <div style="display: flex; flex: 1; gap: 8px; padding-bottom: 8px;">
                                            <select id="ec_number_country_code" name="ec_number_country_code"
                                                style="width: 80px; padding: 8px; border: 1px solid #ced4da; border-radius: 4px; font-size: 14px;">
                                                <option value="+1">+1 US</option>
                                                <option value="+44">+44 UK</option>
                                                <option value="+94" selected>+94 LK</option>
                                            </select>
                                            <input type="number" class="@error('ec_number') is-invalid @enderror"
                                                id="ec_number" name="ec_number" placeholder="Emergency Contact Number"
                                                style="flex: 1; padding: 8px; border: 1px solid #ced4da; border-radius: 4px;">
                                        </div>
                                        @error('ec_number')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <!-- Work Details Section -->
                                <h4 style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;">
                                    Details Related to Work
                                </h4>

                                <div class="form-row" style="display: flex; gap: 15px; align-items: flex-start;">
                                    <div class="form-label" style="flex: 1; display: flex;">
                                        <label style="margin-right: 10px; margin-top: 8px;"><i
                                                class="fa-solid fa-circle-info"></i></label>
                                        <textarea id="about" name="about" rows="3"
                                            placeholder="About you (Minimum 20 characters)"
                                            style="flex: 1; padding: 8px; border-radius: 4px; min-height: 80px;"
                                            required></textarea>
                                        @error('about')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: flex-start; margin-top: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex;">
                                        <label style="margin-right: 10px; margin-top: 8px;"><i
                                                class="fa-solid fa-briefcase"></i></label>
                                        <textarea id="w_experience" name="w_experience" rows="3"
                                            placeholder="Work Experience (e.g., two years experience)"
                                            style="flex: 1; padding: 8px; border-radius: 4px; min-height: 80px;"
                                            required></textarea>
                                        @error('w_experience')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row" style="margin-top: 15px;">
                                    <div class="form-label">
                                        <h4 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                            Languages You Speak
                                        </h4>
                                        <div
                                            style="display: flex; justify-content: space-between; align-items: center; gap: 130px; flex-wrap: nowrap;font-family:'Times New Roman', Times, serif;">
                                            <div style="display: flex; align-items: center; gap: 5px;">
                                                <input type="checkbox" id="english" name="language[]" value="english">
                                                <label for="english">English</label>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 5px;">
                                                <input type="checkbox" id="tamil" name="language[]" value="tamil">
                                                <label for="tamil">Tamil</label>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 5px;">
                                                <input type="checkbox" id="sinhala" name="language[]" value="sinhala">
                                                <label for="sinhala">Sinhala</label>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 5px;">
                                                <input type="checkbox" id="french" name="language[]" value="french">
                                                <label for="french">French</label>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 5px;">
                                                <input type="checkbox" id="hindi" name="language[]" value="hindi">
                                                <label for="hindi">Hindi</label>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 5px;">
                                                <input type="checkbox" id="german" name="language[]" value="german">
                                                <label for="german">German</label>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="form-row"
                                    style="display: flex; align-items: center; gap: 15px; margin-top: 15px; font-family: 'Times New Roman', Times, serif;">
                                    <div class="form-label"
                                        style="display: flex; align-items: center; gap: 10px; width: 100%;">
                                        <label for="guide_category" style="min-width: 120px; font-weight: bold;">Guide
                                            Category:</label>
                                        <select class="form-control" id="guide_category" name="guide_category"
                                            style="padding: 8px; border-radius: 4px; font-family: 'Times New Roman', Times, serif; flex-grow: 1; border: 1px solid #ced4da;"
                                            required>
                                            <option value="National Guide">National Guide</option>
                                            <option value="Chauffeur Guide">Chauffeur Guide</option>
                                            <option value="Site Guide">Site Guide</option>
                                            <option value="Tour Driver">Tour Driver</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Documents Section -->
                                <h4
                                    style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;font-family:'Times New Roman', Times, serif;">
                                    Documents
                                </h4>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="guides_photos_pass_size">Passport Size Photo:</label>
                                        <input type="file"
                                            class="form-control @error('guides_photos_pass_size') is-invalid @enderror"
                                            id="guides_photos_pass_size" name="guides_photos_pass_size"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('guides_photos_pass_size')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="guides_photos_normal">Normal Photo:</label>
                                        <input type="file"
                                            class="form-control @error('guides_photos_normal') is-invalid @enderror"
                                            id="guides_photos_normal" name="guides_photos_normal"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('guides_photos_normal')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="guide_license_f">Guide License (Front):</label>
                                        <input type="file"
                                            class="form-control @error('guide_license_f') is-invalid @enderror"
                                            id="guide_license_f" name="guide_license_f"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('guide_license_f')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="guide_license_b">Guide License (Back):</label>
                                        <input type="file"
                                            class="form-control @error('guide_license_b') is-invalid @enderror"
                                            id="guide_license_b" name="guide_license_b"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('guide_license_b')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="driving_license_f">Driving License (Front):</label>
                                        <input type="file"
                                            class="form-control @error('driving_license_f') is-invalid @enderror"
                                            id="driving_license_f" name="driving_license_f"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('driving_license_f')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="driving_license_b">Driving License (Back):</label>
                                        <input type="file"
                                            class="form-control @error('driving_license_b') is-invalid @enderror"
                                            id="driving_license_b" name="driving_license_b"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('driving_license_b')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="nic_f">NIC (Front):</label>
                                        <input type="file" class="form-control @error('nic_f') is-invalid @enderror"
                                            id="nic_f" name="nic_f"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('nic_f')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="nic_b">NIC (Back):</label>
                                        <input type="file" class="form-control @error('nic_b') is-invalid @enderror"
                                            id="nic_b" name="nic_b"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('nic_b')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>
                                <!-- Vehicle Details Section -->
                                <h4 style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;">
                                    Vehicle Details
                                </h4>
                                

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="fileToUpload_v_insurance_f">Vehicle Insurance (Front):</label>
                                        <input type="file" class="form-control @error('fileToUpload_v_insurance_f') is-invalid @enderror"
                                            id="fileToUpload_v_insurance_f" name="fileToUpload_v_insurance_f"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('fileToUpload_v_insurance_f')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="fileToUpload_v_insurance_b">Vehicle Insurance (Back):</label>
                                        <input type="file" class="form-control @error('fileToUpload_v_insurance_b') is-invalid @enderror"
                                            id="fileToUpload_v_insurance_b" name="fileToUpload_v_insurance_b"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('fileToUpload_v_insurance_b')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_book_f">Vehicle Book (Front):</label>
                                        <input type="file" class="form-control @error('v_book_f') is-invalid @enderror"
                                            id="v_book_f" name="v_book_f"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_book_f')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_book_b">Vehicle Book (Back):</label>
                                        <input type="file" class="form-control @error('v_book_b') is-invalid @enderror"
                                            id="v_book_b" name="v_book_b"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_book_b')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <!-- Insurance Expiry Date -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center; gap: 10px;">
                                        <label for="end_date_insurance" style="min-width: 150px;">Insurance Expiry
                                            Date:</label>
                                        <input type="date" class="form-control" id="end_date_insurance"
                                            name="end_date_insurance"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px; flex-grow: 1;"
                                            required>
                                    </div>

                                    <!-- Vehicle Type -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center; gap: 10px;">
                                        <label for="vehicle_type" style="min-width: 100px;">Vehicle Type:</label>
                                        <select class="form-control" id="vehicle_type" name="vehicle_type"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px; flex-grow: 1;"
                                            required>
                                            <option value="Motorbike">Motorbike</option>
                                            <option value="Car">Car</option>
                                            <option value="Van">Van</option>
                                            <option value="Bus">Bus</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <!-- Vehicle Model -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center; gap: 8px;">
                                        <i class="fa-solid fa-car" style="color: #e4881e;"></i>
                                        <div style="flex: 1; display: flex; flex-direction: column;">
                                            <input type="text" class="@error('v_model') is-invalid @enderror" id="v_model"
                                                name="v_model" placeholder="Vehicle Model*"
                                                style="padding: 10px 12px; border-radius: 4px; font-size: 14px;" required>
                                            @error('v_model')
                                                <span class="invalid-feedback"
                                                    style="color: #dc3545; font-size: 12px; margin-top: 5px;" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>

                                    <!-- Vehicle Number -->
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center; gap: 8px;">
                                        <i class="fa-solid fa-car-side" style="color: #e4881e;"></i>
                                        {{-- <label for="v_number"
                                            style="margin-bottom: 5px; font-weight: 500; color: #495057;">
                                            <i class="fa-solid fa-car-side" style="margin-right: 8px;"></i>Vehicle Number*
                                        </label> --}}
                                        <input type="text" class="@error('v_number') is-invalid @enderror" id="v_number"
                                            name="v_number" placeholder="Vehicle Number*"
                                            style="padding: 10px 12px; border-radius: 4px; font-size: 14px;" required>
                                        @error('v_number')
                                            <span class="invalid-feedback"
                                                style="color: #dc3545; font-size: 12px; margin-top: 5px;" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_out__front_images">Vehicle Front View:</label>
                                        <input type="file" class="@error('v_out__front_images') is-invalid @enderror"
                                            id="v_out__front_images" name="v_out__front_images"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_out__front_images')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_out_back_images">Vehicle Rear View:</label>
                                        <input type="file" class="@error('v_out_back_images') is-invalid @enderror"
                                            id="v_out_back_images" name="v_out_back_images"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_out_back_images')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_out_right_images">Vehicle Right Side:</label>
                                        <input type="file" class="@error('v_out_right_images') is-invalid @enderror"
                                            id="v_out_right_images" name="v_out_right_images"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_out_right_images')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_out_left_images">Vehicle Left Side:</label>
                                        <input type="file" class="@error('v_out_left_images') is-invalid @enderror"
                                            id="v_out_left_images" name="v_out_left_images"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_out_left_images')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_in_front_images">Front Interior:</label>
                                        <input type="file" class="@error('v_in_front_images') is-invalid @enderror"
                                            id="v_in_front_images" name="v_in_front_images"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_in_front_images')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label for="v_in_back_images">Rear Interior:</label>
                                        <input type="file" class="@error('v_in_back_images') is-invalid @enderror"
                                            id="v_in_back_images" name="v_in_back_images"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                        @error('v_in_back_images')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="margin-bottom: 15px;font-family:'Times New Roman', Times, serif;">
                                    <div class="form-label">
                                        <label for="vehicle_rent_own">Ownership:</label>
                                        <select class="form-control" id="vehicle_rent_own" name="vehicle_rent_own"
                                            style="padding: 8px; border: 1px solid #ced4da; border-radius: 4px;" required>
                                            <option value="Owner">Owner</option>
                                            <option value="Rented">Rented</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Password Section -->
                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px; margin-top: 20px;">
                                    Account Security
                                </h5>

                                <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-lock"></i></label>
                                        <input type="password" class="@error('password') is-invalid @enderror" id="password"
                                            name="password" placeholder="Password*" required autocomplete="new-password"
                                            style="padding: 8px; border-radius: 4px;">
                                        @error('password')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-lock"></i></label>
                                        <input type="password" id="password_confirmation" name="password_confirmation"
                                            placeholder="Confirm Password*" required autocomplete="new-password"
                                            style="padding: 8px;  border-radius: 4px;">
                                    </div>
                                </div>

                                <div id="passwordError" class="invalid-feedback"
                                    style="display: none; color: red; margin-bottom: 15px;">
                                    <strong>Confirmed password does not match.</strong>
                                </div>

                                <button type="submit" class="submit-btn">Register</button>

                                <p
                                    style="text-align: center; margin-top: 15px;font-family:'Times New Roman', Times, serif;">
                                    Already have an account? <a href="{{ route('login') }}">Sign In</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            function checkPasswords() {
                var password = $('#password').val();
                var passwordConfirmation = $('#password_confirmation').val();

                if (passwordConfirmation && password !== passwordConfirmation) {
                    $('#passwordError').show();
                    return false;
                } else {
                    $('#passwordError').hide();
                    return true;
                }
            }

            $('#password_confirmation').on('keyup', function () {
                checkPasswords();
            });

            $('form').on('submit', function (event) {
                if (!checkPasswords()) {
                    event.preventDefault();
                }
            });
        });
    </script>
@endsection
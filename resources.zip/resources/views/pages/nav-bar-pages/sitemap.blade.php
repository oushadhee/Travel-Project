@extends('layouts.front',['main_page' > 'yes'])
@section('content')

   

    <!-- common banner -->
    <section class="common-banner" style="font-family: 'Corbel Light';">
        <div class="common-banner-image" style="background: url(assets/images/banner/sitemap_01-mainbanner.jpg); "></div>

        <div class="common-banner-title">
            <a href="index.html" style="font-family: 'Corbel Light';">Home </a>
            <h3 style="font-family: 'Corbel Light';">Get The Best Plans For Yours</h3>
        </div>
    </section>
    <!-- common banner -->

    <br><br><br><br>


@endsection

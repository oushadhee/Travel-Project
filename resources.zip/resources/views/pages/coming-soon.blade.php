@extends('layouts.tourist_and_guide_login_front',['main_page' > 'yes'])

@section('content')


    <style>
        /* Add custom CSS styles to move the content up and reduce bottom margin */
        .banner-content-wrapper {
            margin-top: -160px; /* Adjust this value as needed */
            margin-bottom: -120px; /* Adjust this value as needed */
        }
    </style>

<!-- banner -->
<section class="banner" style="background: url('assets/images/banner/main_bg.gif'); height: 660px; background-size: cover; background-repeat: no-repeat; margin-top: 10px; padding-top: 10px;">

    <div class="banner-carousel owl-theme owl-carousel" >
        <div class="slide-item" >
            <div class="container" >
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner-slide">
                            <div class="banner-content" style="text-align: center; position: relative; z-index: 1;">
                                <div class="banner-content-wrapper" style="position: relative; z-index: 2;">
                                    <div class="banner-content-wrapper-inner">
                                        <h4 style="text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5); color: white">Explore Beyond Boundaries</h4>
                                        <h2 style="color: white; font-size: 80px; font-weight: bolder; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);">
                                            Coming Soon ...... <br>
                                            <span>Starluxe Travels!
                                                <br>
                                            <svg class="banner-text-shape" width="500" height="38" viewBox="0 0 247 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path id="signature1" d="M3.18577 22.2125C3.18577 22.2125 155.675 -3.21963 241.039 14.2277" stroke="#f67a59" stroke-width="5" stroke-linecap="round"/>
                                                <path id="signature2" d="M3.55141 17.792C3.55141 17.792 158.876 1.54075 243.929 23.8236" stroke="#f67a59" stroke-width="5" stroke-linecap="round"/>
                                            </svg>
                                        </span>
                                        </h2>
                                        <br>
                                        <p style="text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); color: white">
                                            “Travel isn’t always pretty. It isn’t always comfortable.
                                            Sometimes it hurts, it even breaks your heart. But that’s okay.
                                            The journey changes you; it should change you.
                                            It leaves marks on your memory, on your consciousness, on your heart,
                                            and on your body. You take something with you. Hopefully,
                                            you leave something good behind.” <br>~ Anthony Bourdain ~
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="slide-item">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner-slide">
                            <div class="banner-content" style="text-align: center; position: relative; z-index: 1;">
                                <div class="banner-content-wrapper" style="position: relative; z-index: 2;">
                                    <div class="banner-content-wrapper-inner">
                                        <h4 style="text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5); color: white">Explore Beyond Boundaries</h4>
                                        <h2 style="color: white; font-size: 80px; font-weight: bolder; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);">
                                            Coming Soon ......<br>
                                            <span>Starluxe Travels!
                                                <br>
                                            <svg class="banner-text-shape" width="500" height="38" viewBox="0 0 247 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path id="signature1" d="M3.18577 22.2125C3.18577 22.2125 155.675 -3.21963 241.039 14.2277" stroke="#f67a59" stroke-width="5" stroke-linecap="round"/>
                                                <path id="signature2" d="M3.55141 17.792C3.55141 17.792 158.876 1.54075 243.929 23.8236" stroke="#f67a59" stroke-width="5" stroke-linecap="round"/>
                                            </svg>
                                        </span>
                                        </h2>
                                        <br>
                                        <p style="text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); color: white">
                                            “Travel isn’t always pretty. It isn’t always comfortable.
                                            Sometimes it hurts, it even breaks your heart. But that’s okay.
                                            The journey changes you; it should change you.
                                            It leaves marks on your memory, on your consciousness, on your heart,
                                            and on your body. You take something with you. Hopefully,
                                            you leave something good behind.” <br>~ Anthony Bourdain ~
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="slide-item">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner-slide">
                            <div class="banner-content" style="text-align: center; position: relative; z-index: 1;">
                                <div class="banner-content-wrapper" style="position: relative; z-index: 2;">
                                    <div class="banner-content-wrapper-inner">
                                        <h4 style="text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5); color: white">Explore Beyond Boundaries</h4>
                                        <h2 style="color: white; font-size: 80px; font-weight: bolder; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);">
                                            Coming Soon ......<br>
                                            <span>Starluxe Travels!
                                                <br>
                                            <svg class="banner-text-shape" width="500" height="38" viewBox="0 0 247 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path id="signature1" d="M3.18577 22.2125C3.18577 22.2125 155.675 -3.21963 241.039 14.2277" stroke="#f67a59" stroke-width="5" stroke-linecap="round"/>
                                                <path id="signature2" d="M3.55141 17.792C3.55141 17.792 158.876 1.54075 243.929 23.8236" stroke="#f67a59" stroke-width="5" stroke-linecap="round"/>
                                            </svg>
                                        </span>
                                        </h2>
                                        <br>
                                        <p style="text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); color: white">
                                            “Travel isn’t always pretty. It isn’t always comfortable.
                                            Sometimes it hurts, it even breaks your heart. But that’s okay.
                                            The journey changes you; it should change you.
                                            It leaves marks on your memory, on your consciousness, on your heart,
                                            and on your body. You take something with you. Hopefully,
                                            you leave something good behind.” <br>~ Anthony Bourdain ~
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- banner -->

@endsection

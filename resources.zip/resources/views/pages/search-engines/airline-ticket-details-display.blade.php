<!-- JOT details  -->
<section class="popular-ture home3-popular-ture">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="align-title">
                    <h5 style="color: #FE7524"> Experience the Wonder of Sri Lanka </h5>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/activitiesimg/01-trekking-hiking.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <a href="tour-guide.html">Place name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantiumtheresr.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/activitiesimg/cycling-01.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <a href="tour-guide.html">Place name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantiumtheresr.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="2500ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/activitiesimg/Baththalangunduwa-camping.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <a href="tour-guide.html">Place name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantiumtheresr.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                    <div class="tour-guid-image">
                        <img src="assets/images/activitiesimg/water-rafting.jpg" alt="image">
                    </div>
                    <div class="tour-guid-content">
                        <a href="tour-guide.html">Place name</a>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantiumtheresr.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- JOT details end -->

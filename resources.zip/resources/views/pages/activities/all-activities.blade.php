@extends('layouts.front',['main_page' > 'yes'])

@section('content')

<style>
    .blog-title-container {
        display: flex;
        justify-content: center;
        align-items: center;
        /* Additional styles if needed */
    }

    /*.blog-title {*/
    /*    !* Additional styles for the text if needed *!*/
    /*}*/

</style>


<section class="common-banner">
    <div class="common-banner-image" ></div>
    <div class="common-banner-title">
        <a href="/" style="font-family: 'Corbel Light';color: #25283A">Home </a>
        <span style="font-family: 'Corbel Light';color: #25283A">/ Our Activities</span>
        <h3 style="font-family: 'Corbel Light';color: #25283A">“The best journeys in life are those that answer questions you never thought to ask.”</h3>
        <h5 style="font-family: 'Corbel Light'; color: #25283A"> -- Rich Ridgeway -- </h5>
    </div>
</section>

<div class="blog" style="margin-top: -0.5px">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="blog-content">
                    <div class="blog-image">
                        <img src="assets/images/activitiesimg/Adventure-01.jpg" alt="image">
                    </div>
                    <div class="blog-info">
                        <div class="footer-info">
                            <a class="blog-title-container"href="{{ route('adventure') }}" style="color: #166EF3; font-family: 'Corbel Light'">
                                {{--                                    <a href="{{ route('adventure') }}" style="color: #166EF3; font-family: 'Corbel Light'">Adventure Activities</a>--}}
                                <span class="blog-title" style="color: #f67a59">Adventure Activities</span>
                            </a>
                            <p>Adventure awaits in Sri Lanka! Conquer peaks, chase turquoise waves,
                                and explore ancient secrets. <br> <br> </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="blog-content">
                    <div class="blog-image">
                        <img src="assets/images/activitiesimg/Fun-02.jpg" alt="image">
                    </div>
                    <div class="blog-info">
                        <div class="footer-info">
                            <a class="blog-title-container" href="{{ route('fun') }}" style="color: #166EF3; font-family: 'Corbel Light'">
                                <span class="blog-title" style="color: #f67a59">Fun Activities</span>
                            </a>
                            <p>Join us in creating moments of happiness as you
                                partake in a spectrum of lighthearted pursuits that add a touch of fun to your journey</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="blog-content">
                    <div class="blog-image">
                        <img src="assets/images/activitiesimg/Park-03.jpg" alt="image">
                    </div>
                    <div class="blog-info">
                        <div class="footer-info">
                            <a class="blog-title-container" href="{{ route('park') }}" style="color: #166EF3; font-family: 'Corbel Light'">
                                <span class="blog-title" style="color: #f67a59">Park Activities</span>
                            </a>
                            <p>Our park activities offer a harmonious blend of tranquility and excitement,
                                providing a perfect escape for nature enthusiasts of all ages.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection


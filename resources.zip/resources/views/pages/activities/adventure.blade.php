@extends('layouts.front',['main_page' > 'yes'])

@section('content')



<!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/adventure" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Adventure
                                </a>
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                                  Embrace the Thrill with Our Adventure Tours
                            </h3>
            
        </div>
          


<!-- adventure  -->
<div class="blog" style="margin-top: -20px">
    <div class="container">
        <div class="row">
            @foreach($adventure as $data)
                @if($data->parent_id == 1)
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-content">
                            <div class="blog-image">
                                <img src="{{ config('app.frontend_url') .  "{$data->activity_image}"}}" alt="image"/>
                            </div>
                            <div class="blog-info">
                                <div class="footer-info">
                                    <a href="{{ route('activities-place-display', ['id' => $data->id]) }}" class="blog-title">{{$data->category_name}}</a>
                                    <p class="descriptionParagraph">{{$data->description}}</p>
                                    {{-- <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    </div>
</div>

<style>

     a:hover {
                    color: #ff6f00 !important;
                }
    .readMoreButton {
        font-weight: bold;
        background: none;
        border: none;
        color: black;
        cursor: pointer;
        padding: 0;
    }

    .readMoreButton:hover {
        text-decoration: underline;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var descriptionParagraphs = document.querySelectorAll(".descriptionParagraph");

        descriptionParagraphs.forEach(function (paragraph) {
            var maxLength = 110; // Change this value to your desired character limit
            var fullText = paragraph.textContent;

            if (fullText.length > maxLength) {
                var shortText = fullText.substring(0, maxLength) + '...';
                paragraph.innerHTML = shortText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
                paragraph.setAttribute("data-full-text", fullText);
            }
        });
    });

    function toggleReadMore(button) {
        var paragraph = button.parentNode;
        var fullText = paragraph.getAttribute("data-full-text");

        if (button.textContent === "Read More") {
            button.textContent = "Read Less";
            paragraph.innerHTML = fullText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read Less</button>';
        } else {
            button.textContent = "Read More";
            paragraph.innerHTML = fullText.substring(0, 100) + '... <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
        }
    }
</script>


<!-- adventure end -->

@endsection

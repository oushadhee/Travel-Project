@extends('layouts.front',['main_page' > 'yes'])

@section('content')
<!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/park" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Park
                                </a>
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                                Discover the Best National Parks for Nature Lovers
                            </h3>
            
        </div>
          
      
        <!-- common banner -->

<div class="blog" style="margin-top: -3px">
    <div class="container">
        <div class="row">
            @foreach($park as $data)
                <div class="col-lg-4 col-md-6">
                    <div class="blog-content">
                        <div class="blog-image">
                            <img src="{{ config('app.frontend_url') . "{$data->activity_image}"}}" alt="image" />
                        </div>
                        <div class="blog-info">
                            <div class="footer-info">
                                <a class="blog-title">{{$data->place_name}}</a>
    
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

<style>
     a:hover {
                    color: #ff6f00 !important;
                }
    .readMoreButton {
        font-weight: bold;
        background: none;
        border: none;
        color: black;
        cursor: pointer;
        padding: 0;
    }

    .readMoreButton:hover {
        text-decoration: underline;
    }
</style>
<!-- park end -->

@endsection

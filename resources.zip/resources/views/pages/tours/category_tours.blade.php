@extends('layouts.app')
@section('content')
<div class="container" style="margin-top: 10px; padding-top: 10px;">
    <h1>{{ $category->category_name }} Tours in {{ $country->name }}</h1>
    
    <div class="row">
        @foreach($tours as $tour)
        <div class="col-md-4 mb-4">
            <div class="card">
                @if($tour->images->first())
                <img src="{{ asset('storage/'.$tour->images->first()->path) }}" class="card-img-top" alt="{{ $tour->title }}">
                @endif
                <div class="card-body">
                    <h5 class="card-title">{{ $tour->title }}</h5>
                    <p class="card-text">{{ Str::limit($tour->description, 100) }}</p>
                    <a href="{{ route('tour.details', $tour->id) }}" class="btn btn-primary">
                        View Details
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    
    {{ $tours->links() }} <!-- Pagination -->
</div>
@endsection
@extends('layouts.app')


@section('content')
<div class="container" style="margin-top: 10px; padding-top: 10px;">
    <h2>Tours in {{ $country->country_name }}</h2>
    <div class="row">
        @foreach($tours as $tour)
            <div class="col-md-4">
                <div class="card mb-3">
                    <img src="{{ asset($tour->tour_image) }}" class="card-img-top" alt="Tour Image">
                    <div class="card-body">
                        <h5 class="card-title">{{ $tour->tour_name }}</h5>
                        <p class="card-text">{{ \Illuminate\Support\Str::limit($tour->description, 100) }}</p>
                        <a href="{{ route('country_tours', ['id' => $tour->id, 'name' => urlencode($tour->tour_name)]) }}" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection

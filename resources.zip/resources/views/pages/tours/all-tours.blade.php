@extends('layouts.front',['main_page' > 'yes'])

@section('content')

      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
            
            <!-- Breadcrumb -->
            <div style="margin-bottom: 10px; font-size: 16px;">
                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                    Home
                </a>
                <span style="color: #999;">/</span>
                <a href="/country" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                   Sri Lanka Tour
                </a>
                <span style="color: #999;">/</span>
                <a href="/alltours?id=2" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                    Tour Packages
                </a>
            </div>

            <!-- Title -->
            <h3 style="color: #094174; font-size: 26px; font-weight: 700; margin-top: 15px; text-transform: uppercase; letter-spacing: 1px;">
                Explore Tailored Plans for Your Dream Vacation
            </h3>
        </div>

            <style>
                /* Hover effects */
                a:hover {
                    color: #ff6f00 !important;
                }
            </style>




<!-- all-tours  -->

<section>
    <div class="blog">
        <div class="container">
            <div class="row">
                @foreach($all_tours_display as $data)
                    @if($data->parent_id == 0)
                        @php
                            switch ($data->id) {
                                case 1:
                                    $route = route('tour_categories', ['id' => $data->id]); // Cultural
                                    break;
                                case 2:
                                    $route = route('wildlife-tours');
                                    break;
                                case 3:
                                    $route = route('eco-tours');
                                    break;
                                case 38:
                                    $route = route('business-tours');
                                    break;
                                case 41:
                                    $route = route('medical-n-wellness');
                                    break;
                                case 56:
                                    $route = route('educational-tours');
                                    break;
                                case 47:
                                    $route = route('sport-tours');
                                    break;
                                default:
                                    $route = '#'; // fallback
                            }
                        @endphp
                        <div class="col-lg-4 col-md-6">
                            <a href="{{ $route }}" class="blog-link" style="text-decoration: none;">
                                <div class="blog-content">
                                    <div class="blog-image">
                                        <img src="{{ config('app.frontend_url') . $data->tour_image }}" alt="{{ $data->category_name }}">
                                    </div>
                                    <div class="blog-info">
                                        <div class="footer-info">
                                            <span class="blog-title" style="color: #f67a59">{{ $data->category_name }}</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
</section>


<!-- all-tours end -->

@endsection
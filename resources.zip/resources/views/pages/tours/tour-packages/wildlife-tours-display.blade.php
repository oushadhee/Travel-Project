@extends('layouts.front',['main_page' > 'yes'])

@section('content')
 <!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/country" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Sri Lanka Tour
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/alltours?id=2" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Tour Packages
                                </a>
                                 <span style="color: #999;">/</span>
                                <a href="/wildlife-tours" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Wildlife Tours
                                </a>
                                
                                   </a>
                                @foreach($tittle as $dat)
                                <span style="color: #999;">/</span>
                                <span style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                   {{ $dat }}
                                </span>
                                @endforeach
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                               Step into the Heart of Heritage with Our Cultural Tours
                            </h3>
            
        </div>
           <style>
                /* Hover effects */
                a:hover {
                    color: #ff6f00 !important;
                }
         </style>
      
        <!-- common banner -->

<div class="col-lg-12">
    <div class="align-title">
         <br><br>
        @foreach($tittle as $dat)
            <h3 style="color: #FE7524; font-family: 'Source Serif Pro', serif;">{{ $dat }} </h3>
        @endforeach
       
    </div>
</div>

<div class="blog" style="margin-top: 10px; padding-top: 10px;">
    <div class="container">
         
        <div class="row">
            @foreach($tours as $data)
              <div class="col-lg-4 col-md-6">
    <div class="blog-content">
        <a href="{{ route('tour-package-details-display', ['id' => $data->id]) }}" style="text-decoration: none; color: inherit;">
            <div class="blog-image">
                <img src="{{ Storage::url($data->tour_image) }}" alt="image">
            </div>
            <div class="blog-info">
                <div class="footer-info">
                    <span class="blog-title">{{$data->tour_name}}</span>
                    <p>{{$data->description}}</p>
                </div>
            </div>
        </a>
    </div>
</div>

            @endforeach
        </div>
    </div>
</div>

<!-- cultural-tours end -->

@endsection



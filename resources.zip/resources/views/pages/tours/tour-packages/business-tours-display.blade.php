@extends('layouts.front',['main_page' > 'yes'])

@section('content')

    <!-- cultural-tours  -->
    <section class="popular-ture home3-popular-ture" style="margin-top: 10px; padding-top: 10px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="align-title">
                        <h3 style="color: #0a3a58; font-family: 'Corbel Light';">Business Tours</h3>
                        {{--                        <h5 style="color: #FE7524; font-family: 'Corbel Light';"> Experience the History of Sri Lanka </h5>--}}
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                        <div class="tour-guid-image">
                            <img src="assets/images/activitiesimg/01-trekking-hiking.jpg" alt="image">
                        </div>
                        <div class="tour-guid-content">
                            <h3 style="color: #103DFF; font-family: 'Corbel Light';">Tour Name</h3>
                            <p style="font-family: 'Corbel Light';">Description</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                        <div class="tour-guid-image">
                            <img src="assets/images/activitiesimg/01-trekking-hiking.jpg" alt="image">
                        </div>
                        <div class="tour-guid-content">
                            <h3 style="color: #103DFF; font-family: 'Corbel Light';">Tour Name</h3>
                            <p style="font-family: 'Corbel Light';">Description</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                        <div class="tour-guid-image">
                            <img src="assets/images/activitiesimg/01-trekking-hiking.jpg" alt="image">
                        </div>
                        <div class="tour-guid-content">
                            <h3 style="color: #103DFF; font-family: 'Corbel Light';">Tour Name</h3>
                            <p style="font-family: 'Corbel Light';">Description</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="tour-guide-container wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1000ms">
                        <div class="tour-guid-image">
                            <img src="assets/images/activitiesimg/01-trekking-hiking.jpg" alt="image">
                        </div>
                        <div class="tour-guid-content">
                            <h3 style="color: #103DFF; font-family: 'Corbel Light';">Tour Name</h3>
                            <p style="font-family: 'Corbel Light';">Description</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- cultural-tours end -->

@endsection



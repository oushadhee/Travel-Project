@extends('layouts.front',['main_page' > 'yes'])
@section('content')


      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/country" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Sri Lanka Tour
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/alltours?id=2" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Tour Packages
                                </a>
                            <span style="color: #999;">/</span>
                                <a href="{{ $route }}" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    {{ $MainCategories[0]['category_name'] ?? 'Category' }}
                                </a>

                             @foreach($tittle as $dat)
                                <span style="color: #999;">/</span>
                                <span style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    {{ $category_name }}
                                </span>
                                @endforeach
                                

                                  
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                               Step into the Heart of Heritage with Our Tours
                            </h3>
            
        </div>
          
      <style>
                /* Hover effects */
                a:hover {
                    color: #ff6f00 !important;
                }



</style>
 
      
 


    </div>
</div>
<!-- tour package details -->
<section class="package-details" style="margin-top: 10px; padding-top: 10px;">
    <div class="container" style="margin-top: 10px; padding-top: 10px;">
        <div class="row">
            <div class="col-lg-12">
                <div class="package-details-left-container">

                                    <div class="pkg-common-title" style="text-align: center; margin: 0px 0;">
                        @foreach($tittle as $dat)
                            <h5 style="color: #094174; font-size: 28px; font-weight: 700; margin-bottom: 10px; text-transform: uppercase;">
                                {{ $category_name }}
                            </h5>
                            <h5 style="color: #FE7524; font-family: 'Source Serif Pro', serif;">
                                {{ $dat->tour_name ?? 'Tour' }} Tour Package Details
                            </h5>
                        @endforeach
                    </div>

                    @foreach($tour_details as $data)
                        <h6 style="font-size: x-large; font-weight: bolder; color:  #166EF3">Day {{$data->sequence}} - {{$data->name}}</h6>
                        <div class="pkg-list-info">
                            <ul>
                                <p style="text-align: justify">{{$data->description}}</p>
                            </ul>
                        </div>


                            <?php
                            $places = \App\Models\TourMoreImages::whereNull('is_deleted')->where('tour_iteration_id', $data->id)->get();
//                            var_dump($places); die();
                            ?>
                        <!-- more details images -->
                                <div class="container">
                                    <div class="row">

                                        @foreach($places as $dataI)
                                            <div class="col-lg-4 col-md-6">
                                                <div class="blog-content_more_images">
                                                    <div class="blog-image">
                                                      <img src="{{ config('app.frontend_url') .  "{$dataI->image}"}}" alt="image"/>
                                                    </div>
                                                    <div class="blog-info">
                                                        <div class="footer-info" style="text-align: center;">
                                                            <a class="blog-title" style="font-weight: bolder; text-align: left; display: inline-block;">{{$dataI->name}}</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>

                            <!-- more details images -->
                        <br>
                    @endforeach


                </div>

                <div class="row">


                </div>
            </div>
        </div>
    </div>

<div style=" align-items: center">
    <div class="header-link-btn" style="text-align: center;">
        <a href="{{ route('book-now-form') }}" class="btn-1" >Book Now<span></span></a>
    </div>
</div>
<br>
<!-- tour package details -->
</section>

@endsection


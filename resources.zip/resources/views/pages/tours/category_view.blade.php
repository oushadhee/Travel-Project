@extends('layouts.app')


@section('content')
<h2>Tours in {{ $country->country_name }} - {{ $category->category_name }}</h2>

@foreach($tours as $tour)
    <div>
        <h4>{{ $tour->tour_name }}</h4>
        <p>{{ $tour->description }}</p>
        <img src="{{ asset($tour->tour_image) }}" width="150">
    </div>
@endforeach

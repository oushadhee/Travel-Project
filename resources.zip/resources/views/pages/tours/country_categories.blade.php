@extends('layouts.app')


@section('content')
<div class="container" style="margin-top: 10px; padding-top: 10px;">
    <h2 class="mb-4">Tour Categories in {{ $country->country_name }}</h2>

    @if($tourCategories->isEmpty())
        <p>No tour categories found for this country.</p>
    @else
        <ul>
            @foreach($tourCategories as $category)
                <li>{{ $category->name }}</li> {{-- Adjust field name based on your DB --}}
            @endforeach
        </ul>
    @endif
</div>
@endsection

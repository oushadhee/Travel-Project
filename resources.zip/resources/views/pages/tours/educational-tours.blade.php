@extends('layouts.front',['main_page' > 'yes'])

@section('content')

  
    <!-- educational-tours  -->
    <section class="popular-ture home3-popular-ture" style="background-color: white ;margin-top: 10px; padding-top: 10px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="align-title">
                        <h3 style="color: #166EF3; font-family: 'Corbel Light';"> Educational Tours</h3>
     </div>
                </div>

                <div class="col-12" style="position: relative; background-color: rgba(255, 255, 255, 0.8); background-image: url('{{ asset('path/to/your/image.jpg') }}'); background-size: cover; background-position: center; text-align: center; padding: 20px;">
                    <!-- Top-left icon -->
                    <div>
                        <img src="{{ asset('assets/images/icons/icon01.png') }}" alt="Icon 1">
                    </div>

                

                    <div >
                        <img src="{{ asset('assets/images/icons/icon02.png') }}" alt="Icon 2">
                    </div>


                    <!-- Bottom-left icon -->
                    <div>
                        <img src="{{ asset('assets/images/icons/icon03.png') }}" alt="Icon 3">
                    </div>

             

                    <p style="color:#213771; font-size: 40px; font-weight: bolder; font-family: 'Book Antiqua';">....Under Construction....</p>
                    <br>
                    <p style="color:#213771; font-size: 20px;">We are working on this page.</p>
                    <p style="color:#213771; font-size: 18px;">Stay tuned for some exciting updates.</p>
                    <p style="color:#213771; font-size: 18px;">Stay tuned for some exciting updates.</p>

                </div>

            </div>
        </div>
</section>

    <br><br><br> <br><br><br> <br><br>

    <!-- educational-tours end -->

@endsection


@extends('layouts.front', ['main_page' => 'yes'])
@section('content')

    <!-- tour package details -->
    <section class="package-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-details-right-container">
                        <div class="destination-common-title">
                           <center> <h4>Book The Package</h4></center>
                        </div>

                        <div class="package-details-right-form">
                            @if(!Auth::check())
                                <p style="margin-bottom: 20px;font-family:'Times New Roman', Times, serif;">If you already have an account, please log in to continue. <span
                                        style="color: red;">*</span></p>
                            @endif

                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if ($message = Session::get('success'))
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>{{ $message }}</strong>
                                </div>
                            @endif

                            <form method="POST" enctype="multipart/form-data"
                                action="{{ Auth::check() ? route('save-book-now-registered') : route('save-book-now') }}">
                                @csrf

                                @if(Auth::check())
                                    <input type="hidden" id="id" name="id" value="{{ Auth::user()->id }}" required>
                                @endif

                                @if(!Auth::check())

                                 <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                   Personal Details<span style="color: red;">*</span>
                                </h5>
                                    <div class="form-row" style="display: flex; gap: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                            <label><i class="fa-solid fa-user"></i></label>
                                            <input type="text" id="f_name" name="f_name" placeholder="First Name*" required>
                                        </div>
                                        <div class="form-label" style="flex: 1;">
                                            <label><i class="fa-solid fa-user"></i></label>
                                            <input type="text" id="l_name" name="l_name" placeholder="Last Name*" required>
                                        </div>
                                    </div>

                                    <div class="form-row" style="display: flex; gap: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                            <label><i class="fa-regular fa-envelope"></i></label>
                                            <input type="email" class="@error('email') is-invalid @enderror" id="email"
                                                name="email" placeholder="Your Email*" required>
                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-label" style="flex: 1; position: relative;">
                                        <label style="position: absolute; top: 50%; transform: translateY(-50%); color: #777; pointer-events: none;">
                                            <i class="fa-solid fa-globe"></i>
                                        </label>
                                        <input 
                                            class="@error('country') is-invalid @enderror" 
                                            id="country" 
                                            name="country" 
                                            list="country-list" 
                                            placeholder="Your Country*" 
                                            required
                                            style="width: 100%; padding: 10px 10px 10px 35px; border-radius: 4px; font-size: 14px;"
                                        >
                                        <datalist id="country-list">
                                            <?php $country_lists = App\Models\Country::all(); ?>
                                            @foreach ($country_lists as $country)
                                                <option value="{{ $country->nicename }}">{{ $country->nicename }}</option>
                                            @endforeach
                                        </datalist>
                                        @error('country')
                                            <span class="invalid-feedback" style="display: block; color: red; font-size: 12px; margin-top: 5px;">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    </div>

                                    <div class="form-row" style="display: flex; gap: 15px; align-items: center;">
    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
        <label style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></label>
        <div style="display: flex; flex: 1; gap: 8px; padding-bottom: 8px; align-items: center;">
            <!-- Country Code Select (reduced width) -->
            <select id="m_phone_1_country_code" name="m_phone_1_country_code"
                style="width: 100px; padding: 8px; border: 1px solid #ced4da; border-radius: 2px; font-size: 14px; height: 38px;">
                <option value="+7">+7</option>
                <option value="+20">+20</option>
                <option value="+27">+27</option>
                <option value="+30">+30</option>
                <option value="+31">+31</option>
                <option value="+32">+32</option>
                <option value="+33">+33</option>
                <option value="+34">+34</option>
                <option value="+36">+36</option>
                <option value="+39">+39</option>
                <option value="+40">+40</option>
                <option value="+41">+41</option>
                <option value="+43">+43</option>
                <option value="+44">+44</option>
                <option value="+45">+45</option>
                <option value="+46">+46</option>
                <option value="+47">+47</option>
                <option value="+48">+48</option>
                <option value="+49">+49</option>
                <option value="+51">+51</option>
                <option value="+52">+52</option>
                <option value="+53">+53</option>
                <option value="+54">+54</option>
                <option value="+55">+55</option>
                <option value="+56">+56</option>
                <option value="+57">+57</option>
                <option value="+58">+58</option>
                <option value="+60">+60</option>
                <option value="+61">+61</option>
                <option value="+62">+62</option>
                <option value="+63">+63</option>
                <option value="+64">+64</option>
                <option value="+65">+65</option>
                <option value="+66">+66</option>
                <option value="+81">+81</option>
                <option value="+82">+82</option>
                <option value="+84">+84</option>
                <option value="+86">+86</option>
                <option value="+90">+90</option>
                <option value="+91">+91</option>
                <option value="+92">+92</option>
                <option value="+93">+93</option>
                <option value="+94" selected>+94</option>
            </select>
            
            <!-- Phone Number Input -->
            <input type="number" class="@error('m_phone_1') is-invalid @enderror"
                id="m_phone_1" name="m_phone_1" placeholder="Phone number*"
                style="flex: 1; border: none; background: transparent; padding: 8px; height: 38px;"
                required>
        </div>
        @error('m_phone_1')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
        <div style="flex: 1; padding-bottom: 8px;">
            <textarea id="address" name="address" placeholder="Your Address*"
                style="width: 100%; border: none; background: transparent; padding: 8px 0; resize: none; min-height: 38px;"
                required></textarea>
        </div>
    </div>
</div>

                                    <div class="form-row" style="display: flex; gap: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                            <label><i class="fa-solid fa-lock"></i></label>
                                            <input type="password" class="@error('password') is-invalid @enderror" id="password"
                                                name="password" placeholder="Password*" required autocomplete="new-password">
                                            @error('password')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="form-label" style="flex: 1;">
                                            <label><i class="fa-solid fa-lock"></i></label>
                                            <input type="password" id="password_confirmation" name="password_confirmation"
                                                placeholder="Confirm Password*" required autocomplete="new-password">
                                        </div>
                                    </div>
                                @endif
                                        
                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                   Expected Time Period<span style="color: red;">*</span>
                                </h5>
                                  
                                <div class="form-row" style="display: flex; gap: 15px;">
                                  
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-regular fa-calendar"></i></label>
                                        <input type="date" id="start_date" name="start_date" value="{{ old('start_date') }}"
                                            style="flex: 1; border: none; padding: 8px 0; background: transparent;">
                                    </div>

                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-regular fa-calendar"></i></label>
                                        <input type="date" id="end_date" name="end_date" value="{{ old('end_date') }}"
                                            style="flex: 1; border: none; padding: 8px 0; background: transparent;">
                                    </div>
                                </div>

                                <div class="form-label">
                                    <label><i class="fa-solid fa-calendar-days"></i></label>
                                    <input type="text" id="number_of_days" name="number_of_days" value="{{ old('number_of_days') }}"
                                        placeholder="OR Expected No. of Days">
                                </div>

                                <div class="package-selection-container" style="margin: 10px 0;">
                                    <div class="form-label">
                                        <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                            Please select Location or Tour Package<span style="color: red;">*</span>
                                        </h5>
                                    </div>

                                    <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                <select id="expected_country" name="expected_country"
                                        style="width: 50%; 
                                            font-family: inherit; /* or your specific font stack */
                                            border: none; 
                                            border-bottom: 1px solid #ccc; 
                                            padding: 3px 0; 
                                            background: transparent;
                                            font-size: 14px; /* Match input field size */
                                            color: #333; /* Match input text color */">
                                    <option value="">Select a Country</option>
                                    <option value="Sri Lanka" {{ old('expected_country') == 'Sri Lanka' ? 'selected' : '' }}>Sri Lanka</option>
                                </select>
                                        </div>
                                        <div class="form-label">
                                            <a href="{{ route('excursions_list') }}" class="btn-info"
                                                id="selectLocationsBtn"
                                                style="padding: 8px 15px; background: #FE7524; color: white; text-decoration: none; border-radius: 4px;">
                                                Select Excursions
                                            </a>
                                        </div>
                                    </div>

                                    <div id="selectedExcursionsSection" style="margin-bottom: 20px; display: none;">
                                        <h4>Selected Excursions:</h4>
                                        <ul id="selectedExcursions"
                                            style="list-style-type: none; padding: 0; border: 1px solid #ddd; border-radius: 5px; padding: 10px; margin-top: 5px;">
                                            <!-- Will be populated dynamically -->
                                        </ul>
                                        <input type="hidden" name="selected_excursions" id="selectedExcursionsInput">
                                    </div>

                                    <div class="form-row" style="display: flex; gap: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                            <select class="@error('tour_package') is-invalid @enderror" id="tour_package"
                                                name="tour_package"
                                                style="width: 100%; border: none; border-bottom: 1px solid #ccc; padding: 8px 0; background: transparent;">
                                                <option value="">Select Tour Package</option>
                                                <?php $tour = App\Models\Tour::all(); ?>
                                                @foreach ($tour as $tour_package)
                                                    <option value="{{ $tour_package->id }}" {{ old('tour_package') == $tour_package->id ? 'selected' : '' }}>
                                                        {{ $tour_package->tour_name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('tour_package')
                                                <span class="invalid-feedback" role="alert"
                                                    style="color: red; font-size: 12px; display: block; margin-top: 5px;">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-label">
                                            <a href="{{ route('allsubtours') }}" class="btn-info"
                                                style="padding: 8px 15px; background: #FE7524; color: white; text-decoration: none; border-radius: 4px;">
                                                View All Tours
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                    Number of ticket<span style="color: red;">*</span>
                                </h5>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-users"></i></label>
                                        <input type="text" id="number_of_people" name="number_of_people" value="{{ old('number_of_people') }}"
                                            placeholder="Number in Party">
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-user"></i></label>
                                        <input type="text" id="number_of_adults" name="number_of_adults" value="{{ old('number_of_adults') }}"
                                            placeholder="Adults (18+)">
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-child"></i></label>
                                        <input type="text" id="number_of_children" name="number_of_children" value="{{ old('number_of_children') }}"
                                            placeholder="Children (3-18)">
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-baby"></i></label>
                                        <input type="text" id="number_of_toddlers" name="number_of_toddlers" value="{{ old('number_of_toddlers') }}"
                                            placeholder="Toddlers (1-3)">
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-baby-carriage"></i></label>
                                        <input type="text" id="number_of_infants" name="number_of_infants" value="{{ old('number_of_infants') }}"
                                            placeholder="Infants (3m-1y)">
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-baby"></i></label>
                                        <input type="text" id="number_of_newborns" name="number_of_newborns" value="{{ old('number_of_newborns') }}"
                                            placeholder="Newborns (0-3m)">
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px; align-items: flex-start;">
                                    <div class="form-label" style="flex: 1; display: flex;">
                                        <label style="margin-right: 10px; margin-top: 8px;"><i
                                                class="fa-solid fa-wheelchair"></i></label>
                                        <textarea id="requirements_for_babies" name="requirements_for_babies" rows="3"
                                            placeholder="Special Requirements for babies or people with disabilities"
                                            style="flex: 1; padding: 8px; border-radius: 4px; min-height: 80px;">{{ old('requirements_for_babies') }}</textarea>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-hotel"></i></label>
                                        <select class="form-control" id="property_type" name="property_type"
                                            onchange="toggleStarRating()"
                                            style="flex: 1; padding: 8px; border-radius: 4px; ">
                                            <option value="">Select Property Type</option>
                                            <option value="Homestays" {{ old('property_type') == 'Homestays' ? 'selected' : '' }}>Homestays</option>
                                            <option value="Hotels" {{ old('property_type') == 'Hotels' ? 'selected' : '' }}>Hotels</option>
                                            <option value="Guest Houses" {{ old('property_type') == 'Guest Houses' ? 'selected' : '' }}>Guest Houses</option>
                                            <option value="Lodges" {{ old('property_type') == 'Lodges' ? 'selected' : '' }}>Lodges</option>
                                            <option value="Resorts" {{ old('property_type') == 'Resorts' ? 'selected' : '' }}>Resorts</option>
                                            <option value="Apartments" {{ old('property_type') == 'Apartments' ? 'selected' : '' }}>Apartments</option>
                                            <option value="Villas" {{ old('property_type') == 'Villas' ? 'selected' : '' }}>Villas</option>
                                            <option value="Holiday Homes" {{ old('property_type') == 'Holiday Homes' ? 'selected' : '' }}>Holiday Homes</option>
                                            <option value="Chalets" {{ old('property_type') == 'Chalets' ? 'selected' : '' }}>Chalets</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;"
                                    id="star_rating_container" style="display: none;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-star"
                                                style="color: #FFD700;"></i></label>
                                        <select class="form-control" id="star_ratings" name="star_ratings" style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da;
                                           color: black; font-weight: normal; font-family: inherit;">
                                            <option value="">Select Star Rating</option>
                                            <option value="1 Star" {{ old('star_ratings') == '1 Star' ? 'selected' : '' }}>1 Star</option>
                                            <option value="2 Star" {{ old('star_ratings') == '2 Star' ? 'selected' : '' }}>2 Star</option>
                                            <option value="3 Star" {{ old('star_ratings') == '3 Star' ? 'selected' : '' }}>3 Star</option>
                                            <option value="4 Star" {{ old('star_ratings') == '4 Star' ? 'selected' : '' }}>4 Star</option>
                                            <option value="5 Star" {{ old('star_ratings') == '5 Star' ? 'selected' : '' }}>5 Star</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-car"></i></label>
                                        <select class="form-control" id="vehicle_type" name="vehicle_type"
                                            style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da; color: black; font-weight: normal; font-family: inherit;">
                                            <option value="">Select Vehicle Type</option>
                                            <option value="Sedan Cars" {{ old('vehicle_type') == 'Sedan Cars' ? 'selected' : '' }}>Sedan Cars</option>
                                            <option value="SUVs" {{ old('vehicle_type') == 'SUVs' ? 'selected' : '' }}>SUVs</option>
                                            <option value="Jeep" {{ old('vehicle_type') == 'Jeep' ? 'selected' : '' }}>Jeep</option>
                                            <option value="Van" {{ old('vehicle_type') == 'Van' ? 'selected' : '' }}>Van</option>
                                            <option value="Bus" {{ old('vehicle_type') == 'Bus' ? 'selected' : '' }}>Bus</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i
                                                class="fa-solid fa-money-bill-wave"></i></label>
                                        <select class="form-control" id="budget_range_from" name="budget_range_from"
                                            style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da; color: black; font-weight: normal; font-family: inherit;">
                                            <option value="">Select Budget From</option>
                                            @for ($i = 1000; $i <= 15000; $i += 1000)
                                                <option value="{{ $i }}" {{ old('budget_range_from') == $i ? 'selected' : '' }}>${{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i
                                                class="fa-solid fa-money-bill-wave"></i></label>
                                        <select class="form-control" id="budget_range_to" name="budget_range_to"
                                            style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da; color: #495057;font-family:'Times New Roman', Times, serif;">
                                            <option value="">Select Budget To</option>
                                            @for ($i = 2000; $i <= 16000; $i += 1000)
                                                <option value="{{ $i }}" {{ old('budget_range_to') == $i ? 'selected' : '' }}>${{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>

                                <div class="form-label">
                                    <label><i class="fa-solid fa-location-dot"></i></label>
                                    <input type="text" id="travel_destination" name="travel_destination" value="{{ old('travel_destination') }}"
                                        placeholder="Travel Destination">
                                </div>

                                <div style="margin: 15px 0;">
                                    <label
                                        style="display: block; margin-bottom: 8px; font-family:'Times New Roman', Times, serif;">Air
                                        Ticket:</label>
                                    <div style="display: flex; gap: 15px;">
                                        <label
                                            style="display: flex; align-items: center; gap: 5px;font-family:'Times New Roman', Times, serif;">
                                            <input type="radio" id="air_ticket_yes" name="air_tickets" value="Yes" {{ old('air_tickets') == 'Yes' ? 'checked' : '' }}>
                                            Yes
                                        </label>
                                        <label
                                            style="display: flex; align-items: center; gap: 5px;font-family:'Times New Roman', Times, serif;">
                                            <input type="radio" id="air_ticket_no" name="air_tickets" value="No" {{ old('air_tickets') == 'No' ? 'checked' : '' }}>
                                            No
                                        </label>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; align-items: flex-start; margin-bottom: 15px;">
                                    <div style="flex: 1; display: flex; gap: 10px;">
                                        <i class="fa-solid fa-circle-question"
                                            style="color: rgb(254, 117, 36); font-size: 1.1rem; margin-top: 10px;"></i>
                                        <textarea id="requirements_for_tour" name="requirements_for_tour" rows="3"
                                            placeholder="Special Requirements for your tour"
                                            style="flex: 1; padding: 8px; border-radius: 4px;color: black; font-family: inherit; min-height: 80px;">{{ old('requirements_for_tour') }}</textarea>
                                    </div>
                                </div>

                                <button type="submit" class="submit-btn">Send Now</button>

                                @if(!Auth::check())
                                    <p style="text-align: center; margin-top: 15px;font-family:'Times New Roman', Times, serif;">Already have an account? <a
                                            href="{{ route('login') }}">Sign In</a></p>
                                @endif
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        function toggleStarRating() {
            var propertyType = document.getElementById('property_type').value;
            var starRatingContainer = document.getElementById('star_rating_container');

            if (propertyType === 'Hotels') {
                starRatingContainer.style.display = 'block';
            } else {
                starRatingContainer.style.display = 'none';
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            // Load selected excursions from sessionStorage
            const selectedExcursions = JSON.parse(sessionStorage.getItem('selectedExcursions')) || [];
            const selectedExcursionsList = document.getElementById('selectedExcursions');
            const selectedExcursionsSection = document.getElementById('selectedExcursionsSection');

            // Display any previously selected excursions
            if (selectedExcursions.length > 0) {
                updateSelectedExcursionsList(selectedExcursions);
                selectedExcursionsSection.style.display = 'block';
            }

            // Listen for changes from the excursions list page
            window.addEventListener('storage', function (event) {
                if (event.key === 'selectedExcursions') {
                    const excursions = JSON.parse(event.newValue) || [];
                    updateSelectedExcursionsList(excursions);
                    selectedExcursionsSection.style.display = excursions.length > 0 ? 'block' : 'none';
                }
            });

            function updateSelectedExcursionsList(excursions) {
                selectedExcursionsList.innerHTML = '';
                excursions.forEach(function (excursion) {
                    const listItem = document.createElement('li');
                    listItem.style.padding = '8px 0';
                    listItem.style.borderBottom = '1px solid #eee';

                    const excursionName = document.createElement('span');
                    excursionName.textContent = excursion.name;

                    const removeBtn = document.createElement('button');
                    removeBtn.textContent = '×';
                    removeBtn.style.marginLeft = '10px';
                    removeBtn.style.background = '#ff4444';
                    removeBtn.style.color = 'white';
                    removeBtn.style.border = 'none';
                    removeBtn.style.borderRadius = '50%';
                    removeBtn.style.width = '25px';
                    removeBtn.style.height = '25px';
                    removeBtn.style.cursor = 'pointer';
                     removeBtn.style.justifyContent = 'center';
                    removeBtn.style.padding = '0';
                    removeBtn.style.fontSize = '16px';
                    removeBtn.onclick = function () {
                        removeExcursion(excursion.id);
                    };

                    listItem.appendChild(excursionName);
                    listItem.appendChild(removeBtn);
                    selectedExcursionsList.appendChild(listItem);
                });

                // Update hidden input with selected excursion IDs
                const excursionIds = excursions.map(e => e.id).join(',');
                document.getElementById('selectedExcursionsInput').value = excursionIds;
            }

            function removeExcursion(id) {
                let excursions = JSON.parse(sessionStorage.getItem('selectedExcursions')) || [];
                excursions = excursions.filter(e => e.id !== id);
                sessionStorage.setItem('selectedExcursions', JSON.stringify(excursions));
                updateSelectedExcursionsList(excursions);

                if (excursions.length === 0) {
                    document.getElementById('selectedExcursionsSection').style.display = 'none';
                }
            }
        });

        $(document).ready(function () {
            $('form').submit(function () {
                var selectedExcursions = [];
                $('#selectedExcursions li span').each(function () {
                    selectedExcursions.push($(this).text());
                });
                $('#selectedExcursionsInput').val(selectedExcursions.join(','));

                $('#selectedExcursions').empty();
                sessionStorage.removeItem('selectedExcursions');
            });
        });

        document.addEventListener('DOMContentLoaded', () => {
            // Load form data from localStorage
            const formData = localStorage.getItem('form_data');
            if (formData) {
                const parsedData = JSON.parse(formData);
                document.getElementById('start_date').value = parsedData.start_date;
                document.getElementById('end_date').value = parsedData.end_date;
                document.getElementById('number_of_days').value = parsedData.number_of_days;
                document.getElementById('expected_country').value = parsedData.expected_country;
            }

            // Listen for form field changes
            const formFields = document.querySelectorAll('#start_date, #end_date, #number_of_days, #expected_country');
            formFields.forEach(field => {
                field.addEventListener('change', () => {
                    const data = {
                        start_date: document.getElementById('start_date').value,
                        end_date: document.getElementById('end_date').value,
                        number_of_days: document.getElementById('number_of_days').value,
                        expected_country: document.getElementById('expected_country').value
                    };
                    localStorage.setItem('form_data', JSON.stringify(data));
                });
            });

            // Clear form data on submit
            document.querySelector('form').addEventListener('submit', () => {
                localStorage.removeItem('form_data');
            });
        });
    </script>
@endsection
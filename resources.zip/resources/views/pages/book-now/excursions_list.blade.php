@extends('layouts.front',['main_page' > 'yes'])
@section('content')

    <style>

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 6px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .card_booked {
            width: 80%;
            margin: 20px auto;
        }

        .card-header{
            text-align: center;
        }

        .card-title-booked {
            margin: 0;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            /*text-align: center;*/
        }

        .card-body-booked {
            padding: 20px;
        }

        /*.btn-group-booked {*/
        /*    margin: 5px;*/
        /*}*/

        /*.pagination {*/
        /*    margin-top: 20px;*/
        /*}*/

        .btn-info {
            display: inline-block;
            padding: 8px 16px;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            border: 1px solid #213771;
            color: #ffffff;
            background-color: #fe7524;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            width:100px;
            
        }

        .btn-info:hover {
            background-color: #fe7524;
            border-color: #138496;
        }

        #cartContainer {
            position: fixed;
            top: 155px;
            left: 10px;
            background-color: #f8f9fa;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            z-index: 10;
        }

        #cartTitle {
            font-weight: bold;
            margin-bottom: 5px;
        }

        #cartItems {
            list-style-type: none;
            padding: 0;
            margin: 0;
            color: blue;
        }

        #cartItems li {
            margin-bottom: 5px;
        }

        .excursion-count-badge {
            position: relative;
        }

        .excursion-count-badge #excursionCount {
            position: absolute;
            top: 6px;
            right: -1px;
            background-color:  #f67a59;
            border-radius: 20%;
            padding-left: 4px;
            padding-right: 2px;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }

        @media (max-width: 500px) {
            .a {
                margin-top: 300px;
            }
        }

        @media (max-width: 500px) {
            .b {
                margin-top: 100px;
            }
        }

    </style>


    <section>
        <div class="content">
            <div class="card_booked">


                <div class="card-header" style="position: relative;">

                    <h3 class="card-title-booked" style="margin-left: 40px;">Discover the world, one adventure at a time, with Explore Your Horizons</h3>
                </div>

                <br>


               <div class="service_area">
    <div class="container">
        <div class="row justify-content-center">
            @foreach ($excursions as $excursion)
                <div class="col-lg-4 col-md-6">
                    <div class="blog-content">
                        <div class="blog-image">
                            <img style="height: 311px; object-fit: cover; width: 100%;" src="{{ config('app.frontend_url') . "{$excursion->image}" }}" alt="image">
                        </div>
                        <div class="blog-info">
                            <div class="footer-info">
                                <a class="blog-title"
                                   style="font-weight: bolder; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: inline-block; max-width: 100%;">
                                    {{ $excursion->excursion_name }}
                                </a>
                                <p class="descriptionParagraph" style="justify-content: center;font-family:'Roboto';">
                                    {{ $excursion->province_e->district_and_province_name }},
                                    {{ $excursion->district_e->district_and_province_name }}
                                </p>
                                <div style="margin-top: 10px;">
                                    <input type="checkbox" class="excursionCheckbox" name="excursionCheckbox[]" value="{{ $excursion->id }}" data-id="{{ $excursion->id }}" data-name="{{ $excursion->excursion_name }}">
                                    <i style="color:blue;font-family:'Roboto';">Add excursions</i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>


                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <!-- Pagination Links -->
                    {{ $excursions->links() }}

                    <a href="{{ route('book-now-form') }}" class="btn btn-info">Go Back</a>
                </div>

            </div>
        </div>
    </section>

   

    <div id="cartContainer" class="a">
        <div class="alert alert-primary" id="cartTitle" role="alert">
            Selected Excursions:
        </div>
        <div class="alert alert-secondary" role="alert">
            <ul id="cartItems"></ul>
        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let selectedExcursions = JSON.parse(sessionStorage.getItem('selectedExcursions')) || [];
            const cartItemsContainer = document.getElementById('cartItems');

            // Function to update the cart display
            function updateCart() {
                cartItemsContainer.innerHTML = ''; // Clear previous content
                if (selectedExcursions.length > 0) {
                    selectedExcursions.forEach(function (excursion) {
                        const cartItem = document.createElement('li');
                        cartItem.textContent = excursion.name;
                        cartItemsContainer.appendChild(cartItem);
                    });
                } else {
                    cartItemsContainer.innerHTML = '<li>No excursions selected</li>';
                }
            }

            // Add event listener to checkboxes
            document.querySelectorAll('.excursionCheckbox').forEach(function (checkbox) {
                checkbox.addEventListener('change', function () {
                    if (this.checked) {
                        selectedExcursions.push({ id: this.value, name: this.dataset.name });
                    } else {
                        selectedExcursions = selectedExcursions.filter(excursion => excursion.id !== this.value);
                    }
                    sessionStorage.setItem('selectedExcursions', JSON.stringify(selectedExcursions));
                    // Update the cartItems container
                    updateCart();
                });
            });

            // Check checkboxes based on selectedExcursions
            selectedExcursions.forEach(function (excursion) {
                const checkbox = document.querySelector(`.excursionCheckbox[value="${excursion.id}"]`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });

            // Initial update of the cart display
            updateCart();

            // Add event listener to the "Add Excursions" button
            const addExcursionsButton = document.querySelector('.btn-info');
            addExcursionsButton.addEventListener('click', function () {
                // Check if at least one checkbox is checked
                const checkedCheckboxes = document.querySelectorAll('.excursionCheckbox:checked');
                if (checkedCheckboxes.length === 0) {
                    alert('You are going without selecting excursions.');
                } else {
                    window.location.href = '{{ route("book-now-form") }}';
                    alert('Successfully Added Selected Excursions');
                }
            });

            // Add event listener to the form submission to clear session storage
            const form = document.querySelector('form');
            form.addEventListener('submit', function() {
                sessionStorage.removeItem('selectedExcursions');
            });
        });
    </script>



@endsection
@extends('layouts.front',['main_page' > 'yes'])
@section('content')

    <style>
        /* styles.css */
        /* Example styles for the table */
        table {
            width: 100%;
            border-collapse: collapse;
            border: none;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .table tbody tr td {
            background-color: #f5f5f5;
        }
        .table thead th {

        background-color:#0d6efd;
    }

        tr:hover {
            background-color: #f5f5f5;
        }

        .card_booked {
            width: 80%;
            margin: 20px auto;
        }

        .card-header{
            text-align: center;
        }

        .card-title-booked {
            margin: 0;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            /*text-align: center;*/
        }


        .card-body-booked {
            padding: 20px;
        }

        .btn-group-booked {
            margin: 5px;
        }

        .btn {
            padding: 5px 10px;
            text-decoration: none;
            color: #fff;
        }

        .btn-info {
            background-color: #17a2b8;
        }

        .custom-btn-warning {
            background-color: #ffc107; /* Yellow color */
            border-color: #ffc107; /* Yellow color */
            color: #212529; /* Default Bootstrap text color */
        }

        /* section{
            margin-top:0px;
        } */
    </style>

    <br><br>

    <section>
        <div class="content">
            <div class="card_booked">
                <div class="card-header">
                    <h3 class="card-title-booked">Explore Your Horizons: Your Booked Trips</h3>
                </div>

                <br><br><br>
                <div class="card-body-booked">
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
                    @if ($message = Session::get('error'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
                    <!-- /.card-header -->
                    <div class="card-body-booked" style="margin-top: -80px; margin-bottom: 20px; margin-left: -50px; margin-right: -50px;" >
                        <table id="example1" class="table table-bordered table-striped" style=" margin-top: 150px">
                            <thead>
                            <tr>

                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Number of days</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php
                            $tour = \App\Models\BookNow::whereNull('is_deleted')
                                ->where('user_id', Auth::user()->id)
                                ->where('status', '!=', 'Cancelled')
                                ->get();
                            ?>

                            @foreach ($tour as $tourDetails)
                                <tr>


                                    <td>{{ $tourDetails->start_date }}</td>
                                    <td>{{ $tourDetails->end_date }}</td>
                                    <td>{{ $tourDetails->number_of_days }}</td>
                                    <td>{{ $tourDetails->status }}</td>
                                    <td class="text-right py-0 align-middle">
                                        <div class="btn-group-booked btn-group-sm">
                                            <a href="{{ route('edit_book_now_form', ['id' => $tourDetails->id]) }}" class="btn btn-info"
                                               onclick="return confirm('Are you sure you want to edit this tour?')">
                                                <i class="fas fa-eye"></i>
                                            </a>


                                            <form id="cancel-form-{{ $tourDetails->id }}" action="{{ route('cancel_tour', ['id' => $tourDetails->id]) }}" method="POST" style="display: none;">
                                                @csrf
                                                @method('DELETE')
                                            </form>

                                            <a href="#" class="btn btn-warning custom-btn-warning" onclick="cancelTour({{ $tourDetails->id }}); return false;">
                                                <i class="fas fa-x"></i>
                                            </a>

                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </section>

    <script>
        function cancelTour(tourId) {
            if (confirm('Are you sure you want to cancel this tour?')) {
                document.getElementById('cancel-form-' + tourId).submit();
            }
        }

    </script>

@endsection


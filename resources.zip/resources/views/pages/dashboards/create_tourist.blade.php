@extends('layouts.front', ['main_page' > 'yes'])
@section('content')

<style>
    .container {
        margin-top: 50px; /* Adjust as needed */
    }
    .panel-body {
        padding: 20px;
    }
    .social-login-box {
        text-align: center;
    }
    .social-login-box img {
        width: 150px; /* Adjust image size as needed */
        height: 150px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .input-group {
        width: 100%;
    }
    .add-passport,
    .add-tickets {
        margin-top: 7px;
    }
    .card-footer {
        text-align: right;
    }
    .text{
        background-color: white;
        margin-top: 1px;
        margin-bottom: 5px;
        padding: 5px;
        padding-bottom: 15px;
        align-items: center;
        text-align: center;
        color: #213771;
        font-weight: bold;
    }
</style>
<br><br><br><br><br><br>
{{--message--}}
@if (count($errors) > 0)
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif
{{--end--}}

<div class="container">
    <div class="align-title">
        <h3 style="color:#f67a59; font-family: 'Corbel Light'">Add Documents</h3>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span class="glyphicon glyphicon-th"></span>
                        Add Passport & Air Ticket
                    </h3>
                </div>
                <div class="text">
                    <h3>Thank you for choosing Us...</h3>
                    <div class="para">
                        Please upload your passport & Air Tickets copies <span style="color:red;">*</span>
                    </div>
                </div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-xs-4 col-sm-4 col-md-4 separator social-login-box">

                        </div>
                        <!-- Add new form code -->
                        <form id="touerForm" action="{{ route('save_booking_data') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="booked_id" value="{{ $booking_id }}">

                            <div class="form-group col-md-6">
                                <label for="passport_copy">Passport Copies</label>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="input-group">
                                            <input type="file" class="passport_copy form-control" name="passport_copy[]">
                                        </div>
                                    </div>
                                    <div class="col-4" style="margin-top:-8px;">
                                        <button type="button" class="add-passport btn btn-primary"><i class="fas fa-plus-square"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="air_tickets_copy">Air Tickets Copies</label>
                                <div class="row">
                                    <div class="col-8">
                                        <div class="input-group">
                                            <input type="file" class="air_tickets_copy form-control" name="air_tickets_copy[]">
                                        </div>
                                    </div>
                                    <div class="col-4" style="margin-top:-8px;">
                                        <button type="button" class="add-tickets btn btn-primary"><i class="fas fa-plus-square"></i></button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 card-footer">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function(){
        $(".add-passport").click(function(){
            var html = '<div class="col-8">' +
                            '<div class="input-group">' +
                                '<input type="file" class="passport_copy form-control" name="passport_copy[]">' +
                            '</div>' +
                        '</div>';
            $(this).closest('.row').append(html);
        });

        $(".add-tickets").click(function(){
            var html = '<div class="col-8">' +
                            '<div class="input-group">' +
                                '<input type="file" class="air_tickets_copy form-control" name="air_tickets_copy[]">' +
                            '</div>' +
                        '</div>';
            $(this).closest('.row').append(html);
        });
    });
</script>

@endsection

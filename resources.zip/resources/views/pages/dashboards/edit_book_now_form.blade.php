@extends('layouts.front', ['main_page' => 'yes'])
@section('content')

      <section class="package-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-details-right-container">
                        {{-- <div class="destination-common-title">
                            <h4>Edit Booking :</h4>
                        </div> --}}

                        <div class="package-details-right-form">
                            {{--message--}}
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if ($message = Session::get('success'))
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>{{ $message }}</strong>
                                </div>
                            @endif
                            {{--end--}}

                            <div class="logo-box" style="text-align: center; margin-bottom: 20px;">
                                {{-- <a href="/"> <figure class="logo"><img src="{{asset('assets/images/logo/StarluxeTravelLogo.jpg')}}" alt="" style="width: 150px"></figure></a> --}}
                                <br>
                                <h1 style="color: #213771; font-weight: bolder;font-family:'Times New Roman', Times, serif">Escape the Ordinary with Extraordinary Journeys.</h1>
                                @guest
                                    <p style="margin-bottom: 20px;font-family:'Times New Roman', Times, serif;">If you already have an account, please log in to continue. <span style="color: red;">*</span></p>
                                @endguest
                            </div>

                            <form method="POST" enctype="multipart/form-data" action="{{route('edit-book-now', ['id' => $bookedTour->id])}}">
                                @csrf
                                @method('PUT')

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">Expected Time Period</h5>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-regular fa-calendar"></i></label>
                                        <input type="date" id="start_date" name="start_date" value="{{ old('start_date', $bookedTour->start_date) }}"
                                            style="flex: 1; border: none; padding: 8px 0; background: transparent;">
                                    </div>

                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-regular fa-calendar"></i></label>
                                        <input type="date" id="end_date" name="end_date" value="{{ old('end_date', $bookedTour->end_date) }}"
                                            style="flex: 1; border: none; padding: 8px 0; background: transparent;">
                                    </div>
                                </div>

                                <div class="form-label">
                                    <label><i class="fa-solid fa-calendar-days"></i></label>
                                    <input type="text" id="number_of_days" name="number_of_days" value="{{ old('number_of_days', $bookedTour->number_of_days) }}"
                                        placeholder="OR Expected No. of Days">
                                </div>

                                <div class="package-selection-container" style="margin: 10px 0;">
                                    <div class="form-label">
                                        <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                            Please select Location or Tour Package<span style="color: red;">*</span>
                                        </h5>
                                    </div>

                                    <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                            <select id="expected_country" name="expected_country"
                                                style="width: 50%; 
                                                    font-family: inherit;
                                                    border: none; 
                                                    border-bottom: 1px solid #ccc; 
                                                    padding: 3px 0; 
                                                    background: transparent;
                                                    font-size: 14px;
                                                    color: #333;">
                                                <option value="{{ $bookedTour->expected_country }}" selected>{{ $bookedTour->expected_country }}</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                            </select>
                                        </div>
                                        <div class="form-label">
                                            <a href="{{ route('edit_excursion_list', ['id' => $bookedTour->id]) }}" class="btn-info"
                                                style="padding: 8px 15px; background: #FE7524; color: white; text-decoration: none; border-radius: 4px;">
                                                Select Excursions
                                            </a>
                                        </div>
                                    </div>

                                    <div id="selectedExcursionsSection" style="margin-bottom: 20px;">
                                        <h4>Selected Excursions:</h4>
                                        <ul id="selectedExcursions"
                                            style="list-style-type: none; padding: 0; border: 1px solid #ddd; border-radius: 5px; padding: 10px; margin-top: 5px;">
                                            @if(isset($selectedExcursions))
                                                @foreach($selectedExcursions as $excursion)
                                                    @if(!empty(trim($excursion)))
                                                        <li>{{ trim($excursion) }}</li>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </ul>
                                        <input type="hidden" name="selected_excursions" id="selectedExcursionsInput" value="{{ implode(',', $selectedExcursions) }}">
                                    </div>

                                    <div class="form-row" style="display: flex; gap: 15px;">
                                        <div class="form-label" style="flex: 1;">
                                            <select class="@error('tour_package') is-invalid @enderror" id="tour_package"
                                                name="tour_package"
                                                style="width: 100%; border: none; border-bottom: 1px solid #ccc; padding: 8px 0; background: transparent;">
                                                <option value="">No Package Need</option>
                                                <?php $tours = \App\Models\Tour::whereNull('is_deleted')->get(); ?>
                                                @foreach ($tours as $tour_package)
                                                    <option value="{{ $tour_package->tour_name }}" {{ $bookedTour->tour_package == $tour_package->tour_name ? 'selected' : '' }}>
                                                        {{ $tour_package->tour_name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('tour_package')
                                                <span class="invalid-feedback" role="alert"
                                                    style="color: red; font-size: 12px; display: block; margin-top: 5px;">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <div class="form-label">
                                            <a href="{{ route('all-tours') }}" class="btn-info"
                                                style="padding: 8px 15px; background: #FE7524; color: white; text-decoration: none; border-radius: 4px;">
                                                View All Tours
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                    Number of ticket<span style="color: red;">*</span>
                                </h5>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-users"></i></label>
                                        <input type="text" id="number_of_people" name="number_of_people" value="{{ $bookedTour->number_of_people }}"
                                            placeholder="Number in Party">
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-user"></i></label>
                                        <input type="text" id="number_of_adults" name="number_of_adults" value="{{ $bookedTour->number_of_adults }}"
                                            placeholder="Adults (18+)">
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-child"></i></label>
                                        <input type="text" id="number_of_children" name="number_of_children" value="{{ $bookedTour->number_of_children }}"
                                            placeholder="Children (3-18)">
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-baby"></i></label>
                                        <input type="text" id="number_of_toddlers" name="number_of_toddlers" value="{{ $bookedTour->number_of_toddlers }}"
                                            placeholder="Toddlers (1-3)">
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-baby-carriage"></i></label>
                                        <input type="text" id="number_of_infants" name="number_of_infants" value="{{ $bookedTour->number_of_infants }}"
                                            placeholder="Infants (3m-1y)">
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-baby"></i></label>
                                        <input type="text" id="number_of_newborns" name="number_of_newborns" value="{{ $bookedTour->number_of_newborns }}"
                                            placeholder="Newborns (0-3m)">
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px; align-items: flex-start;">
                                    <div class="form-label" style="flex: 1; display: flex;">
                                        <label style="margin-right: 10px; margin-top: 8px;"><i
                                                class="fa-solid fa-wheelchair"></i></label>
                                        <textarea id="requirements_for_babies" name="requirements_for_babies" rows="3"
                                            placeholder="Special Requirements for babies or people with disabilities"
                                            style="flex: 1; padding: 8px; border-radius: 4px; min-height: 80px;">{{ $bookedTour->requirements_for_babies }}</textarea>
                                    </div>
                                </div>

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">Accommodation and Vehicle</h5>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-hotel"></i></label>
                                        <select class="form-control" id="property_type" name="property_type"
                                            onchange="toggleStarRating()"
                                            style="flex: 1; padding: 8px; border-radius: 4px; ">
                                            <option value="">Select Property Type</option>
                                            <option value="Homestays" {{ $bookedTour->property_type == 'Homestays' ? 'selected' : '' }}>Homestays</option>
                                            <option value="Hotels" {{ $bookedTour->property_type == 'Hotels' ? 'selected' : '' }}>Hotels</option>
                                            <option value="Guest Houses" {{ $bookedTour->property_type == 'Guest Houses' ? 'selected' : '' }}>Guest Houses</option>
                                            <option value="Lodges" {{ $bookedTour->property_type == 'Lodges' ? 'selected' : '' }}>Lodges</option>
                                            <option value="Resorts" {{ $bookedTour->property_type == 'Resorts' ? 'selected' : '' }}>Resorts</option>
                                            <option value="Apartments" {{ $bookedTour->property_type == 'Apartments' ? 'selected' : '' }}>Apartments</option>
                                            <option value="Villas" {{ $bookedTour->property_type == 'Villas' ? 'selected' : '' }}>Villas</option>
                                            <option value="Holiday Homes" {{ $bookedTour->property_type == 'Holiday Homes' ? 'selected' : '' }}>Holiday Homes</option>
                                            <option value="Chalets" {{ $bookedTour->property_type == 'Chalets' ? 'selected' : '' }}>Chalets</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;"
                                    id="star_rating_container" style="display: none;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-star"
                                                style="color: #FFD700;"></i></label>
                                        <select class="form-control" id="star_ratings" name="star_ratings" style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da;
                                           color: black; font-weight: normal; font-family: inherit;">
                                            <option value="">Select Star Rating</option>
                                            <option value="1 Star" {{ $bookedTour->star_ratings == '1 Star' ? 'selected' : '' }}>1 Star</option>
                                            <option value="2 Star" {{ $bookedTour->star_ratings == '2 Star' ? 'selected' : '' }}>2 Star</option>
                                            <option value="3 Star" {{ $bookedTour->star_ratings == '3 Star' ? 'selected' : '' }}>3 Star</option>
                                            <option value="4 Star" {{ $bookedTour->star_ratings == '4 Star' ? 'selected' : '' }}>4 Star</option>
                                            <option value="5 Star" {{ $bookedTour->star_ratings == '5 Star' ? 'selected' : '' }}>5 Star</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i class="fa-solid fa-car"></i></label>
                                        <select class="form-control" id="vehicle_type" name="vehicle_type"
                                            style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da; color: black; font-weight: normal; font-family: inherit;">
                                            <option value="">Select Vehicle Type</option>
                                            <option value="Sedan Cars" {{ $bookedTour->vehicle_type == 'Sedan Cars' ? 'selected' : '' }}>Sedan Cars</option>
                                            <option value="SUVs" {{ $bookedTour->vehicle_type == 'SUVs' ? 'selected' : '' }}>SUVs</option>
                                            <option value="Jeep" {{ $bookedTour->vehicle_type == 'Jeep' ? 'selected' : '' }}>Jeep</option>
                                            <option value="Van" {{ $bookedTour->vehicle_type == 'Van' ? 'selected' : '' }}>Van</option>
                                            <option value="Bus" {{ $bookedTour->vehicle_type == 'Bus' ? 'selected' : '' }}>Bus</option>
                                        </select>
                                    </div>
                                </div>

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">Budget Range</h5>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i
                                                class="fa-solid fa-money-bill-wave"></i></label>
                                        <select class="form-control" id="budget_range_from" name="budget_range_from"
                                            style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da; color: black; font-weight: normal; font-family: inherit;">
                                            <option value="">Select Budget From</option>
                                            @for ($i = 1000; $i <= 15000; $i += 1000)
                                                <option value="{{ $i }}" {{ $bookedTour->budget_range_from == $i ? 'selected' : '' }}>${{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>

                                <div class="form-row"
                                    style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;">
                                    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
                                        <label style="margin-right: 10px;"><i
                                                class="fa-solid fa-money-bill-wave"></i></label>
                                        <select class="form-control" id="budget_range_to" name="budget_range_to"
                                            style="flex: 1; padding: 8px; border-radius: 4px; border: 1px solid #ced4da; color: #495057;font-family:'Times New Roman', Times, serif;">
                                            <option value="">Select Budget To</option>
                                            @for ($i = 2000; $i <= 16000; $i += 1000)
                                                <option value="{{ $i }}" {{ $bookedTour->budget_range_to == $i ? 'selected' : '' }}>${{ $i }}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">Other</h5>

                                <div class="form-label">
                                    <label><i class="fa-solid fa-location-dot"></i></label>
                                    <input type="text" id="travel_destination" name="travel_destination" value="{{ $bookedTour->travel_destination }}"
                                        placeholder="Travel Destination">
                                </div>

                                <div style="margin: 15px 0;">
                                    <label
                                        style="display: block; margin-bottom: 8px; font-family:'Times New Roman', Times, serif;">Air
                                        Ticket:</label>
                                    <div style="display: flex; gap: 15px;">
                                        <label
                                            style="display: flex; align-items: center; gap: 5px;font-family:'Times New Roman', Times, serif;">
                                            <input type="radio" id="air_ticket_yes" name="air_tickets" value="Yes" {{ $bookedTour->air_tickets == 'Yes' ? 'checked' : '' }}>
                                            Yes
                                        </label>
                                        <label
                                            style="display: flex; align-items: center; gap: 5px;font-family:'Times New Roman', Times, serif;">
                                            <input type="radio" id="air_ticket_no" name="air_tickets" value="No" {{ $bookedTour->air_tickets == 'No' ? 'checked' : '' }}>
                                            No
                                        </label>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; align-items: flex-start; margin-bottom: 15px;">
                                    <div style="flex: 1; display: flex; gap: 10px;">
                                        <i class="fa-solid fa-circle-question"
                                            style="color: rgb(254, 117, 36); font-size: 1.1rem; margin-top: 10px;"></i>
                                        <textarea id="requirements_for_tour" name="requirements_for_tour" rows="3"
                                            placeholder="Don't hesitate to share any further requirements for your tour"
                                            style="flex: 1; padding: 8px; border-radius: 4px;color: black; font-family: inherit; min-height: 80px;">{{ $bookedTour->requirements_for_tour }}</textarea>
                                    </div>
                                </div>

                                <p style="color: black; font-weight: bolder; margin-bottom: 15px;font-family:'Times New Roman', Times, serif">Make sure you fill in everything you need before submitting<span style="color: red;">*</span></p>

                                <button type="submit" class="submit-btn">Update Booking</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>

        <script type="text/javascript">
            function custom_template(obj){
                var data = $(obj.element).data();
                var text = $(obj.element).text();
                if(data && data['img_src']){
                    img_src = data['img_src'];
                    template = $("<div><img src=\"" + img_src + "\" style=\"width:25%;height:20px;\"/>" + text + "</div>");
                    return template;
                }
            }
            var options = {
                'templateSelection': custom_template,
                'templateResult': custom_template,
            }
            $('#id_select2_example').select2(options);
            $('.select2-container--default .select2-selection--single').css({'height': '25px'});

        </script>

        <script>
            function toggleStarRating() {
                var propertyType = document.getElementById('property_type').value;
                var starRatingContainer = document.getElementById('star_rating_container');


                if (propertyType === 'Hotels') {
                    starRatingContainer.style.display = 'block';
                } else {
                    starRatingContainer.style.display = 'none';
                }
            }


            toggleStarRating();


            document.getElementById('property_type').addEventListener('change', toggleStarRating);
        </script>


        <script>
            document.addEventListener('DOMContentLoaded', function () {
                let selectedExcursions = JSON.parse(sessionStorage.getItem('selectedExcursions')) || [];
                const selectedExcursionsList = document.getElementById('selectedExcursions');
                const selectedExcursionsSection = document.getElementById('selectedExcursionsSection');

                if (selectedExcursions.length > 0) {
                    selectedExcursions.forEach(function (excursion) {
                        const listItem = document.createElement('li');
                        listItem.textContent = excursion.name;
                        selectedExcursionsList.appendChild(listItem);
                    });
                    selectedExcursionsSection.style.display = 'block'; // Display the section
                }
            });
        </script>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>

            $(document).ready(function() {
                $('form').submit(function() {
                    var selectedExcursions = [];
                    $('#selectedExcursions li').each(function() {
                        selectedExcursions.push($(this).text());
                    });
                    $('#selectedExcursionsInput').val(selectedExcursions.join(','));

                    // Clear the selected excursions list
                    $('#selectedExcursions').empty();
                    // Clear sessionStorage storing selected excursions
                    sessionStorage.removeItem('selectedExcursions');
                });
            });
        </script>
       <script>
        document.addEventListener('DOMContentLoaded', function () {

            const selectedExcursionsInput = document.getElementById('selectedExcursionsInput').value;
            const selectedExcursionsList = document.getElementById('selectedExcursions');
            const selectedExcursions = Array.from(new Set(selectedExcursionsInput.split(',')));


            selectedExcursionsList.innerHTML = ''; // Clear existing items
            selectedExcursions.forEach(function (excursion) {
                if (excursion.trim()) {
                    const listItem = document.createElement('li');
                    listItem.textContent = excursion.trim();
                    selectedExcursionsList.appendChild(listItem);
                }
            });
        });
    </script>

@endsection

@extends('layouts.front',['main_page' > 'yes'])
@section('content')


<style>

    body {
        background: linear-gradient(to right, rgba(0,0,0,0), rgba(0,0,0,0));
    }
        .table {
        border: none;
    }

    .table tbody tr td {
        background-color: #f5f5f5;
    }
    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
        background-color:#0d6efd;
    }

</style>


<br><br>

<section class="contact" style="font-family: 'Corbel Light'; color: #213771;">
    {{-- <div class="content"> --}}


{{--message--}}
@if (count($errors) > 0)
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif
{{--end--}}

{{-- payment details form and table--}}

<div class="container">
    <div class="contact__wrapper shadow-lg mt-n9">

        @php
        $payment = \App\Models\QuotationDetails::whereIn('booked_id', function ($query) {
            $query->select('id')
                ->from('book_nows')
                ->where('user_id', Auth::user()->id);
            })
    ->where('status', 'Confirmed by Tourist')
    //->orderBy('created_at', 'DESC')
    ->get();

    $counter = 1;

    @endphp

{{-- table code --}}

<div class="">
    <div class="">
      <div class="" style="margin-top: -10px; margin-bottom: -80px; margin-left: px; margin-right: px; ">
        <table class="table table-bordered" style="font-size: 16px; border:none;">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">DATE</th>
              <th scope="col">TOTAL AMOUNT</th>
              <th scope="col">STATUS</th>
              <th scope="col">ACTION</th>
            </tr>
          </thead>

          <tbody style="font-weight: bold;">

            @foreach ($payment as $payments)
            <tr>
              <th scope="row">{{$counter++}}</th>
              <td>{{$payments->updated_at->format('Y-m-d')}}</td>
              <td>$ {{ $totalAmounts[$payments->id] }}</td>
              <td>Confirmed By Me</td>
              <td>
             <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" onclick="setQuotationId({{$payments->id}})"><i class="fa-solid fa-plus"></i></button>
{{-- new button add --}}
            @if ($payments->swift_copy)
            <button type="button" class="btn btn-info" data-toggle="modal" data-target="#viewModal{{$payments->id}}"style="width:100px;height:40px;" >View swift</button>

              @else
                           Swift copy not uploaded

             @endif
            </td>


            </tr>
             @endforeach
          </tbody>

        </table>
      </div>
    </div>
  </div>
{{-- end table --}}
 </div>
</div>


 <!-- Modal -->
 <div class="modal fade" style="color: #4f36cd" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Upload Your Payment Swift Here !!!</h5>
                        <button type="button" class="close " data-dismiss="modal" aria-label="Close" style="font-size: 16px; ">
                        <span aria-hidden="true">&times;</span>
                        </button>
            </div>

    <div class="modal-body">
    <section class="formregister" style="font-family: 'Corbel Light';">
    <form method="POST" enctype="multipart/form-data" action="{{route('pay_reviews')}}">
    @csrf

   <div class="form-group">
   {{-- <input type="hidden"  id="id" name="id" value="{{ Auth::user()->id }}" required> --}}
   <input type="hidden" id="quotationId" name="id" value="" required>
   </div>
   <div class="form-group">
    <div class="col-md-12 col-sm-12">
        <label for="swift_copy">Payment Swift Copy :</label>
        <input type="file"  id="swift_copy" name="swift_copy[]" required multiple>
    </div>
</div>

<div class="form-group">
    <div class="col-md-12 col-sm-12">
        <button type="submit" style="font-size: 16px; ">Upload</button>
    </div>
</div>
</form>
</section>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal" style="font-size: 16px; ">Close</button>
</div>
</div>
</div>
</div>


{{-- new modal --}}

@foreach ($payment as $payments)
@if ($payments->swift_copy)
<!-- View Modal -->
<div class="modal fade" style="color: #4f36cd" id="viewModal{{$payments->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">View Uploaded Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <img src="{{$payments->swift_copy}}" alt="UploadedImage" width="100%">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" data-toggle="modal" data-target="#editModal{{$payments->id}}" style="font-size: 17px;">Edit</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal" style="font-size: 17px;">Close</button>
            </div>
        </div>
    </div>
</div>



<!-- Edit Modal -->
<div class="modal fade" style="color: #4f36cd" id="editModal{{$payments->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Uploaded Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <form method="POST" enctype="multipart/form-data" action="{{ route('update_image', ['id' => $payments->id]) }}">
                    @csrf
                    <div class="form-group">
                        <label for="swift_copy" style="font-size: 17px;">Payment Swift Copy:</label>
                        <input type="file" id="swift_copy" name="swift_copy" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" style="font-size: 17px;">Save</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" style="font-size: 17px;">Close</button>
            </div>
        </div>
    </div>
</div>

@endif
@endforeach




<script>

                function displayAmount(id) {
                    const encodedId = encodeURIComponent(id);
                    fetch('/tourer_payment/' + encodedId)
                        .then(response => response.text())
                        .then(totalAmount => {
                            const paymentElement = document.getElementById('payment' + id);
                            paymentElement.innerHTML = `<div>$${totalAmount}</div>`;
                        });
                }


    function setQuotationId(id) {
        document.getElementById('quotationId').value = id;
    }

    function setQuotationId(id) {
        document.getElementById('quotationId').value = id;
    }


</script>
    {{-- </div> --}}
</section>



@endsection


@extends('layouts.front',['main_page' > 'yes'])
@section('content')


<style>

    body {
        background: linear-gradient(to right, rgba(0,0,0,0), rgba(0,0,0,0));
    }

    .table thead th {

        background-color:#0d6efd;
    }
</style>

<section class="contact" style="font-family: 'Corbel Light'; color: #213771;">
        {{--message--}}
        @if (count($errors) > 0)
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>{{ $message }}</strong>
            </div>
        @endif
        {{--end--}}

        {{-- payment details form and table--}}

        <div class="container">
            <div class="contact__wrapper shadow-lg mt-n9">

                @php
             $counter = 1;

            @endphp

        {{-- table code --}}

        <div class="">
            <div class="">
              <div class="" style="margin-top: -10px; margin-bottom: -80px; margin-left: 0px; margin-right: 0px; ">
                <table class="table table-bordered table-striped" style="border:none; font-weight:bold;">
                  <thead>
                    <tr>
                      <th scope="col">ID</th>
                      <th scope="col">TOUER BOOKING DATE</th>
                      <th scope="col">TOUER CONFIRMED DATE</th>
                      <th scope="col">ACTION</th>
                    </tr>
                  </thead>

                  <tbody style="font-size:16px; font-weight:bold;">

                    @foreach($confirmedBookings as $booking)
                     <tr>
                     <th scope="row">{{$counter++}}</th>
                     {{-- <td>{{ $booking->id }}</td> --}}
                     <td>{{ $booking->created_at->toDateString() }}</td>
                     <td>{{$booking->updated_at->format('Y-m-d')}}</td>
                      <td>
                      <a href="{{ route('create_tourist', ['id' => $booking->id]) }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i></a>
                    </td>

                    </tr>
                    @endforeach
                  </tbody>

                </table>
              </div>
            </div>
          </div>
        {{-- end table --}}
         </div>
        </div>

</section>

@endsection


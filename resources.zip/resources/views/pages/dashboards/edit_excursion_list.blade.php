

@extends('layouts.front',['main_page' > 'yes'])
@section('content')

    <style>

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 6px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .card_booked {
            width: 80%;
            margin: 20px auto;
        }

        .card-header{
            text-align: center;
        }

        .card-title-booked {
            margin: 0;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            /*text-align: center;*/
        }

        .card-body-booked {
            padding: 20px;
        }

        /*.btn-group-booked {*/
        /*    margin: 5px;*/
        /*}*/

        /*.pagination {*/
        /*    margin-top: 20px;*/
        /*}*/

        .btn-info {
            display: inline-block;
            padding: 8px 16px;
            font-size: 16px;
            text-align: center;
            text-decoration: none;
            border: 1px solid #213771;
            color: #ffffff;
            background-color: #213771;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .btn-info:hover {
            background-color: #138496;
            border-color: #138496;
        }

        #cartContainer {
            position: fixed;
            top: 160px;
            left: ;: 10px;
            background-color: #f8f9fa;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            z-index: 10;
        }

        #cartTitle {
            font-weight: bold;
            margin-bottom: 5px;
        }

        #cartItems {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        #cartItems li {
            margin-bottom: 5px;
        }

        /*.row {*/
        /*    display: flex;*/
        /*    flex-wrap: wrap;*/
        /*}*/

        /*.col-8, .col-4 {*/
        /*    flex: 0 0 auto;*/
        /*    width: 50%;*/
        /*}*/

    </style>

    <br><br><br><br>

    <section>
        <div class="content" id="excursionContainer">
            <div class="card_booked">
                <div class="card-header" style="position: relative;">
                    <h3 class="card-title-booked" style="margin-left: 40px;">Discover the world, one adventure at a time, with Explore Your Horizons</h3>
                </div>
                <br><br><br>
                <?php
                    $excursions = \App\Models\Excursion::whereNull('is_deleted')->paginate(6);
                ?>
                <div class="service_area">
                    <div class="container">
                        <div class="row justify-content-center">
                            @foreach ($excursions as $excursion)
                            <div class="col-lg-3 col-md-6" style="border: 2px solid #A3B3B5; margin: 30px;">
                                <div class="single_service" style="margin-bottom: 20px;">
                                    <div class="service_thumb">
                                        <img style="height: 200px; padding-top:20px;" src="{{ env('FRONTEND_URL') . "{$excursion->image}"}}" alt="">
                                    </div>
                                    <div class="service_content text-center" style="background-color: #E3F1F3;">
                                        <div style="background-color: #E3F1F3;  padding-bottom: 10px;">
                                            <h3 style="margin-top:0px; padding-top:20px">{{ $excursion->excursion_name }}</h3>
                                            <p>{{ $excursion->province_e->district_and_province_name}}</p>
                                            <p>{{ $excursion->district_e->district_and_province_name }}</p>
                                            <input type="checkbox" class="excursionCheckbox" name="excursionCheckbox[]" value="{{ $excursion->excursion_name }}" data-name="{{ $excursion->excursion_name }}">
                                            <i style="color:blue">Add excursions</i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="card-body-booked">
                    <form id="excursionForm" action="{{ route('edit_book_now_form', $id) }}" method="GET">
                        <input type="hidden" name="selected_excursions" id="selectedExcursionsInput" value="">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            {{ $excursions->links() }}
                            <button type="submit" class="btn btn-info">Go Back</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <div id="cartContainer" class="a">
        <div class="alert alert-primary" id="cartTitle" role="alert">
            Selected Excursions:
        </div>
        <div class="alert alert-secondary" role="alert">
            <ul id="cartItems">
                @if($selectedLocation)
                    @foreach(array_unique(explode(',', $selectedLocation->location)) as $excursion)
                        @if(!empty($excursion))
                            <li data-name="{{ $excursion }}">{{ $excursion }} <button class="remove-btn" data-name="{{ $excursion }}"></button></li>
                        @endif
                    @endforeach
                @endif
            </ul>
        </div>
    </div>

      
<script>

document.addEventListener('DOMContentLoaded', function () {
    // Retrieve initially selected excursions passed from the server
    let initiallySelectedExcursions = @json($initiallySelectedExcursions).map(e => e.excursion_name);

    // Load previously selected excursions from session storage or use the initially selected ones
    let selectedExcursions = JSON.parse(sessionStorage.getItem('selectedExcursions')) || initiallySelectedExcursions;

    // Function to update the hidden input with the selected excursions
    function updateSelectedExcursionsInput() {
        const uniqueExcursions = [...new Set(selectedExcursions)]; // Ensure uniqueness
        document.getElementById('selectedExcursionsInput').value = uniqueExcursions.join(',');
        sessionStorage.setItem('selectedExcursions', JSON.stringify(uniqueExcursions));
    }

    // Function to add an excursion to the cart if not already present
    function addExcursionToCart(excursionName) {
        const cartItems = document.getElementById('cartItems');
        if (!selectedExcursions.includes(excursionName)) {
            selectedExcursions.push(excursionName);
            const listItem = document.createElement('li');
            listItem.setAttribute('data-name', excursionName);
            listItem.innerHTML = `${excursionName} <button class="remove-btn" data-name="${excursionName}"></button>`;
            cartItems.appendChild(listItem);
            attachRemoveEvent(listItem.querySelector('.remove-btn'));
        }
    }

    // Function to remove an excursion from the cart
    function removeExcursionFromCart(excursionName) {
        selectedExcursions = selectedExcursions.filter(name => name !== excursionName);
        const cartItems = document.getElementById('cartItems');
        const listItem = cartItems.querySelector(`li[data-name="${excursionName}"]`);
        if (listItem) {
            cartItems.removeChild(listItem);
        }

        // Uncheck the corresponding checkbox
        const checkbox = document.querySelector(`.excursionCheckbox[data-name="${excursionName}"]`);
        if (checkbox) {
            checkbox.checked = false;
        }
    }

    // Function to attach event listener to remove buttons
    function attachRemoveEvent(button) {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const excursionName = this.getAttribute('data-name');
            removeExcursionFromCart(excursionName);
            updateSelectedExcursionsInput();
        });
    }

    // Function to update the cart display
    function updateCart() {
        const cartItemsContainer = document.getElementById('cartItems');
        cartItemsContainer.innerHTML = ''; // Clear previous content
        if (selectedExcursions.length > 0) {
            selectedExcursions.forEach(function (excursionName) {
                const listItem = document.createElement('li');
                listItem.setAttribute('data-name', excursionName);
                listItem.innerHTML = `${excursionName} <button class="remove-btn" data-name="${excursionName}"></button>`;
                cartItemsContainer.appendChild(listItem);
                attachRemoveEvent(listItem.querySelector('.remove-btn'));
            });
        } else {
            cartItemsContainer.innerHTML = '<li>No excursions selected</li>';
        }
    }

    // Function to check checkboxes based on selected excursions
    function checkInitiallySelectedExcursions() {
        selectedExcursions.forEach(function (excursionName) {
            const checkbox = document.querySelector(`.excursionCheckbox[value="${excursionName}"]`);
            if (checkbox) {
                checkbox.checked = true;
            }
        });
    }

    // Attach remove event to initially loaded remove buttons
    document.querySelectorAll('.remove-btn').forEach(attachRemoveEvent);

    // Event listener for checkboxes
    document.querySelectorAll('.excursionCheckbox').forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            const excursionName = this.getAttribute('data-name');
            if (this.checked) {
                addExcursionToCart(excursionName);
            } else {
                removeExcursionFromCart(excursionName);
            }
            updateSelectedExcursionsInput();
        });
    });

    // Initialize the cart and checkboxes
    checkInitiallySelectedExcursions();
    updateSelectedExcursionsInput();
    updateCart();

    // Add event listener to the "Go Back" button to clear session storage
    const goBackButton = document.querySelector('.btn.btn-info');
    goBackButton.addEventListener('click', function() {
        sessionStorage.removeItem('selectedExcursions');
    });
});
</script>
@endsection

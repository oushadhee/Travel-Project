@extends('layouts.front',['main_page' > 'yes'])
@section('content')

<style>

    .slider-container {
        position: relative;
        width: 100%; /* Adjust the width as needed */
        max-width: 600px; /* Adjust the maximum width as needed */
        margin: 0 auto; /* Center the container horizontally */
        overflow: hidden; /* Hide overflow */
      }

      /* Style for individual slides */
      .mySlides img {
        width: 100%; /* Ensure image fills its container */
        height: auto; /* Maintain aspect ratio */
        object-fit: cover; /* Cover the container with the image, preserving aspect ratio */
        background-color: black; /* Set background color to black for unused areas */
      }

        * {
      box-sizing: border-box;
    }

    .row {
      display: flex;
      flex-wrap: wrap;
      width: 100%; /* Adjust the width as needed */
    }

    @media (max-width: 500px) {
        .bb{
            padding-right: 20px;
        }
        .mb{
            margin-bottom: 10px;
        }
        .sl{
            margin-top: 600px;
        }

    }

    /* Position the image container (needed to position the left and right arrows) */
    .container {
      position: relative;
    }

    /* Hide the images by default */
    .mySlides {
      display: none;
    }

    /* Add a pointer when hovering over the thumbnail images */
    .cursor {
      cursor: pointer;
    }

    /* Next & previous buttons */
    .prev,
    .next {
      cursor: pointer;
      position: absolute;
      top: 40%;
      width: auto;
      padding: 16px;
      margin-top: -50px;
      color: white;
      font-weight: bold;
      font-size: 20px;
      border-radius: 0 3px 3px 0;
      user-select: none;
      -webkit-user-select: none;
    }

    /* Position the "next button" to the right */
    .next {
      right: 0;
      border-radius: 3px 0 0 3px;
    }

    /* On hover, add a black background color with a little bit see-through */
    .prev:hover,
    .next:hover {
      background-color: rgba(0, 0, 0, 0.8);
    }

    /* Number text (1/3 etc) */
    .numbertext {
      color: #f2f2f2;
      font-size: 12px;
      padding: 8px 12px;
      position: absolute;
      top: 0;
    }

    /* Container for image text */
    .caption-container {
      text-align: center;
      background-color: #222;
      padding: 2px 16px;
      color: white;
    }

    .row:after {
      content: "";
      display: table;
      clear: both;
    }

    /* Six columns side by side */
    .column {
      float: left;
      width: 16.66%;
    }

    .square-image {
        width: 200px; /* Set the width of the square */
        height: 200px; /* Set the height of the square */
        object-fit: cover; /* This ensures the image covers the entire container */
      }

    /* Add a transparency effect for thumnbail images */
    .demo {
      opacity: 0.6;
    }

    .active,
    .demo:hover {
      opacity: 1;
    }
</style>


<div id="time-table" class="time-table-section">
    <div class="blog" style="padding-bottom:40px;">
        <div class="container" style="margin-top: 30px; :">
            <div class="blog-content" style="background: linear-gradient(to bottom, rgba(8, 102, 255, 0.2), rgba(8, 102, 255, 0.2));">
                <div class="blog-image" style="height: auto;">
                    <div class="deals-content block">
                        <div class="deals-image custom-imagerow">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    @if (count($errors) > 0)
                                        <button type="button" class="close" data-dismiss="alert">×</button>
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    @endif
                                    @if ($message = Session::get('success'))
                                        <div class="alert alert-success alert-block">
                                            <button type="button" class="close" data-dismiss="alert">×</button>
                                            <strong>{{ $message }}</strong>
                                        </div>
                                    @endif
                                    <ul style="margin-top:30px;margin-left:40px; color:#213771;">
                                        <?php
                                            $guides=\App\Models\GuideDetails::whereNull('is_deleted')->where('user_id', $guideName->id)->get();
                                            $guideDetails= $guides->first();
                                        ?>
                                        <h1 class="display-3 bb cc" style=" padding-top:30px; padding-left:30px; color:black;"><span style="text-transform: capitalize;">{{ $guideName->f_name }} {{ $guideName->l_name }}</span></h1>
                                        <p style="font-family: Georgia; font-size:20px; padding-top:50px;"><i class="fa-solid fa-briefcase"></i>&emsp;<span>Experience: &emsp;{{ $guideDetails->w_experience }}</span></p>
                                        <p style="font-family: Georgia; font-size:20px; padding-top:15px;"><i class="fa-solid fa-language"></i>&emsp;<span>Languages: &emsp;{{ $guideDetails->language }}</span></p>
                                        <p style="font-family: Georgia; font-size:20px; padding-top:15px;"><i class="fa-solid fa-street-view"></i>&emsp;<span>Guide Category: &emsp;{{ $guideDetails->guide_category }}</span></p>
                                        <p style="font-family: Georgia; font-size:20px; padding-top:15px;"><i class="fa-regular fa-address-card"></i>&emsp;<span>About: &emsp;{{ $guideDetails->about }}</span></p>

                                    </ul>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 text-right" style="padding-right:35px;">
                                    <div class="deals-image custom-image" style="margin-top: 50px; margin-right: 40px;">
                                        <a href="#">
                                            <img src="{{ asset($guideDetails->guides_photos_normal) }}" alt="image" style="border-radius: 50%; border: 5px double; border-color: #f67a59; padding: 15px; height: 300px; width:300px; object-fit: cover; margin:20px;">
                                        </a>
                                    </div>
                                    <p style="margin: 50px; margin-left: 140px; text-align:center; margin-bottom:0%; margin-top:0%;"><span style="font-size:17px; color:#f67a59;">Please Leave Your Valuable Comment About Me</span></p>
                                    <div class="d-flex justify-content-center" style="margin-right: 50px; margin-left: 140px; margin-top:10px; margin-bottom:20px; ">
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="background-color: #f67a59">
                                            Click Here
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    <!-- tour package details -->
    <div class="row">



        <div class="col-lg-4">
            <div class="package-details-right-container">

                <!-- Modal -->
                <div class="modal fade" style="color: #f67a59" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Register First</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <section class="formregister" style="font-family: 'Corbel Light';">
                                    <form method="POST" enctype="multipart/form-data" action="{{route('register_tourist')}}">
                                        @csrf

                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-12">
                                                    <label for="f_name">First Name:</label>
                                                    <input type="text" class="form-control @error('f_name') is-invalid @enderror" id="f_name" name="f_name" required>

                                                    @error('f_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>

                                                <div class="col-lg-6 col-sm-12">
                                                    <label for="l_name">Last Name:</label>
                                                    <input type="text" class="form-control @error('l_name') is-invalid @enderror" id="l_name" name="l_name" required>

                                                    @error('l_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-12">
                                                    <label for="email">Your Email:</label>
                                                    <input type="email" class="form-control @error('email') is-invalid @enderror"  id="email" name="email" required>

                                                    @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                                <div class="col-lg-6 col-sm-12">
                                                    <label for="country">Your Country:</label>
                                                    <input class="form-control @error('country') is-invalid @enderror" id="country" name="country" list="country-list" placeholder="Enter Country" required>
                                                    <datalist id="country-list">
                                                            <?php
                                                            $country_lists = App\Models\Country::all();
                                                            ?>
                                                        @foreach ($country_lists as $country)
                                                            <option value="{{ $country->nicename }}">{{ $country->nicename }}</option>
                                                        @endforeach
                                                    </datalist>
                                                    @error('country')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
{{--                                                    <select class="form-control @error('country') is-invalid @enderror" id="country" name="country" required>--}}
{{--                                                            <?php--}}
{{--                                                            $country_lists = App\Models\Country::all();--}}
{{--                                                            ?>--}}
{{--                                                        @foreach ($country_lists as $country)--}}
{{--                                                            <option data-img_src="{{ asset('vendor/blade-flags/country-'.strtolower($country->iso).'.svg') }}">{{ $country->nicename }}</option>--}}
{{--                                                        @endforeach--}}
{{--                                                    </select>--}}
                                                    {{--                                    <input type="text" class="form-control @error('country') is-invalid @enderror" id="country" name="country" required>--}}

                                                    @error('country')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-6 col-sm-12">
                                                    <label for="address">Your Address:</label>
                                                    <textarea type="text" class="form-control @error('address') is-invalid @enderror" id="address" name="address" rows="8" required></textarea>

                                                    @error('address')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                    @enderror
                                                </div>
                                                <div class="col-lg-6 col-sm-12">

                                                    <div class="form-group"><!-- Adding a form-group div for styling -->
                                                        <label for="m_phone_1">Phone Number</label>
                                                        <div class="m_phone_2-container"  style="display:flex;">
                                                            <div style="display: inline-block; width: 30%;">
                                                                <input type="text" id="m_phone_1_country_code" name="m_phone_1_country_code" list="countries" placeholder="code" value="+" style="width: 100%;">
                                                                <datalist id="countries">
                                                                    @foreach ($country_lists as $country)
                                                                        <option value="{{ $country->phonecode }}" data-img_src="{{ $country->flag_url }}">
                                                                            @if($country->flag_url)
                                                                                <img src="https://flagsapi.com/{{ $country->iso3 }}/flat/64.png">
                                                                            @else
                                                                                {{ $country->name }}
                                                                            @endif
                                                                            (+{{ $country->phonecode }})
                                                                        </option>
                                                                    @endforeach
                                                                </datalist>
                                                            </div>
                                                            <div style="display: inline-block; width: 100%;">
                                                                <input type="number" class="form-control phone-number @error('m_phone_2') is-invalid @enderror" id="m_phone_1" name="m_phone_1" placeholder="Enter number" style="width: 100%;" required>
                                                            </div>
                                                        </div>
{{--                                                        <div class="m_phone_1-container"><!-- Container for combined input -->--}}
{{--                                                            <select class="form-control country-code" id="m_phone_1_country_code" name="m_phone_1_country_code" required>--}}
{{--                                                                    <?php--}}
{{--                                                                    $country_lists = App\Models\Country::all();--}}
{{--                                                                    ?>--}}
{{--                                                                @foreach ($country_lists as $country)--}}
{{--                                                                    <option value="{{ $country->phonecode }}" data-img_src="{{ asset('vendor/blade-flags/country-'.strtolower($country->iso).'.svg') }}">(+{{ $country->phonecode }})</option>--}}
{{--                                                                @endforeach--}}
{{--                                                            </select>--}}
{{--                                                            <input type="number" class="form-control phone-number @error('m_phone_1') is-invalid @enderror" id="m_phone_1" name="m_phone_1" placeholder="Enter phone number" required>--}}
{{--                                                        </div>--}}
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="password">Password:</label>
                                                        <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" required autocomplete="new-password" placeholder="At least 6 characters for password">
                                                        @error('password')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                        @enderror

                                                        <label for="password_confirmation">Confirm Password:</label>
                                                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required autocomplete="new-password">
                                                    </div>

                                                    <div id="passwordError" class="invalid-feedback" style="display: none;">
                                                        <strong>Confirmed password does not match.</strong>
                                                    </div>

                                                  
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <button type="submit">Register</button>
                                        </div>
                                        <p>Already have an account? <a href="{{ route('login') }}">Sign In</a></p>
                                    </form>
                                </section>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

{{-- new code --}}
<div class="container"style="width: 100%">
    <div class="row" >
        <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 sl">
            <div class="testimonial-container wow fadeInLeftBig" data-wow-delay="00ms" data-wow-duration="2000ms" style="width: 100%;">
                <div class="testimonials-carousel owl-carousel owl-theme">

                    @foreach ($comments as $comment)
                        <div class="testimonial-content">
                            <div class="test-bus">
                                {{-- <img src="assets/images/shape/bus.png" alt="bus"> --}}
                            </div>
                            <h5 style="font-family: 'Corbel Light';">#Happy Customer</h5>
                            <h4 style="font-family: 'Corbel Light';">What Your Tourist's Say</h4>
                            <p style="font-family: 'Corbel Light';">“{{ $comment->comment_guide}} ”</p>
                            <div class="testimonial-info">

                                <div class="testimonial-rating">
                                    <p style="font-family: 'Corbel Light';">{{ $comment->user->f_name}} {{ $comment->user->l_name}}</p>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endforeach



                </div>
            </div>
        </div>
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
            <div class="row" style="margin-top: 100px; width:100%;">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="align-title">
                        <h3 style="color:#f67a59; font-family: 'Corbel Light'">Gallary</h3>
                    </div>
                </div>

                {{-- add new code --}}
                <!-- Full-width images with number text -->
                <div class="row" style="width: 100%;">

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bb">
                        <div class="slider-container" style="height:400px; width:100%;">
                            @php
                                $totalImages = $images->count();
                                $currentSlide = 1;
                            @endphp
                            @foreach ($images as $gallery)
                                <div class="mySlides">
                                    <div class="numbertext">{{ $currentSlide }}/{{ $totalImages }}</div>
                                    <img src="{{ asset($gallery->tour_photos) }}" style="height: 45vh; width: 100vw;">
                                </div>
                                @php
                                    $currentSlide++;
                                @endphp
                            @endforeach
                        </div>

                        <!-- Next and previous buttons -->
                        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                        <a class="next" onclick="plusSlides(1)">&#10095;</a>
                    </div>



                    <!-- Thumbnail images -->
                    <div class="row" style="margin-left:40px; margin-right:40px">

                        <div class="row" style="margin-left:7px; margin-right:7px">

                            @foreach ($images as $gallery)
                                <div class="column">
                                    <img class="demo cursor" src="{{ asset($gallery->tour_photos) }}" style="width: 100%; height:50%;" onclick="currentSlide(1)" alt="The Woods">
                                </div>
                            @endforeach
                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let slideIndex = 1;
    showSlides(slideIndex);

    // Next/previous controls
    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    // Thumbnail image controls
    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("demo");
        let captionText = document.getElementById("caption");
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
        captionText.innerHTML = dots[slideIndex-1].alt;
    }
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        function checkPasswords() {
            var password = $('#password').val();
            var passwordConfirmation = $('#password_confirmation').val();

            if (passwordConfirmation && password !== passwordConfirmation) {
                $('#passwordError').show();
                return false;
            } else {
                $('#passwordError').hide();
                return true;
            }
        }

        $('#password_confirmation').on('keyup', function () {
            checkPasswords();
        });

        $('#registerButton').on('click', function (event) {
            if (!checkPasswords()) {
                event.preventDefault();
            }
        });
    });
</script>


@endsection




@extends('layouts.front',['main_page' > 'yes'])
@section('content')

<style>

.slider-container {
    position: relative;
    width: 100%; /* Adjust the width as needed */
    max-width: 600px; /* Adjust the maximum width as needed */
    margin: 0 auto; /* Center the container horizontally */
    overflow: hidden; /* Hide overflow */
  }

  /* Style for individual slides */
  .mySlides img {
    width: 100%; /* Ensure image fills its container */
    height: auto; /* Maintain aspect ratio */
    object-fit: cover; /* Cover the container with the image, preserving aspect ratio */
    background-color: black;
     /* Set background color to black for unused areas */
  }

    * {
  box-sizing: border-box;
}

@media (max-width: 500px) {
    .bb{
        padding-right: 20px;
    }
    .mb{
        margin-bottom: 10px;
    }

}

/* Position the image container (needed to position the left and right arrows) */
.container {
  position: relative;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #222;
  padding: 2px 16px;
  color: white;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

.square-image {
    width: 200px; /* Set the width of the square */
    height: 200px; /* Set the height of the square */
    object-fit: cover; /* This ensures the image covers the entire container */
  }

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}

/* Fix for the main profile section */
.profile-section {
    min-height: auto;
    overflow: visible;
}

/* Fix for the blog content container */
.blog-content {
    min-height: auto !important;
    height: auto !important;
    overflow: visible !important;
    padding-bottom: 50px;
}

/* Fix for the profile info container */
.profile-info-container {
    min-height: auto;
    overflow: visible;
    padding-bottom: 30px;
}

/* Ensure the left column has enough space */
.profile-left-column {
    min-height: 600px;
    overflow: visible;
}

/* Fix for the deals-content block */
.deals-content.block {
    height: auto !important;
    min-height: auto !important;
    overflow: visible !important;
}

/* Fix for deals-image */
.deals-image.custom-imagerow {
    height: auto !important;
    min-height: auto !important;
    overflow: visible !important;
}

/* Ensure proper spacing for profile info */
.profile-info-list {
    margin-bottom: 30px;
    padding-bottom: 20px;
}

/* Media query for better mobile responsiveness */
@media (max-width: 768px) {
    .profile-left-column {
        min-height: auto;
        margin-bottom: 30px;
    }
    
    .profile-info-list {
        margin-left: 20px !important;
        padding-left: 20px !important;
    }
    
    .bb {
        padding-left: 10px;
        padding-right: 10px;
    }
}

</style>




<div class="col-lg-12">
    <div style="padding: 30px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <div class="row align-items-center">

            <!-- Profile Picture Column -->
            <div class="col-lg-3 text-center">
                <img src="{{ asset(Auth::user()->guidedetails->guides_photos_normal) }}"
                    style="width: 180px; height: 180px; border-radius: 50%; object-fit: cover; border: 5px double #fe7524; padding: 5px;">
                    <!-- About -->
                    <div class="mt-4" style="padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <p style="font-size: 16px; color: #333;">{{ Auth::user()->guidedetails->about }}</p>
                    </div> 
            </div>
             
            

            <!-- User Info Column -->
            <div class="col-lg-9">
                
                <h2 style="color: #333; border-bottom: 2px solid #fe7524; padding-bottom: 10px; margin-bottom: 25px; font-family: 'Roboto';">
                    {{ Auth::user()->f_name }} {{ Auth::user()->l_name }}
                </h2>

                <!-- Experience and Language -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-briefcase" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">EXPERIENCE</div>
                                <div style="font-size: 16px;">{{ Auth::user()->guidedetails->w_experience }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-language" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">LANGUAGES</div>
                                <div style="font-size: 16px;">{{ Auth::user()->guidedetails->language }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Guide Category and Address -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-street-view" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">GUIDE CATEGORY</div>
                                <div style="font-size: 16px;">{{ Auth::user()->guidedetails->guide_category }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-map-marker-alt" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">ADDRESS</div>
                                <div style="font-size: 16px;">{{ Auth::user()->address }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Contact Numbers -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-mobile-screen-button" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">MOBILE NO 01</div>
                                <div style="font-size: 16px;">({{ Auth::user()->m_phone_1_country_code }}) {{ Auth::user()->m_phone_1 }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-mobile-screen-button" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">MOBILE NO 02</div>
                                <div style="font-size: 16px;">({{ Auth::user()->m_phone_1_country_code }}) {{ Auth::user()->m_phone_2 }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Landline and Email -->
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-phone" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">LANDLINE</div>
                                <div style="font-size: 16px;">({{ Auth::user()->l_number_country_code }}) {{ Auth::user()->l_number }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="display: flex; align-items: flex-start; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-regular fa-envelope" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div style="min-width: 0;">
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">EMAIL</div>
                                <div style="font-size: 16px; word-break: break-all;">{{ Auth::user()->email }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Emergency Contact -->
                <div class="row">
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-person-circle-check" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">EMERGENCY CONTACT NAME</div>
                                <div style="font-size: 16px;">{{ Auth::user()->ec_name }}</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <i class="fa-solid fa-mobile-screen-button" style="color: #fe7524; font-size: 24px; margin-right: 15px;"></i>
                            <div>
                                <div style="font-weight: 600; color: #6c757d; font-size: 14px;">EMERGENCY CONTACT NO</div>
                                <div style="font-size: 16px;">({{ Auth::user()->ec_number_country_code }}) {{ Auth::user()->ec_number }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- About -->
                <!-- <div class="mt-4" style="padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <p style="font-size: 16px; color: #333;">{{ Auth::user()->guidedetails->about }}</p>
                </div> -->

            </div>
        </div>
    </div>
</div>

<br><br>
<div class="container bb" >
    <div class="row">
        <div class="col-lg-12">
            <div class="align-title">
                <h3 style="color:#fe7524; font-family: 'roboto'">Guide Documents</h3>
            </div>
        </div>

        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="activites-container" style="margin: 20px;">
                <div class="activities-image" >
                    @php
                                $fileUrl = asset(Auth::user()->guidedetails->guide_license_f);
                                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                            @endphp

                            <a data-toggle="modal" data-target="#guideLicenseFrontModal">
                                @if (in_array($fileExtension, ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'gif', 'TIFF', 'PSD']))

                                    <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                                @elseif ($fileExtension === 'pdf')
                                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                                @else
                                    <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                                @endif
                            </a>

                            <div class="modal fade" id="guideLicenseFrontModal" tabindex="-1" role="dialog" aria-labelledby="guideLicenseFrontModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-md" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="guideLicenseFrontModalLabel">Guide License Front Side Image</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            @if ($fileExtension === 'pdf')
                                                <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                            @else
                                                <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>
                <div class="activities-content">

                    <h4 style="text-align: center; margin-top:40px">Guide License Front Side Image</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="activites-container" style="margin: 20px;">
                <div class="activities-image">
                    @php
                                $fileUrl = asset(Auth::user()->guidedetails->guide_license_b);
                                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                            @endphp

                            <a data-toggle="modal" data-target="#guideLicenseBackModal">
                                @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                                    <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                                @elseif ($fileExtension === 'pdf')

                                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover; ">
                                @else

                                    <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover; "></iframe>
                                @endif
                            </a>


                            <div class="modal fade" id="guideLicenseBackModal" tabindex="-1" role="dialog" aria-labelledby="guideLicenseBackModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-md" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="guideLicenseBackModalLabel">Guide License Back Side Image</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            @if ($fileExtension === 'pdf')

                                                <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                            @else

                                                <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>
                <div class="activities-content">
                    <h4 style="text-align: center; margin-top:40px">Guide License Back Side Image</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="activites-container" style="margin: 20px;">
                <div class="activities-image">
                        @php
                            $fileUrl = asset(Auth::user()->guidedetails->driving_license_f);
                            $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                        @endphp

                        <a data-toggle="modal" data-target="#drivingLicenseFrontModal">
                            @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                                <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                            @elseif ($fileExtension === 'pdf')

                                <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                            @else

                                <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                            @endif
                        </a>


                        <div class="modal fade" id="drivingLicenseFrontModal" tabindex="-1" role="dialog" aria-labelledby="drivingLicenseFrontModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-md" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="drivingLicenseFrontModalLabel">Driving License Front Image</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        @if ($fileExtension === 'pdf')

                                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                        @else

                                            <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>

                </div>
                <div class="activities-content">
                    <h4 style="text-align: center; margin-top:40px">Driving License Front Image</h4>
                </div>
            </div>
        </div>
    </div>

        <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image" >
                        @php
                                $fileUrl = asset(Auth::user()->guidedetails->driving_license_b);
                                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                            @endphp

                            <a data-toggle="modal" data-target="#drivingLicenseBackModal">
                                @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                                    <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                                @elseif ($fileExtension === 'pdf')

                                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                                @else

                                    <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                                @endif
                            </a>


                            <div class="modal fade" id="drivingLicenseBackModal" tabindex="-1" role="dialog" aria-labelledby="drivingLicenseBackModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-md" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="drivingLicenseBackModalLabel">Driving License Back Side Image</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            @if ($fileExtension === 'pdf')

                                                <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                            @else

                                                <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Driving License Back Image</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image">
                        @php
                                $fileUrl = asset(Auth::user()->guidedetails->nic_f);
                                $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                            @endphp

                            <a data-toggle="modal" data-target="#nicFrontModal">
                                @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))
                                    {{-- Display image --}}
                                    <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                                @elseif ($fileExtension === 'pdf')
                                    {{-- Display PDF using embed --}}
                                    <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                                @else
                                    {{-- Display generic content using iframe --}}
                                    <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                                @endif
                            </a>


                            <div class="modal fade" id="nicFrontModal" tabindex="-1" role="dialog" aria-labelledby="nicFrontModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-md" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="nicFrontModalLabel">NIC Front Side Image</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            @if ($fileExtension === 'pdf')
                                                {{-- Display PDF using embed --}}
                                                <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                            @else
                                                {{-- Display generic content using iframe --}}
                                                <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">NIC Front Side Image</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image">
                        @php
                        $fileUrl = asset(Auth::user()->guidedetails->nic_b);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                     @endphp

                     <a data-toggle="modal" data-target="#nicBackModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                     </a>


                     <div class="modal fade" id="nicBackModal" tabindex="-1" role="dialog" aria-labelledby="nicBackModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="nicBackModalLabel">NIC Back Side Images</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    @if ($fileExtension === 'pdf')

                                        <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                    @else

                                        <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                    @endif
                                </div>
                            </div>
                        </div>
                     </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">NIC Back Side Image</h4>
                    </div>
                </div>
            </div>
        </div>

</div>



<div class="container bb" >
    <div class="row" style="margin-top: 100px;">
        <div class="col-lg-12">
            <div class="align-title">
                <h3 style="color:#fe7524; font-family: 'roboto'">Vehicle Details</h3>
            </div>
        </div>

       <div class="col-lg-12">
    <div style="padding: 30px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h2 style="color: #333; border-bottom: 2px solid #fe7524; padding-bottom: 10px; margin-bottom: 25px; font-family: 'Roboto';">
            Vehicle Information
        </h2>

        <div class="row mb-3">
            <div class="col-md-6">
                <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <i class="fa-solid fa-list-ol" style="color: #fe7524; font-size: 20px; margin-right: 15px;"></i>
                    <div>
                        <div style="font-weight: 600; color: #6c757d; font-size: 14px;">VEHICLE NUMBER</div>
                        <div>{{ Auth::user()->vehicle->v_number }}</div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <i class="fa-solid fa-van-shuttle" style="color: #fe7524; font-size: 20px; margin-right: 15px;"></i>
                    <div>
                        <div style="font-weight: 600; color: #6c757d; font-size: 14px;">VEHICLE TYPE</div>
                        <div>{{ Auth::user()->vehicle->vehicle_type }}</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Row 2 -->
        <div class="row mb-3">
            <div class="col-md-6">
                <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <i class="fa-solid fa-van-shuttle" style="color: #fe7524; font-size: 20px; margin-right: 15px;"></i>
                    <div>
                        <div style="font-weight: 600; color: #6c757d; font-size: 14px;">VEHICLE MODEL</div>
                        <div>{{ Auth::user()->vehicle->v_model }}</div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <i class="fa-solid fa-person" style="color: #fe7524; font-size: 20px; margin-right: 15px;"></i>
                    <div>
                        <div style="font-weight: 600; color: #6c757d; font-size: 14px;">OWNERSHIP</div>
                        <div>{{ Auth::user()->vehicle->vehicle_rent_own }}</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Row 3 -->
        <div class="row mb-3">
            <div class="col-md-6">
                <div style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                    <i class="fa-regular fa-calendar-days" style="color: #fe7524; font-size: 20px; margin-right: 15px;"></i>
                    <div>
                        <div style="font-weight: 600; color: #6c757d; font-size: 14px;">INSURANCE END DATE</div>
                        <div>{{ Auth::user()->vehicle->end_date_insurance }}</div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="activites-container" style="margin: 20px;">
                <div class="activities-image" >
                    @php
                        $fileUrl = asset(Auth::user()->vehicle->fileToUpload_v_insurance_f);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                    @endphp

                    <a data-toggle="modal" data-target="#insuranceFrontModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                    </a>


                    <div class="modal fade" id="insuranceFrontModal" tabindex="-1" role="dialog" aria-labelledby="insuranceFrontModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="insuranceFrontModalLabel">Insurance Front</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    @if ($fileExtension === 'pdf')

                                        <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                    @else

                                        <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="activities-content">

                    <h4 style="text-align: center; margin-top:40px">Insurance Front</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="activites-container" style="margin: 20px;">
                <div class="activities-image">
                    @php
                        $fileUrl = asset(Auth::user()->vehicle->fileToUpload_v_insurance_b);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                    @endphp

                    <a data-toggle="modal" data-target="#insuranceBackModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                    </a>


                    <div class="modal fade" id="insuranceBackModal" tabindex="-1" role="dialog" aria-labelledby="insuranceBackModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="insuranceBackModalLabel">Insurance Back</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    @if ($fileExtension === 'pdf')

                                        <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                    @else

                                        <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="activities-content">
                    <h4 style="text-align: center; margin-top:40px">Insurance Back</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="activites-container" style="margin: 20px;">
                <div class="activities-image">
                    @php
                        $fileUrl = asset(Auth::user()->vehicle->v_book_f);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                    @endphp

                    <a data-toggle="modal" data-target="#vBookFrontModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                    </a>


                    <div class="modal fade" id="vBookFrontModal" tabindex="-1" role="dialog" aria-labelledby="vBookFrontModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="vBookFrontModalLabel">Vehicle Book Front Side Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    @if ($fileExtension === 'pdf')

                                        <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                    @else

                                        <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="activities-content">
                    <h4 style="text-align: center; margin-top:40px">Vehicle Book Front Side Image</h4>
                </div>
            </div>
        </div>
    </div>

        <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image" >
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_book_b);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                     @endphp

                    <a data-toggle="modal" data-target="#vBookBackModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                    </a>


                    <div class="modal fade" id="vBookBackModal" tabindex="-1" role="dialog" aria-labelledby="vBookBackModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="vBookBackModalLabel">Vehicle Book Back Side Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    @if ($fileExtension === 'pdf')

                                        <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 100%; height: 500px;">
                                    @else

                                        <iframe src="{{ $fileUrl }}" style="width: 100%; height: 500px;"></iframe>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Vehicle Book Back Side Image</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image">
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_out__front_images);

                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                    @endphp

                    <a data-toggle="modal" data-target="#frontImageModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))
                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')
                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else
                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                    </a>

                    <div class="modal fade" id="frontImageModal" tabindex="-1" role="dialog" aria-labelledby="frontImageModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="frontImageModalLabel">Front Side Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="{{ $fileUrl }}" alt="Front Image" style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Front Side Image</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image">
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_out_back_images);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                     @endphp

                     <a data-toggle="modal" data-target="#backImageModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                     </a>


                     <div class="modal fade" id="backImageModal" tabindex="-1" role="dialog" aria-labelledby="backImageModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="backImageModalLabel">Back Side Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="{{ $fileUrl }}" alt="Back Image" style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                     </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Back Side Image</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image" >
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_out_left_images);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                     @endphp

                     <a data-toggle="modal" data-target="#leftImageModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))

                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')

                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else

                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                     </a>


                     <div class="modal fade" id="leftImageModal" tabindex="-1" role="dialog" aria-labelledby="leftImageModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="leftImageModalLabel">Left Side Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="{{ $fileUrl }}" alt="Left Image" style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                     </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Left Side Image</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image">
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_out_right_images);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                    @endphp

                    <a data-toggle="modal" data-target="#fullImageModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))
                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')
                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else
                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                    </a>

                    <div class="modal fade" id="fullImageModal" tabindex="-1" role="dialog" aria-labelledby="fullImageModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="fullImageModalLabel">Right Side Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="{{ $fileUrl }}" alt="Full Image" style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Right Side Image</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 bb">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image">
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_in_front_images);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                     @endphp

                     <a data-toggle="modal" data-target="#frontSeatImageModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))
                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')
                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else
                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                     </a>

                     <div class="modal fade" id="frontSeatImageModal" tabindex="-1" role="dialog" aria-labelledby="frontImageModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="frontImageModalLabel">Front Seat Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="{{ $fileUrl }}" alt="Front Image" style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                     </div>
                     </div>
                     <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Front Seat Image</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 bb">
                <div class="activites-container" style="margin: 20px;">
                    <div class="activities-image" >
                        @php
                        $fileUrl = asset(Auth::user()->vehicle->v_in_back_images);
                        $fileExtension = pathinfo($fileUrl, PATHINFO_EXTENSION);
                     @endphp

                     <a data-toggle="modal" data-target="#backSeatImageModal">
                        @if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif']))
                            <img src="{{ $fileUrl }}" alt="Image" style="width: 100%; height: 300px; object-fit: cover;">
                        @elseif ($fileExtension === 'pdf')
                            <embed src="{{ $fileUrl }}" type="application/pdf" style="width: 300px; height: 300px; object-fit: cover;">
                        @else
                            <iframe src="{{ $fileUrl }}" style="width: 300px; height: 300px; object-fit: cover;"></iframe>
                        @endif
                     </a>

                     <div class="modal fade" id="backSeatImageModal" tabindex="-1" role="dialog" aria-labelledby="backImageModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="backImageModalLabel">Back Seat Image</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <img src="{{ $fileUrl }}" alt="Back Image" style="width: 100%; height: auto;">
                                </div>
                            </div>
                        </div>
                     </div>
                    </div>
                    <div class="activities-content">
                        <h4 style="text-align: center; margin-top:40px">Back Seat Image</h4>
                    </div>
                </div>
            </div>
        </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-lg-5 col-md-8 col-sm-12 col-xs-12">
            <div class="testimonial-container wow fadeInLeftBig" data-wow-delay="00ms" data-wow-duration="2000ms" style="width: 100%;">
                <div class="testimonials-carousel owl-carousel owl-theme">

                    @foreach ($comments as $comment)
                        <div class="testimonial-content">
                            <div class="test-bus">
                                <img src="assets/images/shape/bus.png" alt="bus">
                            </div>
                            <h5 style="font-family: 'Corbel Light';">#Happy Customer</h5>
                            <h4 style="font-family: 'Corbel Light';">What Your Tourist's Say</h4>
                            <p style="font-family: 'Corbel Light';">“ {{ $comment->comment_guide}} ”</p>
                            <div class="testimonial-info">

                                <div class="testimonial-rating">
                                    <p style="font-family: 'Corbel Light';">{{ $comment->user->f_name}} {{ $comment->user->l_name}}</p>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>
        </div>

        <div class="col-lg-7 col-md-8 col-sm-12 col-xs-12">
            <div class="row" style="margin-top: 100px;">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="" style="float: left;">
                        <h3 style="color:#fe7524; font-family:'roboto'">Gallary</h3>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="text-right align-items-center">
                        <button type="button" style="float: right; margin-top:20px; margin-right:11%; background-color: #fe7524; width:140px; height:40px;" class="btn mb">
                            <i class="mdi mdi-account-settings-variant mr-1"></i>
                            <a href="{{ route('guide-profile-edit') }}" style="color: white;">New Uploads</a>
                        </button>
                    </div>
                </div>
                {{-- gallery guide image display code --}}
                <!-- Full-width images with number text -->
                <div class="row">
    <div class="col-lg-7 col-md-7 col-sm-7 col-xs- bb">
        <div class="slider-container" style="justify-content:center;">

            {{-- start image display gallery section --}}
            <?php
            $images = \App\Models\Gallery::whereNull('galleries.is_deleted')
                ->join('users', 'galleries.user_id', '=', 'users.id')
                ->where('users.user_type', 'guide')
                ->where('user_id', Auth::user()->id)
                ->get();
            ?>

            @php
                $totalImages = $images->count();
                $currentSlide = 1;
            @endphp
            @foreach ($images as $gallery)
                <div class="mySlides">
                    <div class="numbertext">{{ $currentSlide }}/{{ $totalImages }}</div>
                    <img src="{{ asset($gallery->tour_photos) }}" style="height: 45vh; width: 100%; object-fit: cover;">
                </div>
                @php
                    $currentSlide++;
                @endphp
            @endforeach

            <!-- Next and previous buttons positioned inside the slider -->
            <a class="prev" onclick="plusSlides(-1)" style="position: absolute; top: 50%; left: 15px; transform: translateY(-50%); color: white; font-size: 24px; font-weight: bold; cursor: pointer; z-index: 10; background-color: rgba(0,0,0,0.3); padding: 10px 15px; border-radius: 50%;">&#10094;</a>
            <a class="next" onclick="plusSlides(1)" style="position: absolute; top: 50%; right: 15px; transform: translateY(-50%); color: white; font-size: 24px; font-weight: bold; cursor: pointer; z-index: 10; background-color: rgba(0,0,0,0.3); padding: 10px 15px; border-radius: 50%;">&#10095;</a>
        </div>

        <!-- Thumbnail images -->
        <div class="row" style="margin-left:7px; margin-right:7px; margin-top: 10px;">
            @foreach ($images as $index => $gallery)
                <div class="column" style="padding: 5px;">
                    <img class="demo cursor" src="{{ asset($gallery->tour_photos) }}" 
                         style="width: 100%; height: 80px; object-fit: cover; border: 2px solid transparent;"
                         onclick="currentSlide({{ $index + 1 }})" 
                         alt="Tour image {{ $index + 1 }}"
                         onmouseover="this.style.border='2px solid #f67a59'"
                         onmouseout="this.style.border='2px solid transparent'">
                </div>
            @endforeach
        </div>
    </div>
</div>


            </div>
        </div>

    </div>
</div>


<script>
    let slideIndex = 1;
    showSlides(slideIndex);

    // Next/previous controls
    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    // Thumbnail image controls
    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("demo");
        let captionText = document.getElementById("caption");
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
        captionText.innerHTML = dots[slideIndex-1].alt;
    }
</script>
@endsection
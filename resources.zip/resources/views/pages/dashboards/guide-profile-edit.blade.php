@extends('layouts.front', ['main_page' => 'yes'])
@section('content')

    <!-- Tour Images Upload Form -->
    <section class="package-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-details-right-container">
                        <div class="destination-common-title">
                            <center>
                                <h4 style="color: rgb(9, 65, 116); font-weight: bolder;">
                                    Join with Starluxe Travels
                                </h4>
                                <h3 style="color: black; font-weight: bolder;">
                                    Tour Images Upload
                                </h3>
                            </center>
                        </div>

                        <div class="package-details-right-form">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @if ($message = Session::get('success'))
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong>{{ $message }}</strong>
                                </div>
                            @endif

                            <form method="POST" enctype="multipart/form-data" action="{{route('guide_tour_images')}}">
                                @csrf

                                <input type="hidden" id="id" name="id" value="{{ Auth::user()->id }}" required>

                                <div class="form-row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-calendar"></i>Tour Start Date</label>
                                        <input type="date" class="@error('start_date') is-invalid @enderror" 
                                            id="start_date" name="start_date" placeholder="Start Date*" required
                                            style="padding: 8px; border-radius: 4px;">
                                        @error('start_date')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-calendar"></i>Tour End Date</label>
                                        <input type="date" class="@error('end_date') is-invalid @enderror" 
                                            id="end_date" name="end_date" placeholder="End Date*" required
                                            style="padding: 8px; border-radius: 4px;">
                                        @error('end_date')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-row" style="margin-bottom: 15px;">
                                    <div class="form-label">
                                        <h4 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                            Upload Tour Photos
                                        </h4>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <label><i class="fa-solid fa-images"></i></label>
                                            <input type="file" class="@error('tour_photos') is-invalid @enderror" 
                                                id="tour_photos" name="tour_photos[]" multiple required
                                                style="padding: 8px; border-radius: 4px; width: 100%;">
                                            @error('tour_photos')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                        <small class="text-muted">You can select multiple photos</small>
                                    </div>
                                </div>

                                <button type="submit" class="submit-btn">Save Uploads</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
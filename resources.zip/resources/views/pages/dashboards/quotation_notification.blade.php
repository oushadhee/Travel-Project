@extends('layouts.front',['main_page' > 'yes'])
@section('content')


<style>
    body {
        background: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0));
    }

    @media (max-width: 767px) {

        .contact-form .row::after {
            content: "";
            display: table;
            clear: both;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        strong {
            color: #555;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }

        .negotiate-button {

            background-color: #FE7524;
            width: 100px;
            height: 50px;

        }

        .confirm-button {

            background-color: #FE7524;
            width: 100px;
            height: 50px;
        }

    }

    .button-container {
        display: flex;
        gap: 8rem;
        margin-top: 20px;
    }



    /* Adjust margin for buttons on mobile */
    @media (max-width: 767px) {
        .button-container .btn {
            margin-bottom: 10px;
            /* Adjust as needed */
        }
    }
</style>




<section class="contact" style="font-family: 'Corbel Light'; color: #213771;">
    {{--message--}}
    @if (count($errors) > 0)
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    @if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
    @endif
    {{--end--}}

    {{-- load notification page --}}
    <div class="container" style="margin-top: -10px; margin-bottom: -80px; ">
        <div class="contact__wrapper shadow-lg mt-n9">
            <div class="row no-gutters">
                <div class="col-lg-5 contact-info__wrapper p-5 order-lg-2" style="background-color:#DBE7C9">
                    <h2 class="color--white mb-5 fw-bold" style="text-align: center; font-family:'roboto';" ;>Quotation Details</h2>

                    <br><br>

                    <div class="container" id="tourDetails">
                        <div id="quotationDetails"></div>
                    </div>

                </div>

                {{-- start list section --}}
                @php
                $notifications = \App\Models\QuotationDetails::whereIn('booked_id', function ($query) {
                $query->select('id')
                ->from('book_nows')
                ->where('user_id', Auth::user()->id);
                })
                ->where('status', 'Submitted to Tourist')
                ->orderBy('created_at', 'DESC')
                ->get();

                $notificationCount = $notifications->count();
                @endphp

                <div class="col-lg-7 p-4 order-lg-1" style="background-color: white; border-radius: 0 8px 8px 0;">
                    <div class="notification-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #f0f0f0;">
                        <h3 style="color: #2c3e50; font-weight: 700; margin: 0;">
                            <i class="fas fa-bell mr-2" style="color: #FE7524;"></i>
                            Notifications
                        </h3>
                        <span id="notificationCount" class="badge badge-pill"
                            style="background-color: #FE7524; color: white; font-size: 14px; padding: 5px 10px;">
                            {{ $notificationCount }}
                        </span>
                    </div>

                    <div class="notification-list-container" style="max-height: 400px; overflow-y: auto; padding-right: 10px;">
                        <div class="list-group" style="border-radius: 8px;">
                            @foreach ($notifications as $key => $notification)
                            <a href="#" class="list-group-item list-group-item-action notification-item"
                                onclick="displayAmount( {{ $notification->id }} ); markAsRead({{ $notification->id }})"
                                style="border: none;
                          border-left: 3px solid {{ $notification->status2 == 'unread' ? '#FE7524' : '#6c757d' }};
                          margin-bottom: 8px;
                          padding: 15px;
                          transition: all 0.3s ease;
                          background-color: {{ $notification->status2 == 'unread' ? '#FFF8F0' : 'white' }};">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <h5 style="color: #2c3e50; margin-bottom: 5px; font-weight: 600;">
                                            Tour {{ $notificationCount - $key }}
                                        </h5>
                                        <small class="text-muted">{{ $notification->created_at->format('M d, Y h:i A') }}</small>
                                    </div>
                                    <span class="badge {{ $notification->status2 == 'unread' ? 'badge-danger' : 'badge-secondary' }}"
                                        style="font-size: 12px; padding: 5px 10px; border-radius: 10px;">
                                        {{ ucfirst($notification->status2) }}
                                    </span>
                                </div>
                                <div id="amount{{ $notification->id }}" style="display: none;"></div>
                            </a>
                            @endforeach
                            @if($notifications->isEmpty())
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-3" style="color: #e9ecef;"></i>
                                <p>No notifications available</p>
                            </div>
                            @endif
                        </div>
                    </div>
                </div>
                <!-- End Contact Form Wrapper -->

            </div>
        </div>
    </div>
    <br><br>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            updateNotificationCount();
        });

        function updateNotificationCount() {
            fetch('/notification-count')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('notificationCount').innerText = data.count;
                    if (data.count === 0) {
                        document.getElementById('notificationCount').style.display = 'none';
                    } else {
                        document.getElementById('notificationCount').style.display = 'inline-block';
                    }
                })
                .catch(error => console.error('Error fetching notification count:', error));
        }

        function displayAmount(id) {
            const encodedId = encodeURIComponent(id);
            fetch('/quotation_notification/' + encodedId)
                .then(response => response.text())
                .then(totalAmount => {
                    const quotationDetails = document.getElementById('quotationDetails');
                    quotationDetails.innerHTML = `
            <div>Total Amount: $${totalAmount}</div>
            <br>
            <p>If you need to negotiate the expenses of your tour,<br> feel free to contact us.</p>
            <br>
            <div class="button-container">
                <a href="${window.location.origin}/quotation_comments/${id}" class="btn btn-success" onclick="passId('${id}')" >Negotiate</a>
                <form id="confirmForm" action="{{ route('status_confirm')}}" method="post">
                    @csrf
            <input type="hidden" name="id" value="${id}">
                    <button class="btn btn-success" type="submit" style =" background-color: #FE7524; width : 100px; height: 30px;">Confirm</button>
                </form>
            </div>
        `;
                });
        }




        function markAsRead(notificationId) {
            fetch('/mark-notification-as-read', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        notification_id: notificationId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationCount();
                    } else {
                        console.error('Failed to mark notification as read:', data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    </script>


</section>



@endsection
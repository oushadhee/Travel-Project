<footer class="main__footer p_relative" style="background-image: url('{{ asset('assets/images/background/footerbg.png') }}');">
    <div class="footer__middle p_relative d_block">
        <div class="container">
            <div class="footer__middle__content">
                <div class="row clearfix">
                    <!-- About Section -->
                    <div class="col-lg-3 col-md-6 col-sm-12 footer_column">
                        <div class="footer_widget left">
                            <div class="footer__logo">
                                <figure>
                                    <img src="{{ asset('assets/images/logo_new2.png') }}" alt="Starluxe Travels Logo">
                                </figure>
                            </div>
                            <div class="widget_content">
                                <p>Escape the Ordinary with Extraordinary Journeys.</p>
                            </div>
                            <div class="banner-media footer-media">
                                <p>Social Network:</p>
                                <ul>
                                    <li><a href="https://www.facebook.com/dreamplaces.global/"><i class="fa-brands fa-facebook-f"></i></a></li>
                                    <li><a href="https://www.instagram.com/dreamplaces.global?igsh=MXQ1NWU2bzl2am1pcA=="><i class="fa-brands fa-instagram"></i></a></li>
                                    <li><a href="viber://add?number=94707009666"><i class="fab fa-viber"></i></a></li>
                                    <li><a href="https://wa.me/94707009666"><i class="fab fa-whatsapp"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Links Section -->
                    <div class="col-lg-2 col-md-6 col-sm-12 footer_column">
                        <div class="footer_widget links_widget ml_100">
                            <div class="widget_title">
                                <h4>About Travel</h4>
                            </div>
                            <div class="widget_content">
                                <ul class="links_list clearfix">
                                    <li><a href="/">Home</a></li>
                                    <li><a href="{{ route('gallery') }}">Gallery</a></li>
                                    <li><a href="{{ route('about') }}">About Us</a></li>
                                    <li><a href="{{ route('contactus') }}">Contact Us</a></li>
                                    <li><a href="{{ route('guide-registration') }}">Guide</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Details Section -->
                    <div class="col-lg-3 col-md-6 col-sm-12 footer_column">
                        <div class="footer_widget contact_widget">
                            <div class="widget_title">
                                <h4>Contact Us</h4>
                            </div>
                            <div class="widget_content">
                                <ul class="contact_list">
                                    <li>
                                        <i class="fa-solid fa-location-dot"></i>
                                        <span>199, 6th Floor, Ward City Shopping Complex, Gampaha, Sri Lanka</span>
                                    </li><br>
                                    <li>
                                        <i class="fa-solid fa-phone"></i>
                                        <a href="tel:+94707009666">070-700-9666</a>
                                    </li><br>
                                    <li>
                                        <i class="fa-solid fa-envelope"></i>
                                        <a href="mailto:info@starluxetravels.com">info@starluxetravels.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Gallery Section -->
                    <div class="col-lg-3 col-md-6 col-sm-12 footer_column">
                        <div class="footer_widget gallery_widget">
                            <div class="widget_title">
                                <h4>Visit Sri Lanka</h4>
                            </div>
                            <div class="widget_content">
                                <div class="footer-recent-post">
                                    <div class="footer-recent-content">
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/1.png') }}" alt="Gallery Image 1" style="border-radius: 8px;">
                                        </div>
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/2.png') }}" alt="Gallery Image 2" style="border-radius: 8px;">
                                        </div>
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/3.png') }}" alt="Gallery Image 3" style="border-radius: 8px;">
                                        </div>
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/4.png') }}" alt="Gallery Image 4" style="border-radius: 8px;">
                                        </div>
                                    </div>
                                    <div class="footer-recent-content">
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/5.png') }}" alt="Gallery Image 5" style="border-radius: 8px;">
                                        </div>
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/6.png') }}" alt="Gallery Image 6" style="border-radius: 8px;">
                                        </div>
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/7.png') }}" alt="Gallery Image 7" style="border-radius: 8px;">
                                        </div>
                                        <div class="footer-recent-image">
                                            <img src="{{ asset('assets/images/main-gallery/8.png') }}" alt="Gallery Image 8" style="border-radius: 8px;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer_bottom p_relative">
        <div class="auto_container">
            <div class="bottom_inner p_relative">
                <div class="copyright">
                    <p>Copyright © 2025 Starluxe Travels. All rights reserved.</p>
                    <p>Designed by <a href="http://starluxetravels.com/" style="color: #FE7524;">Starluxe Travels (Pvt) Ltd</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
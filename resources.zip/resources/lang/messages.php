<?php

return [

    // English translations
    'en' => [
        'welcome' => 'Welcome to our travel site!',
        'read_more' => 'Read More',
        'tour_name' => 'Tour Name',
        'description' => 'Description',
        'book_now' => 'Book Now',
        'contact_us' => 'Contact Us',
    ],

    // Spanish translations
    'es' => [
        'welcome' => '¡Bienvenido a nuestro sitio de viajes!',
        'read_more' => 'Leer más',
        'tour_name' => 'Nombre del tour',
        'description' => 'Descripción',
        'book_now' => 'Reservar ahora',
        'contact_us' => 'Contáctenos',
    ],

    // Chinese translations (Simplified)
    'zh' => [
        'welcome' => '欢迎来到我们的旅游网站！',
        'read_more' => '阅读更多',
        'tour_name' => '旅游名称',
        'description' => '描述',
        'book_now' => '立即预订',
        'contact_us' => '联系我们',
    ],

];

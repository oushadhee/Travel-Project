<?php

use App\Http\Controllers\AccommodationAddController;
use App\Http\Controllers\ActivityAddController;
use App\Http\Controllers\ActivityCategoryController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Auth\ForgotPasswordManager;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\CountryCodeAndFlagsController;
use App\Http\Controllers\EventAddController;
use App\Http\Controllers\ExcursionsAddController;
use App\Http\Controllers\FrontDisplayController;
use App\Http\Controllers\GuideController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ImagesAddController;
use App\Http\Controllers\NotifyrController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\TourCategoryController;
use App\Http\Controllers\TouristController;
use App\Http\Controllers\ToursAddController;
use App\Http\Controllers\TwoFAController;
use App\Http\Controllers\UnexploredAddController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TourController;
use App\Http\Controllers\FrontendVideoController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/



Route::get('/', [FrontDisplayController::class, 'home'])->name('home');

Route::get('/linkstorage', function () {
    Artisan::call('storage:link');
});


//------------------------------------------------------------------------------

//nav-bar & footer routes

Route::get('/excursions', [FrontDisplayController::class, 'excursions'])->name('excursions');

Route::get('/unexplored', [FrontDisplayController::class, 'unexplored'])->name('unexplored');

Route::get('/add-image', [FrontDisplayController::class, 'add_image'])->name('add-image');

Route::get('/special-events', [FrontDisplayController::class, 'special_events'])->name('special-events');

Route::get('/sitemap', function () {
    return view('pages.nav-bar-pages.sitemap');
})->name('sitemap');

Route::get('/gallery', function () {
    return view('pages.nav-bar-pages.gallery');
})->name('gallery');

Route::get('/videos', function () {
    return view('pages.nav-bar-pages.videogallery');
})->name('videos');

Route::get('/about', function () {
    return view('pages.nav-bar-pages.about');
})->name('about');



Route::get('/accommodation', function () {
    return view('pages.nav-bar-pages.accommodation');
})->name('accommodation');

Route::get('/guide', function () {
    return view('pages.nav-bar-pages.guide');
})->name('guide');

//end of the navbar & footer routes

//---------------------------------------------------------------------

//tours

Route::get('/tour_categories/{id}', [FrontDisplayController::class, 'cultural_tours'])->name('tour_categories');

Route::get('/wildlife-tours', [FrontDisplayController::class, 'wildlife_tours'])->name('wildlife-tours');

Route::get('/eco-tours', [FrontDisplayController::class, 'eco_tours'])->name('eco-tours');

Route::get('/business-tours', [FrontDisplayController::class, 'business_tours'])->name('business-tours');

Route::get('/medical-n-wellness', [FrontDisplayController::class, 'medical_n_wellness'])->name('medical-n-wellness');

Route::get('/educational-tours', [FrontDisplayController::class, 'educational_tours'])->name('educational-tours');

Route::get('/culinary-tours', [FrontDisplayController::class, 'culinary_tours'])->name('culinary-tours');

Route::get('/sport-tours', [FrontDisplayController::class, 'sport_tours'])->name('sport-tours');


//end of the tours

//-------------------------------------------------------

//activities

Route::get('/all-activities', [FrontDisplayController::class, 'all_activities'])->name('all-activities');

Route::get('/adventure', [FrontDisplayController::class, 'adventure'])->name('adventure');

Route::get('/fun', [FrontDisplayController::class, 'fun'])->name('fun');

Route::get('/park', [FrontDisplayController::class, 'park'])->name('park');

Route::get('/activities-place-display/{id}', [FrontDisplayController::class, 'activities_place_display'])->name('activities-place-display');


//------------------------------------------------------------------------------------------
// Route::get('/country-tours/{id}', [TourController::class, 'countryTours'])->name('country_tours');
Route::get('/tours/country/{id}', [TourCategoryController::class, 'countryTours'])->name('country_tours');
// Route::get('/tours/country/{id}', [TourCategoryController::class, 'showTours'])->name('country_tours');
Route::get('/tour-categories', [TourCategoryController::class, 'index'])->name('tour-categories.index');
Route::get('/tours/country/{country_id}/category/{category_id}', [TourCategoryController::class, 'showTours'])->name('tour_categories_by_country');
Route::get('/tours', [TourCategoryController::class, 'allTours'])->name('all-tours');
// Route::get('/tours/country/{id}', [TourCategoryController::class, 'countryTours'])->name('country_tours');
Route::get('/tours/category/{id}', [TourCategoryController::class, 'categoryTours'])->name('category-tours');

//------------------------------------------------------------------------------------------




//tour-packages-display-pages


Route::get('/all-tours', [FrontDisplayController::class, 'all_tours'])->name('all-tours');

Route::get('/country', [FrontDisplayController::class, 'allCountry'])->name('all-country');

Route::get('/alltours', [FrontDisplayController::class, 'allsubtours'])->name('allsubtours');

Route::get('/cultural-tours-display/{id}', [FrontDisplayController::class, 'cultural_tours_display'])->name('cultural-tours-display');

Route::get('/wildlife-tours-display/{id}', [FrontDisplayController::class, 'wildlife_tours_display'])->name('wildlife-tours-display');

Route::get('/eco-tours-display/{id}', [FrontDisplayController::class, 'eco_tours_display'])->name('eco-tours-display');




//end of tour-packages-display-pages

//------------------------------------------------------------------------


Route::get('/get_path/{id}', [FrontDisplayController::class, 'get_path'])->name('get_path');

Route::get('/tour-package-details-display/{id}', [FrontDisplayController::class, 'tours_display'])->name('tour-package-details-display');

//-------------------------------------------------------------------------------------------------------------------------------------------





//accommodation

Route::get('/accommodation-display-admin-dash', function () {
    return view('backend.sidebar.accommodations.accommodation-display-admin-dash');
})->name('accommodation-display-admin-dash');

Route::get('/add-accommodation', function () {
    return view('backend.sidebar.accommodations.add-accommodation');
})->name('add-accommodation');


//activities

Route::get('/activity-display-admin-dash', function () {
    return view('backend.sidebar.activities.activity-display-admin-dash');
})->name('activity-display-admin-dash');

Route::get('/add-activity', function () {
    return view('backend.sidebar.activities.add-activity');
})->name('add-activity');

Route::get('/add-activity-category', function () {
    return view('backend.sidebar.activities.add-activity-category');
})->name('add-activity-category');


//events

Route::get('/add-event', function () {
    return view('backend.sidebar.events.add-event');
})->name('add-event');

Route::get('/event-display-admin-dash', function () {
    return view('backend.sidebar.events.event-display-admin-dash');
})->name('event-display-admin-dash');


//excursions

Route::get('/add-excursions', function () {
    return view('backend.sidebar.excursions.add-excursions');
})->name('add-excursions');

Route::get('/excursions-display-admin-dash', function () {
    return view('backend.sidebar.excursions.excursions-display-admin-dash');
})->name('excursions-display-admin-dash');


//gallery

Route::get('/add-images', function () {
    return view('backend.sidebar.gallery.add-images');
})->name('add-images');

Route::get('/gallery-display-admin-dash', function () {
    return view('backend.sidebar.gallery.gallery-display-admin-dash');
})->name('gallery-display-admin-dash');

Route::get('/', [FrontDisplayController::class, 'home'])->name('home');


//tours

Route::get('/add-tour', [ToursAddController::class, 'addTour'])->name('add-tour');
Route::get('/fetch-tour-category', [ToursAddController::class, 'fetch_tour_category'])->name('fetch-tour-category');
Route::get('/add-tour-category', [FrontDisplayController::class, 'addTourCategory'])->name('add-tour-category');

Route::get('/add-tour-more-details', function () {
    return view('backend.sidebar.tours.add-tour-more-details');
})->name('add-tour-more-details');

Route::get('/tour-display-admin-dash', function () {
    return view('backend.sidebar.tours.tour-display-admin-dash');
})->name('tour-display-admin-dash');

Route::get('/tour-more-details-display', function () {
    return view('backend.sidebar.tours.tour-more-details-display');
})->name('tour-more-details-display');

Route::get('/add-more-images', function () {
    return view('backend.sidebar.tours.add-more-images');
})->name('add-more-images');

Route::get('/display-more-images', function () {
    return view('backend.sidebar.tours.display-more-images');
})->name('display-more-images');

//unexplored

Route::get('/add-unexplored', function () {
    return view('backend.sidebar.unexplored.add-unexplored');
})->name('add-unexplored');

Route::get('/unexplored-display-admin-dash', function () {
    return view('backend.sidebar.unexplored.unexplored-display-admin-dash');
})->name('unexplored-display-admin-dash');


//inquiries

Route::get('/inquiries-display-admin-dash', function () {
    return view('backend.sidebar.inquiries.inquiries-display-admin-dash');
})->name('inquiries-display-admin-dash');


//tourers

Route::get('/tourers-display-admin-dash', function () {
    return view('backend.sidebar.tourers.tourers-display-admin-dash');
})->name('tourers-display-admin-dash');


//guides

Route::get('/guides-display-admin-dash', function () {
    return view('backend.sidebar.guides.guides-display-admin-dash');
})->name('guides-display-admin-dash');

Route::get('/guides-see-more-details', function () {
    return view('backend.sidebar.guides.guides-see-more-details');
})->name('guides-see-more-details');



//add tours form
Route::post('/add-tour-details', [ToursAddController::class, 'addTourDetails'])->name('add-tour-details');

//add tour category form
Route::post('/add-tour-category', [TourCategoryController::class, 'addTourCategory'])->name('add-tour-category');

//add excursion form
Route::post('/add-excursion', [ExcursionsAddController::class, 'addExcursionDetails'])->name('add-excursion');

//add unexplored form
Route::post('/add-unexplored', [UnexploredAddController::class, 'addUnexploredDetails'])->name('add-unexplored');

//add event form
Route::post('/add-event', [EventAddController::class, 'addEventDetails'])->name('add-event');

//add accommodation form
Route::post('/add-accommodation', [AccommodationAddController::class, 'addAccommodationDetails'])->name('add-accommodation');

//add images form
Route::post('/add-images', [ImagesAddController::class, 'addImages'])->name('add-images');

//add activity form
Route::post('/add-activity-details', [ActivityAddController::class, 'addActivityDetails'])->name('add-activity-details');

//add activity category form
Route::post('/add-activity-category', [ActivityCategoryController::class, 'addActivityCategory'])->name('add-activity-category');


//tourer and guide login, register

Route::get('/guide-registration', [GuideController::class, 'register'])->name('guide-registration');

Route::get('/register', [TouristController::class, 'register'])->name('register');

Route::get('/book-now-form', [TouristController::class, 'book_now'])->name('book-now-form');

Route::get('/excursions_list', [TouristController::class, 'excursions_list'])->name('excursions_list');

Route::get('/save_selected_excursions', [TouristController::class, 'save_selected_excursions'])->name('save_selected_excursions');

//-----------------------------------------------------------------------------------------------------------------

Route::get('/login', [LoginController::class, 'login'])->name('login');

Route::post('/loginCheck', [LoginController::class,'login_user'])->name('loginCheck');

Route::post('/register_tourist', [RegisterController::class, 'registerTourist'])->name('register_tourist');

Route::post('/guide_register', [RegisterController::class, 'registerGuide'])->name('guide_register');

Route::post('/save-book-now', [RegisterController::class, 'saveBookNow'])->name('save-book-now');

Route::get('/login_agent', [ForgotPasswordManager::class, 'login_agent'])->name('login_agent');
Route::post('/agent_login', [ForgotPasswordManager::class, 'agent_login'])->name('agent_login');
Route::get('/agent_form', [ForgotPasswordManager::class, 'agent_form'])->name('agent_form');
Route::post('/agent_submit', [ForgotPasswordManager::class, 'agent_submit'])->name('agent_submit');

Route::get('/verify_tourist_agent/{token}', [ForgotPasswordManager::class, 'verify_tourist_agent'])->name('verify_tourist_agent');


//-------------------------------------------------------------------------------------------------------------

//admin login register

Route::get('/admin_register', [AdminController::class, 'admin_register'])->name('admin-register');
Route::post('/register_admin', [AdminController::class, 'register_admin'])->name('register_admin');

Route::get('/admin-login', [AdminController::class, 'admin_login'])->name('admin-login');
Route::post('/admin-loginCheck', [LoginController::class, 'login'])->name('admin-loginCheck');

Route::get('/admin-dashboard-view', [AdminController::class, 'admin_dashboard_view'])->name('admin-dashboard-view');

//--------------------------------------------------------------------------------------------------------------------------

//contact form

Route::get('/contactus', [ContactController::class, 'contact_us'])->name('contactus');

//--------------------------------------------------------------------------------------------------------------------------

//country codes and flags list

Route::get('countries_and_flags', [CountryCodeAndFlagsController::class, 'countries_and_flags']);

//----------------------------------------------------------------------------------------------------------------------------

//contact-form-email

Route::get('/send-email', [ContactController::class, 'sendEmail'])->name('send-email');

//emails / verification

Route::get('/verify_tourist/{token}', [RegisterController::class, 'verify_tourist'])->name('verify_tourist');

Route::get('/verify_booked_tourist/{token_booked}', [RegisterController::class, 'verify_booked_tourist'])->name('verify_booked_tourist');

Route::get('/verify_guide/{token_g}', [RegisterController::class, 'verify_guide'])->name('verify_guide');

//---------------------------------------------------------------------------------------------------------------------------

Route::get('/guide-profile-display/{id}', [GuideController::class, 'guide_profile_display'])->name('guide-profile-display');

//-----------------------------------------------------------------------------------------------------------------------------

Route::get('/guides', [FrontDisplayController::class, 'guides'])->name('guides');

//-------------------------------------------------------------------------------------------------------------------
Auth::routes();

//Route::get('/admin-dashboard-view', [AdminController::class, 'admin_dashboard_view'])->name('admin-dashboard-view');

//Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

Route::middleware(['auth', 'user-access:tourer'])->group(function () {

    Route::get('/tourist-profile', [TouristController::class, 'tourist_profile'])->name('tourist-profile');

    Route::post('/jot-reviews', [TouristController::class, 'saveReview'])->name('jot_reviews');

    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

    Route::post('/profile-picture', [TouristController::class, 'saveProfile_picture'])->name('profile-picture');

    Route::post('/jot_reviews', [ReviewController::class, 'jot_reviews'])->name('jot_reviews');

    Route::post('/guide_reviews', [ReviewController::class, 'guide_reviews'])->name('guide_reviews');

    Route::post('/save-book-now-registered', [TouristController::class, 'saveBookNowRegistered'])->name('save-book-now-registered');

    Route::get('/view_booked_tours', [TouristController::class, 'view_booked_tours'])->name('view_booked_tours');

    Route::delete('/cancel_tour/{id}', [TouristController::class, 'cancel_tour'])->name('cancel_tour');

//    Route::get('/view_booked_tours', [TouristController::class, 'view_booked_tours'])->name('view_booked_tours');

    Route::get('/view_create_tourist', [TouristController::class, 'view_create_tourist'])->name('view_create_tourist');

    Route::get('/edit_book_now_form/{id}', [TouristController::class, 'edit_book_now_form'])->name('edit_book_now_form');

    Route::put('/edit-book-now/{id}', [TouristController::class, 'edit_book_now'])->name('edit-book-now');

    Route::get('/edit_excursion_list/{id}', [TouristController::class, 'edit_excursion_list'])->name('edit_excursion_list');



    //create_tourist page
    Route::get('/create_tourist/{id}', [TouristController::class, 'create_tourist'])->name('create_tourist');

    Route::get('/touer_confirmed_list', [TouristController::class, 'touer_confirmed_list'])->name('touer_confirmed_list');

    Route::post('/save_booking_data', [TouristController::class, 'save_booking_data'])->name('save_booking_data');

    //touris notification route details

    Route::get('/quotation_notification', [NotifyrController::class, 'quotation_notification'])->name('quotation_notification');

    Route::get('/quotation_notification/{id}', [NotifyrController::class, 'amount'])->name('amount');

    Route::get('/notification-count', [NotifyrController::class, 'getNotificationCount'])->name('getNotificationCount');
    Route::post('/mark-notification-as-read', [NotifyrController::class, 'markNotificationAsRead'])->name('markNotificationAsRead');

//negotiate form and button details

    Route::get('/quotation_comments/{id}', [NotifyrController::class, 'quotation_comments'])->name('quotation_comments');

    Route::post('add_negotiate_comment', [NotifyrController::class, 'add_negotiate_comment'])->name('add_negotiate_comment');
// confirm button route
    Route::post('/confirm_quotation', [NotifyrController::class, 'status_confirm'])->name('status_confirm');

//payment swift copy
    Route::get('/tourer_payment', [NotifyrController::class, 'tourer_payment'])->name('tourer_payment');

    Route::get('/tourer_payment/{id}', [NotifyrController::class, 'payment'])->name('payment');

    Route::post('/pay_reviews', [ReviewController::class, 'pay_reviews'])->name('pay_reviews');

    Route::post('/pay_reviews', [ReviewController::class, 'pay_reviews'])->name('pay_reviews');

    Route::get('/quotation/{id}/edit-image', [ReviewController::class, 'edit_image'])->name('edit_image');

    Route::post('/quotation/{id}/update-image', [ReviewController::class, 'update_image'])->name('update_image');

});



Route::middleware(['auth', 'user-access:guide'])->group(function () {

    Route::get('/guide-profile', [GuideController::class, 'guide_profile'])->name('guide-profile');

    Route::get('/guide-profile-edit', [GuideController::class, 'guide_profile_edit'])->name('guide-profile-edit');

    Route::post('/guide_tour_images', [ReviewController::class, 'guide_tour_images'])->name('guide_tour_images');

    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

});



//end of the login-register
Route::get("/forgot-password", [ForgotPasswordManager::class, "forgotPassword"])->name("forgot.password");

Route::post("/forgot-password", [ForgotPasswordManager::class, "forgotPasswordPost"])->name("forgot.password.post");

Route::get("/reset-password/{token}", [ForgotPasswordManager::class, "resetPassword"])->name("reset.password");

Route::get("/reset-password", [ForgotPasswordManager::class, "reset_Password"])->name("reset.password.post");

Route::post("/reset-password", [ForgotPasswordManager::class, "resetPasswordPost"])->name("reset.password.post");

//----------------------------------------



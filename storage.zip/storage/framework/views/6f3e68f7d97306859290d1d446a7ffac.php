<?php $__env->startSection('content'); ?>

<!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/unexplored" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Unexplored
                                </a>
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                                Journey Beyond the Ordinary with Our Unexplored Tours
                            </h3>
            
        </div>
         
      
        <!-- common banner -->

<section class="package-details"style="margin-bottom: -15px;">
    <div class="container">
        <div class="row">
             <?php $__currentLoopData = $unexplored; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-content">
                    <div class="blog-image">
                      <img src="<?php echo e(config('app.frontend_url') . "{$data->image}"); ?>" alt="image" />
                    </div>
                    <div class="blog-info">
                        <div class="footer-info">

                            <a class="blog-title" style="color: #f67a59; font-weight: bolder; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: inline-block; max-width: 100%;"><?php echo e($data->unexplored_name); ?></a>
                            <p class="descriptionParagraph" style="justify-content: center"><?php echo e($data->description); ?></p>
                            
                        </div>
                    </div>
                </div>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<style>

     a:hover {
                    color: #ff6f00 !important;
                }
    .readMoreButton {
        font-weight: bold;
        background: none;
        border: none;
        color: black;
        cursor: pointer;
        padding: 0;
    }

    .readMoreButton:hover {
        text-decoration: underline;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var descriptionParagraphs = document.querySelectorAll(".descriptionParagraph");

        descriptionParagraphs.forEach(function (paragraph) {
            var maxLength = 100; // Change this value to your desired character limit
            var fullText = paragraph.textContent;

            if (fullText.length > maxLength) {
                var shortText = fullText.substring(0, maxLength) + '...';
                paragraph.innerHTML = shortText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
                paragraph.setAttribute("data-full-text", fullText);
            }
        });
    });

    function toggleReadMore(button) {
        var paragraph = button.parentNode;
        var fullText = paragraph.getAttribute("data-full-text");

        if (button.textContent === "Read More") {
            button.textContent = "Read Less";
            paragraph.innerHTML = fullText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read Less</button>';
        } else {
            button.textContent = "Read More";
            paragraph.innerHTML = fullText.substring(0, 100) + '... <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
        }
    }
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Keen Rabbits\starluxe8.4\front-new (2)\front-new\idea (SLF)\resources\views/pages/nav-bar-pages/unexplored.blade.php ENDPATH**/ ?>
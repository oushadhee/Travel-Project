<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        * {
            box-sizing: border-box;
        }

        .square-image {
            width: 200px;
            /* Set the width of the square */
            height: 200px;
            /* Set the height of the square */
            object-fit: cover;
            /* This ensures the image covers the entire container */
        }

        /* Position the image container (needed to position the left and right arrows) */
        .container {
            position: relative;
        }

        /* Hide the images by default */
        .mySlides {
            display: none;
        }

        /* Add a pointer when hovering over the thumbnail images */
        .cursor {
            cursor: pointer;
        }

        /* Next & previous buttons */
        .prev,
        .next {
            cursor: pointer;
            position: absolute;
            top: 40%;
            width: auto;
            padding: 16px;
            margin-top: -50px;
            color: white;
            font-weight: bold;
            font-size: 20px;
            border-radius: 0 3px 3px 0;
            user-select: none;
            -webkit-user-select: none;
        }

        @media (max-width: 700px) {
            .bb {
                text-align: center;
            }

            .mtt {
                margin-top: 50px;
            }
        }

        @media (min-width: 700px) {
            .cc {
                text-align: right;
            }
        }

        text-align: right;

        /.blog-content {
            /
            /*    background: linear-gradient(to bottom, rgba(8, 102, 255, 0.2), rgba(8, 102, 255, 0.2));*/
            /
        }

        /
        /* Position the "next button" to the right */
        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        /* On hover, add a black background color with a little bit see-through */
        .prev:hover,
        .next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        /* Number text (1/3 etc) */
        .numbertext {
            color: #f2f2f2;
            font-size: 12px;
            padding: 8px 12px;
            position: absolute;
            top: 0;
        }

        /* Container for image text */
        .caption-container {
            text-align: center;
            background-color: #222;
            padding: 2px 16px;
            color: white;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        /* Six columns side by side */
        .column {
            float: left;
            width: 16.66%;
        }

        /* Add a transparency effect for thumnbail images */
        .demo {
            opacity: 0.6;
        }

        .active,
        .demo:hover {
            opacity: 1;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            width: 100%;
            padding: 0.5rem 0;
            margin: 0;
            font-size: 1.8rem;
            color: #212529;
            text-align: left;
            list-style: none;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: 0.25rem;
        }

        .dropdown-item {
            display: block;
            width: 100%;
            padding: 0.25rem 1.5rem;
            clear: both;
            font-weight: 400;
            color: #212529;
            text-align: inherit;
            white-space: nowrap;
            background-color: transparent;
            border: 0;
            cursor: pointer;
        }

        .dropdown-item:hover {
            background-color: #f8f9fa;
        }

        * {
            box-sizing: border-box;
        }

        .square-image {
            width: 200px;
            /* Set the width of the square */
            height: 200px;
            /* Set the height of the square */
            object-fit: cover;
            /* This ensures the image covers the entire container */
        }

        /* Position the image container (needed to position the left and right arrows) */
        .container {
            position: relative;
        }

        /* Hide the images by default */
        .mySlides {
            display: none;
        }

        /* Add a pointer when hovering over the thumbnail images */
        .cursor {
            cursor: pointer;
        }

        /* Next & previous buttons */
        .prev,
        .next {
            cursor: pointer;
            position: absolute;
            top: 40%;
            width: auto;
            padding: 16px;
            margin-top: -50px;
            color: white;
            font-weight: bold;
            font-size: 20px;
            border-radius: 0 3px 3px 0;
            user-select: none;
            -webkit-user-select: none;
        }

        @media (max-width: 700px) {
            .bb {
                text-align: center;
            }

            .mtt {
                margin-top: 50px;
            }
        }

        @media (min-width: 700px) {
            .cc {
                text-align: right;
            }
        }

        text-align: right;

        /.blog-content {
            /
            /*    background: linear-gradient(to bottom, rgba(8, 102, 255, 0.2), rgba(8, 102, 255, 0.2));*/
            /
        }

        /
        /* Position the "next button" to the right */
        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        /* On hover, add a black background color with a little bit see-through */
        .prev:hover,
        .next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        /* Number text (1/3 etc) */
        .numbertext {
            color: #f2f2f2;
            font-size: 12px;
            padding: 8px 12px;
            position: absolute;
            top: 0;
        }

        /* Container for image text */
        .caption-container {
            text-align: center;
            background-color: #222;
            padding: 2px 16px;
            color: white;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        /* Six columns side by side */
        .column {
            float: left;
            width: 16.66%;
        }

        /* Add a transparency effect for thumnbail images */
        .demo {
            opacity: 0.6;
        }

        .active,
        .demo:hover {
            opacity: 1;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            z-index: 1000;
            display: none;
            width: 100%;
            padding: 0.5rem 0;
            margin: 0;
            font-size: 1.8rem;
            color: #212529;
            text-align: left;
            list-style: none;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: 0.25rem;
        }

        .dropdown-item {
            display: block;
            width: 100%;
            padding: 0.25rem 1.5rem;
            clear: both;
            font-weight: 400;
            color: #212529;
            text-align: inherit;
            white-space: nowrap;
            background-color: transparent;
            border: 0;
            cursor: pointer;
        }

        .dropdown-item:hover {
            background-color: #f8f9fa;
        }



        /* Default styling for smaller screens */
        .button-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-container .btn {
            width: 80%;
            margin: 10px 0;
        }

        /* Medium screens and above */
        @media (min-width: 768px) {
            .button-container {
                flex-direction: row;
                justify-content: space-between;
            }

            .button-container .btn {
                width: auto;
                margin: 0;
            }

            .button-container .btn:first-child {
                margin-left: 150px;
            }

            .button-container .btn:last-child {
                margin-right: 100px;
            }
        }

        /* Large screens and above */
        @media (min-width: 992px) {
            .button-container {
                flex-direction: row;
                justify-content: space-between;
            }

            .button-container .btn:first-child {
                margin-left: 150px;
            }

            .button-container .btn:last-child {
                margin-right: 100px;
            }
        }

        /table data css/


        /* Table Styling - Added to match your image */
        #example1 {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-family: 'Arial', sans-serif;
            margin: 20px 0;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        #example1 thead th {
            background-color: #2c3e50;
            color: white;
            font-weight: bold;
            padding: 12px 15px;
            text-align: left;
            border: none;
        }

        #example1 tbody tr {
            background-color: white;
        }

        #example1 tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        #example1 tbody td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            vertical-align: middle;
        }

        #example1 tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Column specific styling */
        #example1 tbody td:first-child {
            color: #2c3e50;
            font-weight: normal;
        }

        #example1 tbody td:nth-child(3) {
            /* Number of days column */
            color: #7f8c8d;
        }

        /* Status styling */
        .status-pending {
            color: #856404;
            background-color: #fff3cd;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
        }

        .status-confirmed {
            color: #155724;
            background-color: #d4edda;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
        }

        /* Action buttons */
        .btn-group-booked .btn {
            margin: 2px;
            padding: 5px 10px;
            font-size: 12px;
            border-radius: 3px;
        }

        .btn-info {
            background-color: white;
            border-color: white;
        }

        .custom-btn-warning {
            background-color: #f39c12;
            border-color: #f39c12;
            color: white;
        }

        .btn-success {
            background-color: #27ae60;
            border-color: #27ae60;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            #example1 {
                display: block;
                overflow-x: auto;
            }
        }
    </style>


    <!-- tour guide -->


    <div id="time-table" class="time-table-section">
        <div class="blog" style="padding-top:5%; padding-bottom:5%;">
            <div class="container">
                <div class="blog-content"
                    style="background: linear-gradient(to bottom, rgba(8, 102, 255, 0.2), rgba(8, 102, 255, 0.2));">
                    <div class="blog-image" style="height: auto;">
                        <div class="deals-content block">
                            <div class="deals-image custom-imagerow">
                                <div class="row">
                                    <!-- User Profile Card -->
                                    <div class="col-lg-12">
                                        <div
                                            style="padding: 30px; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                                            <div class="row align-items-center">
                                                <!-- Profile Picture Column -->
                                                <div class="col-lg-3 text-center">
                                                    <?php if(auth()->user() && auth()->user()->profile_pic): ?>
                                                        <img src="<?php echo e(asset(auth()->user()->profile_pic)); ?>?v=<?php echo e(time()); ?>"
                                                            style="width: 180px; height: 180px; border-radius: 50%; object-fit: cover; border: 5px double #FE7524; padding: 5px;">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/profile/user-avatar.svg.png')); ?>"
                                                            style="width: 180px; height: 180px; border-radius: 50%; object-fit: cover; border: 5px double #FE7524; padding: 5px;">
                                                    <?php endif; ?>
                                                    <form method="POST" id="profilePictureForm"
                                                        enctype="multipart/form-data"
                                                        action="<?php echo e(route('profile-picture')); ?>" class="mt-4">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="file" id="profilePictureInput" name="profile_pic"
                                                            style="display:none" accept="image/*" onchange="submitForm()">
                                                        <button type="button" class="btn-1"
                                                            onclick="selectProfilePicture()">
                                                            Update Photo
                                                        </button>
                                                    </form>
                                                </div>

                                                <!-- User Info Column -->
                                                <div class="col-lg-9">
                                                    <h2
                                                        style="color: #333; border-bottom: 2px solid #FE7524; padding-bottom: 10px; margin-bottom: 25px;font-family:'roboto';">
                                                        <?php echo e(Auth::user()->f_name); ?> <?php echo e(Auth::user()->l_name); ?>

                                                    </h2>

                                                    <!-- First Row - Country and Phone -->
                                                    <div class="row mb-3">
                                                        <!-- Country -->
                                                        <div class="col-md-6">
                                                            <div
                                                                style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px; height: 100%;">
                                                                <i class="fas fa-globe"
                                                                    style="color: #FE7524; font-size: 24px; margin-right: 15px;"></i>
                                                                <div>
                                                                    <div
                                                                        style="font-weight: 600; color: #6c757d; font-size: 14px;">
                                                                        COUNTRY</div>
                                                                    <div style="font-size: 16px;">
                                                                        <?php echo e(Auth::user()->country); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Mobile -->
                                                        <div class="col-md-6">
                                                            <div
                                                                style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px; height: 100%;">
                                                                <i class="fas fa-mobile-alt"
                                                                    style="color: #FE7524; font-size: 24px; margin-right: 15px;"></i>
                                                                <div>
                                                                    <div
                                                                        style="font-weight: 600; color: #6c757d; font-size: 14px;">
                                                                        MOBILE</div>
                                                                    <div style="font-size: 16px; white-space: nowrap;">
                                                                        <?php echo e(Auth::user()->m_phone_1_country_code); ?>

                                                                        <?php echo e(chunk_split(Auth::user()->m_phone_1, 3, ' ')); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!-- Second Row - Email and Address -->
                                                    <div class="row">
                                                        <!-- Email -->
                                                        <div class="col-md-6">
                                                            <div
                                                                style="display: flex; align-items: flex-start; padding: 15px; background: #f8f9fa; border-radius: 8px; height: 100%;">
                                                                <i class="fas fa-envelope"
                                                                    style="color: #FE7524; font-size: 24px; margin-right: 15px; margin-top: 3px;"></i>
                                                                <div style="min-width: 0;">
                                                                    <div
                                                                        style="font-weight: 600; color: #6c757d; font-size: 14px; margin-bottom: 5px;">
                                                                        EMAIL</div>
                                                                    <div
                                                                        style="font-size: 16px; word-break: break-all; line-height: 1.4;">
                                                                        <?php echo e(Auth::user()->email); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Address -->
                                                        <div class="col-md-6">
                                                            <div
                                                                style="display: flex; align-items: flex-start; padding: 15px; background: #f8f9fa; border-radius: 8px; height: 100%;">
                                                                <i class="fas fa-map-marker-alt"
                                                                    style="color: #FE7524; font-size: 24px; margin-right: 15px; margin-top: 3px;"></i>
                                                                <div>
                                                                    <div
                                                                        style="font-weight: 600; color: #6c757d; font-size: 14px;">
                                                                        ADDRESS</div>
                                                                    <div style="font-size: 16px;">
                                                                        <?php echo e(Auth::user()->address); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                               <div style=" align-items: right">
    <div class="header-link-btn" style="margin-left:80px;margin-top:10px;">
        <a href="<?php echo e(route('book-now-form')); ?>" class="btn-1" >Book a Tour<span></span></a>
    </div>
</div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>

                    <br><br>

                    <section>
                        <div class="content">
                            <div class="card_booked" style="box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px;">
                                

                                <div class="card-body-booked" style="padding: 20px;">
                                    
                                    <?php if($message = Session::get('error')): ?>
                                        <div class="alert alert-danger alert-block">
                                            <button type="button" class="close" data-dismiss="alert">×</button>
                                            <strong><?php echo e($message); ?></strong>
                                        </div>
                                    <?php endif; ?>

                                    <div class="table-responsive">
                                        <table id="example1" class="table"
                                            style="width: 100%; border-collapse: separate; border-spacing: 0;">
                                            <thead>
                                                <tr style="background-color: #fe7524; color: white;">
                                                    <th style="padding: 12px 15px; text-align: left;">Start Date</th>
                                                    <th style="padding: 12px 15px; text-align: left;">End Date</th>
                                                    <th style="padding: 12px 15px; text-align: left;">Number of days</th>
                                                    <th style="padding: 12px 15px; text-align: left;">Status</th>
                                                    <th style="padding: 12px 15px; text-align: center;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
    $tour = \App\Models\BookNow::whereNull('is_deleted')
        ->where('user_id', Auth::user()->id)
        ->where('status', '!=', 'Cancelled')
        ->get();
                                                ?>

                                                <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr style="border-bottom: 1px solid #e0e0e0;">
                                                        <td style="padding: 12px 15px; color: #333;">
                                                            <?php echo e($tourDetails->start_date); ?>

                                                        </td>
                                                        <td style="padding: 12px 15px; color: #333;">
                                                            <?php echo e($tourDetails->end_date); ?>

                                                        </td>
                                                        <td style="padding: 12px 15px; color: #666;">
                                                            <?php echo e($tourDetails->number_of_days); ?>

                                                        </td>
                                                        <td style="padding: 12px 15px;">
                                                            <span style="display: inline-block; padding: 3px 8px; border-radius: 3px; 
                                                                                      <?php if($tourDetails->status == 'Pending'): ?> 
                                                                                          background-color: #fff3cd; color: #856404;
                                                                                      <?php elseif($tourDetails->status == 'Confirmed'): ?>
                                                                                          background-color: #d4edda; color: #155724;
                                                                                      <?php else: ?>
                                                                                          background-color: #f8f9fa; color: #333;
                                                                                      <?php endif; ?>">
                                                                <?php echo e($tourDetails->status); ?>

                                                            </span>
                                                        </td>
                                                        <td class="text-right py-0 align-middle" style="padding: 12px 15px;">
                                                            <div class="btn-group-booked btn-group-sm"
                                                                style="display: flex; gap: 8px; justify-content: flex-end;">
                                                                <a href="<?php echo e(route('edit_book_now_form', ['id' => $tourDetails->id])); ?>"
                                                                    class="btn btn-info"
                                                                    style="background-color: #3498db; color: white; padding: 8px; border-radius: 50%; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;"
                                                                    onclick="return confirm('Are you sure you want to edit this tour?')">
                                                                    <i class="fas fa-eye"></i>
                                                                </a>

                                                                <form id="cancel-form-<?php echo e($tourDetails->id); ?>"
                                                                    action="<?php echo e(route('cancel_tour', ['id' => $tourDetails->id])); ?>"
                                                                    method="POST" style="display: none;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>

                                                                <a href="#" class="btn btn-warning custom-btn-warning"
                                                                    style="background-color: #f39c12; color: white; padding: 8px; border-radius: 50%; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;"
                                                                    onclick="cancelTour(<?php echo e($tourDetails->id); ?>); return false;">
                                                                    <i class="fas fa-x"></i>
                                                                </a>





                                                                <a href="<?php echo e(route('quotation_notification')); ?>"
                                                                    class="btn btn-success"
                                                                    style="background-color: #f67a59; color: white; padding: 8px 12px; border-radius: 20px; display: inline-flex; align-items: center;">
                                                                    View Quotation
                                                                </a>




                                                                <a href="<?php echo e(route('tourer_payment')); ?>" class="btn btn-success"
                                                                    style="background-color: #f67a59; color: white; padding: 8px 12px; border-radius: 20px; display: inline-flex; align-items: center;">
                                                                    Payment
                                                                </a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>



                    
                </div>
            </div>
        </div>
    </div>


    </div>


    <div class="container">
        <div class="row d-flex justify-content-around">

            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="padding:0%;">
                <section class="package-details" style="padding:15px; padding-top:0%;">
                    <div class="card" style="width: 100%;">
                        <img src="assets\images\banner\a1.jpeg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Feedback</h5>
                            <p class="card-text">
                            <div class="destination-common-title">
                                <h5 style="color:#1c333e ; font-weight: bolder; text-align: center">We value your feedback.
                                    Tell us about your trip with Starluxe Travels!</h5>
                            </div>
                            </p>
                            <div class="d-flex justify-content-center">
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#exampleModal" style="background-color: #f67a59; width:150px; height:40px;">
                                    Click Here
                                </button>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            
            <?php if(isset($bookNow)): ?>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="padding:0%;">
                    <section class="package-details" style="padding:15px; padding-top:0%;">
                        <div class="card" style="width: 100%;">
                            <img src="assets\images\banner\66.jpeg" class="card-img-top" alt="..." style="height: 195px">
                            <div class="card-body">
                                <h5 class="card-title">Confirmed</h5>
                                <p class="card-text">
                                <div class="destination-common-title">
                                    <h5 style="color:#1c333e ; font-weight: bolder; text-align: center">We have confirmed your
                                        booking tours. Check it out!!!</h5>
                                </div>
                                </p>
                                <div class="d-flex justify-content-center">
                                    <a href="<?php echo e(route('touer_confirmed_list')); ?>" class="btn btn-primary"
                                        style="background-color: #f67a59; width:150px; height:30px;padding:20px;">
                                        Click Here
                                    </a>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            <?php endif; ?>
            

            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="padding:0%;">
                <section class="package-details" style="padding:15px; padding-top:0%;">
                    <div class="card" style="width: 100%;">
                        <img src="assets\images\banner\a2.jpeg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Experience</h5>
                            <p class="card-text">
                            <div class="destination-common-title">
                                <h5 style="color:#1c333e ; font-weight: bolder; text-align: center">Share your experience!
                                    Tell us about your guide and how they made your trip special.</h5>
                            </div>
                            </p>
                            <div class="d-flex justify-content-center">
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#exampleModalGuide" style="background-color: #f67a59; width:150px; height:40px;">
                                    Click Here
                                </button>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </div>
    </div>


    
    <div class="col-lg-2 col-md-2 col-sm-0 col-xs-0"></div>
    </div>
    </div>
    </div>


<!-- Tour Review Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #f67a59; color: #fff;">
                <h5 class="modal-title" id="exampleModalLabel">We Would Love to Hear From You!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <section class="formregister">
                    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('jot_reviews')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input type="hidden" id="user_id" name="user_id" value="<?php echo e(Auth::user()->id); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="tour_category_id">Tour Category:</label>
                            <select id="tour_category_id" name="tour_category_id" class="form-control">
                                <option value="" disabled selected>Select a tour category</option>
                                <?php $__currentLoopData = $tourCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['tour_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="tour_type">Tour Type:</label>
                            <select id="tour_type" name="tour_type" class="form-control" required>
                                <option value="" disabled selected>Select a tour type</option>
                                <option value="Cultural">Cultural</option>
                                <option value="Wildlife">Wildlife</option>
                                <option value="Eco">Eco</option>
                            </select>
                            <?php $__errorArgs = ['tour_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="rating">Your Rating:</label>
                            <div class="star-rating">
                                <?php for($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" id="guide-star<?php echo e($i); ?>" name="rating" value="<?php echo e($i); ?>" <?php echo e($i == 3 ? 'checked' : ''); ?> required>
                                    <label for="guide-star<?php echo e($i); ?>" title="<?php echo e($i); ?> stars"></label>
                                <?php endfor; ?>
                            </div>
                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="comment_jot">Your Comment:</label>
                            <textarea id="comment_jot" name="comment_jot" class="form-control" required></textarea>
                            <?php $__errorArgs = ['comment_jot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="suggestions_jot">Your Suggestions:</label>
                            <textarea id="suggestions_jot" name="suggestions_jot" class="form-control" required></textarea>
                            <?php $__errorArgs = ['suggestions_jot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="start_date">Start Date of the Tour:</label>
                            <input type="date" id="start_date" name="start_date" class="form-control" required>
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="end_date">End Date of the Tour:</label>
                            <input type="date" id="end_date" name="end_date" class="form-control" required>
                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="country">Country:</label>
                            <select id="country" name="country" class="form-control" required>
                                <option value="" disabled selected>Select a country</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <!-- Add more countries as needed -->
                            </select>
                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="tour_photos">Tour Photos:</label>
                            <input type="file" id="tour_photos" name="tour_photos[]" class="form-control-file" multiple accept="image/*">
                            <?php $__errorArgs = ['tour_photos.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary">Submit Review</button>
                        </div>
                    </form>
                </section>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
    .modal-content {
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        font-family: 'Corbel', 'Arial', sans-serif;
        background-color: #fff;
    }

    .modal-header {
        border-bottom: none;
        padding: 20px;
    }

    .modal-title {
        font-size: 1.5em;
        font-weight: 600;
    }

    .modal-body {
        padding: 20px 30px;
    }

    .modal-footer {
        border-top: none;
        padding: 15px 30px;
    }

    .formregister {
        max-width: 100%;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        font-size: 1em;
        font-weight: 500;
        color: #333;
        margin-bottom: 8px;
        display: block;
    }

    .form-control, .form-control-file {
        border: 1px solid #ced4da;
        border-radius: 5px;
        padding: 10px;
        font-size: 1em;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus, .form-control-file:focus {
        border-color: #f67a59;
        box-shadow: 0 0 5px rgba(246, 122, 89, 0.3);
        outline: none;
    }

    textarea.form-control {
        resize: vertical;
        min-height: 100px;
        max-height: 200px;
    }

    select.form-control {
        appearance: none;
        background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24"><path fill="#666" d="M7 10l5 5 5-5z"/></svg>') no-repeat right 10px center;
        background-size: 12px;
    }

    .form-control-file {
        padding: 8px 0;
    }

    .star-rating {
        display: flex;
        flex-direction: row-reverse;
        justify-content: flex-end;
        gap: 5px;
    }

    .star-rating input {
        position: absolute;
        opacity: 0;
        width: 0;
        height: 0;
    }

    .star-rating label {
        font-size: 1.5em;
        color: #ccc;
        cursor: pointer;
        transition: color 0.2s ease;
    }

    .star-rating label:before {
        content: '★';
    }

    .star-rating input:checked ~ label,
    .star-rating input:hover ~ label,
    .star-rating label:hover {
        color: #f67a59;
    }

    .btn-primary {
        background-color: #f67a59;
        border: none;
        padding: 12px 30px;
        font-size: 1em;
        font-weight: 500;
        border-radius: 5px;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .btn-primary:hover {
        background-color: #e55a3a;
        transform: translateY(-2px);
    }

    .btn-secondary {
        background-color: #6c757d;
        border: none;
        padding: 10px 20px;
        font-size: 1em;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }

    .error-text {
        color: #dc3545;
        font-size: 0.85em;
        margin-top: 5px;
        display: block;
    }

    @media (max-width: 576px) {
        .modal-dialog {
            margin: 10px;
        }

        .modal-content {
            padding: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .btn-primary {
            width: 100%;
            padding: 12px;
        }

        .star-rating label {
            font-size: 1.2em;
        }
    }
</style>

<script>
    document.querySelector('form').addEventListener('submit', function(event) {
        const rating = document.querySelector('input[name="rating"]:checked');
        if (!rating) {
            event.preventDefault();
            alert('Please select a rating before submitting.');
        }
    });
</script>



<!-- Guide Review Modal -->
<div class="modal fade" id="exampleModalGuide" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #f67a59; color: #fff;">
                <h5 class="modal-title" id="exampleModalLabel">We Would Love to Hear About Your Guide!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <section class="formregister">
                    <form method="POST" action="<?php echo e(route('guide_reviews')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input type="hidden" id="id" name="id" value="<?php echo e(Auth::user()->id); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="rating">Your Rating:</label>
                            <div class="star-rating">
                                <?php for($i = 5; $i >= 1; $i--): ?>
                                    <input type="radio" id="guide-star<?php echo e($i); ?>" name="rating" value="<?php echo e($i); ?>" required>
                                    <label for="guide-star<?php echo e($i); ?>" title="<?php echo e($i); ?> stars"></label>
                                <?php endfor; ?>
                            </div>
                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="selected_guide">Guide Name:</label>
                            <?php
                                $userGuides = \App\Models\User::whereNull('is_deleted')->where('user_type', 'guide')->get();
                            ?>
                            <?php if(!empty($userGuides)): ?>
                                <select class="form-control" id="selected_guide" name="selected_guide" required>
                                    <option value="" disabled selected>Select a guide</option>
                                    <?php $__currentLoopData = $userGuides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($guide->id); ?>" data-image="<?php echo e($guide->profile_image ? asset('storage/' . $guide->profile_image) : asset('assets/images/guides/placeholder.png')); ?>">
                                            <?php echo e($guide->f_name); ?> <?php echo e($guide->l_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php else: ?>
                                <p class="no-guides">No guides available</p>
                            <?php endif; ?>
                            <?php $__errorArgs = ['selected_guide'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="comment_guide">Your Comment:</label>
                            <textarea id="comment_guide" name="comment_guide" class="form-control" required></textarea>
                            <?php $__errorArgs = ['comment_guide'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="suggestions_guide">Your Suggestions:</label>
                            <textarea id="suggestions_guide" name="suggestions_guide" class="form-control" required></textarea>
                            <?php $__errorArgs = ['suggestions_guide'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error-text"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary">Submit Review</button>
                        </div>
                    </form>
                </section>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>

    <style>
        /* Modal styling */
        .modal-content {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            font-family: 'Corbel', 'Arial', sans-serif;
            background-color: #fff;
        }

        .modal-header {
            border-bottom: none;
            padding: 20px;
        }

        .modal-title {
            font-size: 1.5em;
            font-weight: 600;
        }

        .modal-body {
            padding: 20px 30px;
        }

        .modal-footer {
            border-top: none;
            padding: 15px 30px;
        }

        /* Form styling */
        .formregister {
            max-width: 100%;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 1em;
            font-weight: 500;
            color: #333;
            margin-bottom: 8px;
            display: block;
        }

        .form-control {
            border: 1px solid #ced4da;
            border-radius: 5px;
            padding: 10px;
            font-size: 1em;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-control:focus {
            border-color: #f67a59;
            box-shadow: 0 0 5px rgba(246, 122, 89, 0.3);
            outline: none;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 100px;
            max-height: 200px;
        }

        select.form-control {
            appearance: none;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24"><path fill="#666" d="M7 10l5 5 5-5z"/></svg>') no-repeat right 10px center;
            background-size: 12px;
        }

        .no-guides {
            color: #666;
            font-size: 0.9em;
            margin-top: 5px;
        }

        /* Star rating styling */
        .star-rating {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-end;
            gap: 5px;
        }

        .star-rating input {
            display: none;
        }

        .star-rating label {
            font-size: 1.5em;
            color: #ccc;
            cursor: pointer;
            transition: color 0.2s ease;
        }

        .star-rating label:before {
            content: '★';
        }

        .star-rating input:checked ~ label,
        .star-rating input:hover ~ label,
        .star-rating label:hover {
            color: #f67a59;
        }

        /* Button styling */
        .btn-primary {
            background-color: #f67a59;
            border: none;
            padding: 12px 30px;
            font-size: 1em;
            font-weight: 500;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-primary:hover {
            background-color: #e55a3a;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background-color: #6c757d;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        /* Error styling */
        .error-text {
            color: #dc3545;
            font-size: 0.85em;
            margin-top: 5px;
            display: block;
        }

        /* Guide image styling */
        .deals-image.custom-image {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #guide-image {
            transition: opacity 0.3s ease;
        }

        #guide-image:hover {
            opacity: 0.8;
        }

        /* Responsive design */
        @media (max-width: 576px) {
            .modal-dialog {
                margin: 10px;
            }

            .modal-content {
                padding: 10px;
            }

            .form-group {
                margin-bottom: 15px;
            }

            .btn-primary {
                width: 100%;
                padding: 12px;
            }

            .star-rating label {
                font-size: 1.2em;
            }

            .deals-image.custom-image {
                margin: 20px 0;
            }

            #guide-image {
                height: 200px;
                width: 200px;
            }
        }
    </style>

    <script>
        // Update guide image when a guide is selected
        document.getElementById('selected_guide').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const imageSrc = selectedOption.getAttribute('data-image') || "<?php echo e(asset('assets/images/guides/placeholder.png')); ?>";
            const guideImage = document.getElementById('guide-image');
            guideImage.src = imageSrc;
            guideImage.style.display = 'block';
        });

        // Set default image on page load
        window.addEventListener('load', function() {
            const select = document.getElementById('selected_guide');
            if (select.options.length > 1) {
                const firstOption = select.options[1];
                const imageSrc = firstOption.getAttribute('data-image') || "<?php echo e(asset('assets/images/guides/placeholder.png')); ?>";
                document.getElementById('guide-image').src = imageSrc;
                document.getElementById('guide-image').style.display = 'block';
            }
        });
    </script>
</div>


    

    <div class="col-lg-4">
        <div class="package-details-right-container">

            <br>

            <br><br>

            <div class="col-md-12">
                <br><br>
            </div>

            <div class="destination-common-title">
                <h5 style="color:#f67a59 ; font-weight: bolder; text-align: center"></h5>
            </div>

        </div>

    </div>

    </div>
    </div>
    </div>
    </section>
    <!-- tour package details -->
    </div>

    <!-- Container for the image gallery -->
    <script>
        let slideIndex = 1;
        showSlides(slideIndex);

        // Next/previous controls
        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        // Thumbnail image controls
        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            let i;
            let slides = document.getElementsByClassName("mySlides");
            let dots = document.getElementsByClassName("demo");
            let captionText = document.getElementById("caption");
            if (n > slides.length) { slideIndex = 1 }
            if (n < 1) { slideIndex = slides.length }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
            captionText.innerHTML = dots[slideIndex - 1].alt;
        }
    </script>




    <script>
        function selectProfilePicture() {
            document.getElementById('profilePictureInput').click();
        }

        function displayImage(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    // Display the image (optional)
                    var img = document.createElement('img');
                    img.src = e.target.result;
                    img.style.width = '100px'; // Adjust the size as needed
                    document.body.appendChild(img);
                };

                reader.readAsDataURL(input.files[0]);

                // Show the "Upload" button after selecting an image
                document.querySelector('.btn-light.waves-effect[style="display:none"]').style.display = 'inline-block';
            }
        }
    </script>



    <script>
        function selectProfilePicture() {
            document.getElementById('profilePictureInput').click();
        }

        function submitForm() {
            document.getElementById('profilePictureForm').submit();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', ['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Keen Rabbits\starluxe8.4\front-new (2)\front-new\idea (SLF)\resources\views/pages/dashboards/tourist-profile.blade.php ENDPATH**/ ?>
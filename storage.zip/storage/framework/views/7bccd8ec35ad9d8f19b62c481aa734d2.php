<?php $__env->startSection('content'); ?>






<!-- Casinos  -->

 <!-- common banner -->
        <section class="common-banner">
            <div class="common-banner-image" style="background: url(assets/images/banner/B7.png);"></div>

            <div class="common-banner-title">
                <a href="index.html">Home </a>
                <span>/ Gallery</span>
                <h3>Best Images And Video Gallery</h3>
            </div>
        </section>
<section class="popular-ture home3-popular-ture" style="font-family: 'Corbel Light'; background-color: white">
    

            <div class="blog" style="margin-top: -3px">
                <div class="container" style="margin-top: 10px; padding-top: 10px;">
                    <div class="row">

                        <?php $__currentLoopData = $fun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $casinos = \App\Models\Activity::whereNull('is_deleted')->where('id', $data->id)->where('sub_category_id',20)->get();
                                ?>
                            <?php $__currentLoopData = $casinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="blog-content">
                                        <div class="blog-image">
                                           <img src="<?php echo e(config('app.frontend_url') . "{$row->activity_image}"); ?>"
                                                                        alt="image" />
                                        </div>
                                        <div class="blog-info">
                                            <div class="footer-info">
                                                <a class="blog-title"><?php echo e($row->place_name); ?></a>
                                                <p class="descriptionParagraph"><?php echo e($row->description); ?></p>
           
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Casinos  -->

              
            

    <div class="container" style="margin-top: 10px; padding-top: 10px;">
         <h3 style="text-align: center; font-weight: bold; font-size: 28px; color: #213771; font-family: 'Roboto';  text-transform: uppercase; letter-spacing: 1px; border-bottom: 2px solid #213771;">Best Clubs And Video Gallery</h3>
        <div class="row">
           

            <div class="blog" style="margin-top: -20px">
                <div class="container" style="margin-top: 10px; padding-top: 10px;">
                    <div class="row">
                        <?php $__currentLoopData = $fun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $clubs=\App\Models\Activity::whereNull('is_deleted')->where('id', $data->id)->where('sub_category_id',21)->get();
      
                                ?>
                            <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="blog-content">
                                        <div class="blog-image">
                                            <img src="<?php echo e(env('FRONTEND_URL') . "{$row->activity_image}"); ?>" alt="image"/>


                                        </div>
                                        <div class="blog-info">
                                            <div class="footer-info">
                                                <a class="blog-title"><?php echo e($row->place_name); ?></a>
              
                                                <p class="club-description"><?php echo e($row->description); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        var descriptionParagraphs = document.querySelectorAll(".descriptionParagraph, .club-description");

        descriptionParagraphs.forEach(function (paragraph) {
            var maxLength = 80;
            var fullText = paragraph.textContent;

            if (fullText.length > maxLength) {
                var shortText = fullText.substring(0, maxLength) + '...';
                paragraph.innerHTML = shortText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
                paragraph.setAttribute("data-full-text", fullText);
            }
        });
    });

    function toggleReadMore(button) {
        var paragraph = button.parentNode;
        var fullText = paragraph.getAttribute("data-full-text");

        if (button.textContent === "Read More") {
            button.textContent = "Read Less";
            paragraph.innerHTML = fullText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read Less</button>';
        } else {
            button.textContent = "Read More";
            paragraph.innerHTML = fullText.substring(0, 100) + '... <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/pages/activities/fun.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>



 <!-- common banner -->
        <section class="common-banner">
            <div class="common-banner-image" style="background: url(assets/images/banner/B8.png);"></div>

            <div class="common-banner-title">
                <a href="index.html">Home </a>
                <span>/ Gallery</span>
                <h3>Best Images And Video Gallery</h3>
            </div>
        </section>
        <!-- common banner -->

<!-- adventure  -->
<div class="blog" style="margin-top: -20px">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $adventure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->parent_id == 1): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-content">
                            <div class="blog-image">
                                <img src="<?php echo e(config('app.frontend_url') .  "{$data->activity_image}"); ?>" alt="image"/>
                            </div>
                            <div class="blog-info">
                                <div class="footer-info">
                                    <a href="<?php echo e(route('activities-place-display', ['id' => $data->id])); ?>" class="blog-title"><?php echo e($data->category_name); ?></a>
                                    <p class="descriptionParagraph"><?php echo e($data->description); ?></p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var descriptionParagraphs = document.querySelectorAll(".descriptionParagraph");

        descriptionParagraphs.forEach(function (paragraph) {
            var maxLength = 110; // Change this value to your desired character limit
            var fullText = paragraph.textContent;

            if (fullText.length > maxLength) {
                var shortText = fullText.substring(0, maxLength) + '...';
                paragraph.innerHTML = shortText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
                paragraph.setAttribute("data-full-text", fullText);
            }
        });
    });

    function toggleReadMore(button) {
        var paragraph = button.parentNode;
        var fullText = paragraph.getAttribute("data-full-text");

        if (button.textContent === "Read More") {
            button.textContent = "Read Less";
            paragraph.innerHTML = fullText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read Less</button>';
        } else {
            button.textContent = "Read More";
            paragraph.innerHTML = fullText.substring(0, 100) + '... <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
        }
    }
</script>


<!-- adventure end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/pages/activities/adventure.blade.php ENDPATH**/ ?>
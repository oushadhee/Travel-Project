<?php $__env->startSection('content'); ?>
 <!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/country" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Sri Lanka Tour
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/alltours?id=2" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Tour Packages
                                </a>
                                 <span style="color: #999;">/</span>
                                <a href="/wildlife-tours" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Wildlife Tours
                                </a>
                                
                                   </a>
                                <?php $__currentLoopData = $tittle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="color: #999;">/</span>
                                <span style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                   <?php echo e($dat); ?>

                                </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                               Step into the Heart of Heritage with Our Cultural Tours
                            </h3>
            
        </div>
           <style>
                /* Hover effects */
                a:hover {
                    color: #ff6f00 !important;
                }
         </style>
      
        <!-- common banner -->

<div class="col-lg-12">
    <div class="align-title">
         <br><br>
        <?php $__currentLoopData = $tittle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 style="color: #FE7524; font-family: 'Source Serif Pro', serif;"><?php echo e($dat); ?> </h3>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
</div>

<div class="blog" style="margin-top: 10px; padding-top: 10px;">
    <div class="container">
         
        <div class="row">
            <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6">
    <div class="blog-content">
        <a href="<?php echo e(route('tour-package-details-display', ['id' => $data->id])); ?>" style="text-decoration: none; color: inherit;">
            <div class="blog-image">
                <img src="<?php echo e(Storage::url($data->tour_image)); ?>" alt="image">
            </div>
            <div class="blog-info">
                <div class="footer-info">
                    <span class="blog-title"><?php echo e($data->tour_name); ?></span>
                    <p><?php echo e($data->description); ?></p>
                </div>
            </div>
        </a>
    </div>
</div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<!-- cultural-tours end -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Keen Rabbits\starluxe8.4\front-new (2)\front-new\idea (SLF)\resources\views/pages/tours/tour-packages/wildlife-tours-display.blade.php ENDPATH**/ ?>
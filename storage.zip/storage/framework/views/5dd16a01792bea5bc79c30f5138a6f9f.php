<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add this style block in the <head> for fixed positioning -->
    <style>
        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            background-color: #ffffff; /* Adjust background as needed to match your design */
        }
        body {
            padding-top: 10px; /* Adjust this value based on your header's height to avoid content overlap */
        }
    </style>
    <!-- main header -->
    <header class="main-header style-one ">
        <div class="header-lower">
            <div class="header_bottom p_relative">
                <div class="auto_container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/images/stlx1.png')); ?>" alt="logo"></a></figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar" style="background-color: #000000;"></i>
                                <i class="icon-bar" style="background-color: #000000;"></i>
                                <i class="icon-bar" style="background-color: #000000;"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                        <li class="dropdown <?php if(request()->routeIs('country_tours')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('all-country')); ?>">Tours</a>
                                            <ul>
                                                <?php
                                                    use App\Models\Country;
                                                    $countries = Country::whereHas('tourCategories')->get();
                                                ?>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('allsubtours', ['id' => $country->id])); ?>">
                                                            <?php echo e($country->country_name); ?>

                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        
                                        <li class="<?php if(request()->routeIs('excursions')): ?> active <?php endif; ?>">
                                            <a href="<?php echo e(route('excursions')); ?>">Excursions</a>
                                        </li>
                                        <li class="dropdown <?php if(request()->routeIs('unexplored') || request()->routeIs('adventure') || request()->routeIs('fun') || request()->routeIs('park') || request()->routeIs('special-events')): ?> active <?php endif; ?>">
                                            <a href="#">Explore</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(route('unexplored')); ?>">Unexplored</a></li>
                                                <li><a href="<?php echo e(route('adventure')); ?>">Adventure</a></li>
                                                <li><a href="<?php echo e(route('fun')); ?>">Funs</a></li>
                                                <li><a href="<?php echo e(route('park')); ?>">Parks</a></li>
                                                <li><a href="<?php echo e(route('special-events')); ?>">Events</a></li>
                                            </ul>
                                        </li>
                                        <li class="dropdown <?php if(request()->routeIs('gallery') || request()->routeIs('videos')): ?> active <?php endif; ?>">
                                            <a href="#">Gallery</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(route('gallery')); ?>">Image Gallery</a></li>
                                                <li><a href="<?php echo e(route('videos')); ?>">Videos Gallery</a></li>
                                            </ul>
                                        </li>
                                        <li class="<?php if(request()->routeIs('about')): ?> active <?php endif; ?>"><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                        <li class="<?php if(request()->routeIs('contactus')): ?> active <?php endif; ?>"><a href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
                                        <li class="dropdown navbar">
                                            <?php if(auth()->guard()->guest()): ?>
                                                <a href="#">Join</a>
                                                <ul class="sub-menu">
                                                    <li>
                                                        <a href="<?php echo e(route('login')); ?>">Login</a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('book-now-form')); ?>">Book Now</a>
                                                    </li>
                                                </ul>
                                            <?php else: ?>
                                                <a href="#" class="dropdown-toggle">
                                                    <span style="text-transform: capitalize; color: #166EF3; font-size: 12px;">
                                                        <?php if(Auth::check() && Auth::user()->user_type == 'guide'): ?>
                                                            <img src="<?php echo e(asset(Auth::user()->guidedetails->guides_photos_normal)); ?>" alt="Guide Image" style="width: 30px; height: 30px; border-radius: 50%; object-fit: cover;">
                                                        <?php elseif(Auth::check() && Auth::user()->user_type == 'tourer'): ?>
                                                            <img src="<?php echo e(asset(Auth::user()->profile_pic)); ?>" alt="Tourer Image" style="width: 30px; height: 30px; border-radius: 50%; object-fit: cover;">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('assets/images/profile/user-avatar.svg.png')); ?>" alt="Default Image" style="width: 30px; height: 30px; border-radius: 50%; object-fit: cover;">
                                                        <?php endif; ?>
                                                    </span>
                                                </a>
                                                <ul class="sub-menu">
                                                    <li>
                                                        <a href="<?php echo e(Auth::check() && Auth::user()->user_type == 'guide' ? route('guide-profile') : route('tourist-profile')); ?>">My Dashboard</a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                            <span class="glyphicon glyphicon-log-out"></span> Logout
                                                        </a>
                                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    </li>
                                                </ul>
                                            <?php endif; ?>
                                        </li>
                                        <?php if(Auth::check() && Auth::user()->user_type == 'tourer'): ?>
                                            <?php
                                                $notifications = \App\Models\QuotationDetails::whereIn('booked_id', function ($query) {
                                                    $query->select('id')->from('book_nows')->where('user_id', Auth::user()->id);
                                                })->where('status', 'Submitted to Tourist')->where('status2', 'unread')->orderBy('created_at', 'DESC')->get();
                                                $notificationCount = $notifications->count();
                                            ?>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link" data-toggle="dropdown" href="#">
                                                    <i class="far fa-bell"></i>
                                                    <span id="notificationCount" class="badge navbar-badge top-1 start-100 translate-middle" style="background-color: white; color: blue; transform: translate(-50%, -50%);">
                                                        <?php echo e($notificationCount); ?>

                                                    </span>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" style="width: auto; font-size: 15px;">
                                                    <span class="dropdown-item dropdown-header">Quotation Notifications</span>
                                                    <div class="dropdown-divider"></div>
                                                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('quotation_notification')); ?>" class="dropdown-item notification-item" data-id="<?php echo e($notification->id); ?>" onclick="markAsRead(<?php echo e($notification->id); ?>)">
                                                            <?php echo e('View Tour ' . ($notificationCount - $key)); ?> - <span class="badge <?php echo e($notification->status2 == 'unread' ? 'badge-danger' : 'badge-secondary'); ?>"><?php echo e(ucfirst($notification->status2)); ?></span>
                                                        </a>
                                                        <?php if(!$loop->last): ?>
                                                            <div class="dropdown-divider"></div>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="dropdown-divider"></div>
                                                    <a href="<?php echo e(route('quotation_notification')); ?>" class="dropdown-item dropdown-footer">View All</a>
                                                </div>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </nav>
                            <div class="header__right">
                                <div class="header-right-search">
                                    <div class="header-scarce">
                                        <button class="btn primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop" aria-controls="offcanvasTop">
                                            <i class="flaticon-search"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="header-right-option">
                                    <select>
                                        <option value="">USD</option>
                                        <option value="">URO</option>
                                        <option value="">BDT</option>
                                    </select>
                                </div>
                                <div class="header-right-option">
                                    <select>
                                        <option value="">ENG</option>
                                        <option value="">SPANISH</option>
                                        <option value="">CHINISH</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Notification JavaScript -->
    <script>
        function markAsRead(notificationId) {
            fetch('/mark-notification-as-read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ notification_id: notificationId })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateNotificationCount();
                        const item = document.querySelector(`.notification-item[data-id="${notificationId}"] .badge`);
                        if (item) {
                            item.classList.replace('badge-danger', 'badge-secondary');
                            item.innerText = 'Read';
                        }
                    } else {
                        console.error('Failed to mark notification as read:', data.message);
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        function updateNotificationCount() {
            fetch('/notification-count')
                .then(response => response.json())
                .then(data => {
                    const countElement = document.getElementById('notificationCount');
                    countElement.innerText = data.count;
                    countElement.style.display = data.count === 0 ? 'none' : 'inline-block';
                })
                .catch(error => console.error('Error fetching notification count:', error));
        }

        document.addEventListener('DOMContentLoaded', function () {
            updateNotificationCount();

            // Mobile Menu Toggle Logic
            const toggler = document.querySelector('.mobile-nav-toggler');
            const mobileMenu = document.querySelector('.mobile-menu');
            const closeBtn = document.querySelector('.mobile-menu .close-btn');
            const backdrop = document.querySelector('.mobile-menu .menu-backdrop');

            if (toggler && mobileMenu) {
                toggler.addEventListener('click', function () {
                    mobileMenu.classList.toggle('active');
                });
            }

            if (closeBtn && mobileMenu) {
                closeBtn.addEventListener('click', function () {
                    mobileMenu.classList.remove('active');
                });
            }

            if (backdrop && mobileMenu) {
                backdrop.addEventListener('click', function () {
                    mobileMenu.classList.remove('active');
                });
            }
        });
    </script>

    <!-- Mobile Menu -->
    <div class="mobile-menu" style="color:#213771">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><i class="fas fa-times"></i></div>
        <nav class="menu-box">
            <div class="nav-logo">
                <a href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('assets/images/stlx.png')); ?>" alt="logo" style="max-height: 60px;">
                </a>
            </div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            <div class="contact-info">
                <h4>Contact Info</h4>
                <ul>
                    <li>
                        <p>Starluxe Travels</p>
                        <p>3rd, Ward City Shopping Mall,</p>
                        <p>120, Marybiso Rd,</p>
                        <p>Gampaha 11000</p>
                    </li>
                </ul>
            </div>
            <div class="social-links">
                <div class="banner-media">
                    <ul>
                        <li><a href="https://www.instagram.com/jump_on_travels/"><i class="fa-brands fa-instagram"></i></a></li>
                        <li><a href="https://web.facebook.com/profile.php?id=100095217601600"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="viber://add?number=94707009666"><i class="fab fa-viber"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <!-- End Mobile Menu -->
</html><?php /**PATH D:\Keen Rabbits\starluxe8.4\front-new (2)\front-new\idea (SLF)\resources\views/components/navbar2.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

 <!-- common banner -->
        <section class="common-banner">
            <div class="common-banner-image" style="background: url(assets/images/banner/B14.png);"></div>

            <div class="common-banner-title">
                <a href="index.html">Home </a>
                <span>/ tour-package</span>
                <h3>Get The Best Plans For Your’s</h3>
            </div>
        </section>
        <!-- common banner -->



<!-- all-tours  -->

<section>
<div class="blog" >
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $all_tours_display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($data->parent_id == 0): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-content">
                            <div class="blog-image">
                                
                             <img src="<?php echo e(config('app.frontend_url') ."{$data->tour_image}"); ?>" alt="image"> 
                            </div>
                            <div class="blog-info">
                                <div class="footer-info">
                                    <a href="<?php echo e(route('tour_categories', ['id' => $data->id])); ?>"  class="blog-title-container">
                                        <span class="blog-title" style="color: #f67a59"><?php echo e($data->category_name); ?></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</section>
<!-- all-tours end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/pages/tours/all-tours.blade.php ENDPATH**/ ?>
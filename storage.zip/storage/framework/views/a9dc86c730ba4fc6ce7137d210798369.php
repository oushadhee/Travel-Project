<?php $__env->startSection('content'); ?>



<section class="loginform" style="background-color: #333; padding: 20px; display: flex; justify-content: center; align-items: center; height: 100vh; padding-top: 180px; background-image: url('assets/images/banner/login_bg.jpg'); background-size: cover; background-position: center;">
    <div class="loginform-box" style="background-color: rgba(255, 255, 255, 0.8); border-radius: 10px; padding: 30px; width: 400px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);margin-top:-50px;">
        <?php if(session('error')): ?>
            <div class="alert alert-danger" style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px;">
                <button type="button" class="close" data-dismiss="alert" style="background: none; border: none; color: inherit;">&times;</button>
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block" style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px;">
                <button type="button" class="close" data-dismiss="alert" style="background: none; border: none; color: inherit;">&times;</button>
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php endif; ?>

        <h1 style="color: #f67a59; font-weight: bold; text-align: center;font-family:'roboto';">Starluxe Travels</h1><br>

        <form action="<?php echo e(route('loginCheck')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="login-form-group" style="margin-bottom: 20px;">
                <label for="email" style="font-size: 14px; font-weight: bold;">EMAIL:</label>
                <input type="email" id="email" name="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required style="width: 100%; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc;">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert" style="color: #e74c3c; font-size: 12px;">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="login-form-group" style="margin-bottom: 20px;">
                <label for="password" style="font-size: 14px; font-weight: bold;">PASSWORD:</label>
                <input type="password" id="password" name="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required style="width: 100%; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc;">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert" style="color: #e74c3c; font-size: 12px;">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="login-form-group" style="text-align: center;">
                <button type="submit" style="background-color: #fe7524; color: white; font-weight: bold; padding: 10px 20px; border: none; border-radius: 5px;">LOGIN</button>
            </div>

            <div style="text-align: center; margin-top: 10px;">
                <a href="<?php echo e(route('forgot.password')); ?>" style="color: #fe7524; text-decoration: none;">Forgot Password?</a>
            </div>

            <p class="have_account" style="text-align: center; font-size: 14px; color: #333; margin-top: 20px;">Don't have an account? <br>
                <a href="<?php echo e(route('register')); ?>" class="sign-up-link" style="color: #fe7524; font-weight: bold;">Sign Up</a> as a Tourist
            </p>
        </form>

        <!-- <div class="footer__logo" style="text-align: center; margin-top: 30px;">
            <a href="/"><figure class="logo_B"><img src="<?php echo e(asset('assets/images/logo/LOGO-JOT - Footer.png')); ?>" alt="Logo" style="width: 100px;"></figure></a>
        </div> -->
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', ['main_page' => 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/auth/login.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>


<!-- cultural-tour-package  -->
<section>
    <div class="blog" style="margin-top: 10px; padding-top: 10px;">
        <div class="container">
              <h3 style="text-align: center;">Your perfect getaway starts here </h3> <br>
            <div class="row">
                <?php if(count($cultural_tours) > 0): ?>
                    <?php $__currentLoopData = $cultural_tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="blog-content">
                                <div class="blog-image">
                                    

                                    <img src="<?php echo e(config('app.frontend_url') . "{$data->tour_image}"); ?>" alt="image"/>
                                </div>
                                <div class="blog-info">
                                    <div class="footer-info">
                                        <a href="<?php echo e(route('cultural-tours-display', ['id' => $data->id])); ?>" class="blog-title"><?php echo e($data->category_name); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>

                    <div class="blog_msg col-12" style="position: relative; text-align: center; padding: 10px;">

                       


                        <p style="color:#213771; font-size: 40px; font-weight: bolder; font-family: 'Book Antiqua';">....Coming Soon....</p>
                        <br>
                        <p style="color:#213771; font-size: 20px;">We are working on this page.</p>
                        <p style="color:#213771; font-size: 18px;">Stay tuned for some exciting updates.</p>
                       
                    </div>
                <?php endif; ?>


            </div>
        </div>
    </div>
</section>
<!-- cultural-tour-package end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/pages/tours/cultural-tours.blade.php ENDPATH**/ ?>
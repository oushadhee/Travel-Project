<?php $__env->startSection('content'); ?>

<!-- common banner -->
      <div style="background: #F7F8FA; width: 100%; max-width: auto; height: 120px; margin: 0 auto; padding: 25px; text-align: center; font-family: 'Segoe UI', Arial, sans-serif; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                
                <div style="margin-bottom: 10px; font-size: 16px;">
                                <a href="./" style="color: #094174; font-weight: 600; text-decoration: none; margin-right: 8px; transition: color 0.3s;">
                                    Home
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/country" style="color: #666; text-decoration: none; margin: 0 8px; transition: color 0.3s;">
                                   Sri Lanka Tour
                                </a>
                                <span style="color: #999;">/</span>
                                <a href="/alltours?id=2" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Tour Packages
                                </a>
                                 <span style="color: #999;">/</span>
                                <a href="/business-tours" style="color: #666; text-decoration: none; margin-left: 8px; transition: color 0.3s;">
                                    Business Tour
                                </a>
                                
                            </div>
                            <h3 style="color: #094174; font-size: 24px; font-weight: 700; margin: 20px 0 0; text-transform: uppercase;">
                               Seamless Business Travel Solutions for Global Professionals
                            </h3>
            
        </div>
           <style>
                /* Hover effects */
                a:hover {
                    color: #ff6f00 !important;
                }
         </style>
      
        <!-- common banner -->


<!-- Business Tours Section -->
<section class="popular-ture home3-popular-ture" style="background-color: white; margin-top: 10px; padding-top: 10px;">
    <div class="container">
       

        <div class="row">
            <div class="col-12" style="position: relative; background-color: rgba(255, 255, 255, 0.8); background-image: url('<?php echo e(asset('path/to/your/image.jpg')); ?>'); background-size: cover; background-position: center; text-align: center; padding: 60px 20px; border-radius: 10px;">
                
                <!-- Top-left Icon -->
                <div style="position: absolute; top: 10px; left: 120px; width: 200px; height: 150px;">
                    <img src="<?php echo e(asset('assets/images/icons/icon01.png')); ?>" alt="Icon 1" style="width: 100%; height: auto;">
                </div>

                <!-- Bottom-center Icon -->
                <div style="position: absolute; bottom: -75px; left: 50%; transform: translateX(-50%); width: 150px; height: 150px;">
                    <img src="<?php echo e(asset('assets/images/icons/icon02.png')); ?>" alt="Icon 2" style="width: 100%; height: auto;">
                </div>

                <!-- Bottom-right Icon -->
                <div style="position: absolute; bottom: -20px; right: 50px; width: 200px; height: 180px;">
                    <img src="<?php echo e(asset('assets/images/icons/icon03.png')); ?>" alt="Icon 3" style="width: 100%; height: auto;">
                </div>

                <!-- Main Text -->
                <p style="color: #213771; font-size: 40px; font-weight: bolder; font-family: 'Book Antiqua'; margin-top: 40px;">
                    ....Under Construction....
                </p>
                <p style="color: #213771; font-size: 20px;">We are working on this page.</p>
                <p style="color: #213771; font-size: 18px;">Stay tuned for some exciting updates.</p>
            </div>
        </div>
    </div>
</section>

<!-- Business Tours Section End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', ['main_page' => 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Keen Rabbits\starluxe8.4\front-new (2)\front-new\idea (SLF)\resources\views/pages/tours/business-tours.blade.php ENDPATH**/ ?>
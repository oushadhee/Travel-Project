<?php $__env->startSection('content'); ?>



  <!-- common banner -->
        <section class="common-banner">
            <div class="common-banner-image" style="background: url(assets/images/banner/B3.png);"></div>

            <div class="common-banner-title">
                <a href="index.html">Home </a>
                <span>/ Gallery</span>
                <h3>Best Images And Video Gallery</h3>
            </div>
        </section>
        <!-- common banner -->

<section class="package-details"style="margin-bottom: -15px;">
    <div class="container">
        <div class="row">
             <?php $__currentLoopData = $unexplored; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="blog-content">
                    <div class="blog-image">
                      <img src="<?php echo e(config('app.frontend_url') . "{$data->image}"); ?>" alt="image" />
                    </div>
                    <div class="blog-info">
                        <div class="footer-info">

                            <a class="blog-title" style="color: #f67a59; font-weight: bolder; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: inline-block; max-width: 100%;"><?php echo e($data->unexplored_name); ?></a>
                            <p class="descriptionParagraph" style="justify-content: center"><?php echo e($data->description); ?></p>
                            
                        </div>
                    </div>
                </div>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var descriptionParagraphs = document.querySelectorAll(".descriptionParagraph");

        descriptionParagraphs.forEach(function (paragraph) {
            var maxLength = 100; // Change this value to your desired character limit
            var fullText = paragraph.textContent;

            if (fullText.length > maxLength) {
                var shortText = fullText.substring(0, maxLength) + '...';
                paragraph.innerHTML = shortText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
                paragraph.setAttribute("data-full-text", fullText);
            }
        });
    });

    function toggleReadMore(button) {
        var paragraph = button.parentNode;
        var fullText = paragraph.getAttribute("data-full-text");

        if (button.textContent === "Read More") {
            button.textContent = "Read Less";
            paragraph.innerHTML = fullText + ' <button class="readMoreButton" onclick="toggleReadMore(this)">Read Less</button>';
        } else {
            button.textContent = "Read More";
            paragraph.innerHTML = fullText.substring(0, 100) + '... <button class="readMoreButton" onclick="toggleReadMore(this)">Read More</button>';
        }
    }
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front',['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/pages/nav-bar-pages/unexplored.blade.php ENDPATH**/ ?>
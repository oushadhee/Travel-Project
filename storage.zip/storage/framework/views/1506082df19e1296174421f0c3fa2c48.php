<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    h2 {
        color: #333;
        text-align: center;
    }
    strong {
        color: #555;
    }
</style>

<body>
    <div class="container">
        <h2>Registered Tourist Information</h2>

        <p>
            Hi, <br>
            I am <?php echo e($tourist_data['f_name']); ?> <?php echo e($tourist_data['l_name']); ?>. <br><br>

            <strong>Name:</strong> <?php echo e($tourist_data['f_name']); ?> <?php echo e($tourist_data['l_name']); ?> <br>
            <strong>Email:</strong> <?php echo e($tourist_data['email']); ?> <br>
            <strong>Country From:</strong> <?php echo e($tourist_data['country']); ?> <br>
            <strong>Address:</strong> <?php echo e($tourist_data['address']); ?> <br>
            <strong>Mobile Number:</strong> (+<?php echo e($tourist_data['m_phone_1_country_code']); ?>) <?php echo e($tourist_data['m_phone_1']); ?> <br>

        </p>
    </div>
</body>
<?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/email/tourist_registered_email.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>


    <!-- registration form -->
    <section class="package-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="package-details-right-container">
                        <div class="destination-common-title">
                            <center>
                                <h4>Tourist's Registration</h4>
                            </center>
                        </div>

                        <div class="package-details-right-form">
                            
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                            

                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('register_tourist')); ?>">
                                <?php echo csrf_field(); ?>

                                <h5 style="color: black; font-weight: bolder; margin-bottom: 15px;">
                                    Personal Details<span style="color: red;">*</span>
                                </h5>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-user"></i></label>
                                        <input type="text" class="<?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="f_name"
                                            name="f_name" placeholder="First Name*" required>
                                        <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-user"></i></label>
                                        <input type="text" class="<?php $__errorArgs = ['l_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="l_name"
                                            name="l_name" placeholder="Last Name*" required>
                                        <?php $__errorArgs = ['l_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-regular fa-envelope"></i></label>
                                        <input type="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                                            name="email" placeholder="Your Email*" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-label" style="flex: 1; position: relative;">
                                        <label
                                            style="position: absolute; top: 50%; transform: translateY(-50%); color: #777; pointer-events: none;">
                                            <i class="fa-solid fa-globe"></i>
                                        </label>
                                        <input class="<?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="country" name="country"
                                            list="country-list" placeholder="Your Country*" required
                                            style="width: 100%; padding: 10px 10px 10px 35px; border-radius: 4px; font-size: 14px;">
                                        <datalist id="country-list">
                                            <?php $country_lists = App\Models\Country::all(); ?>
                                            <?php $__currentLoopData = $country_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->nicename); ?>"><?php echo e($country->nicename); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </datalist>
                                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback"
                                                style="display: block; color: red; font-size: 12px; margin-top: 5px;">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-row" style="display: flex; gap: 15px; align-items: flex-start;">
                                    <div class="form-label" style="flex: 1; display: flex;">
                                        <label style="margin-right: 10px; margin-top: 8px;"><i
                                                class="fa-solid fa-home"></i></label>
                                        <textarea id="address" name="address" placeholder="Your Address*"
                                            style="flex: 1; padding: 8px; border-radius: 4px; min-height: 80px;"
                                            required></textarea>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                               
                                      <div class="form-row" style="display: flex; gap: 15px; align-items: center;">
    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
        <label style="margin-right: 10px;"><i class="fa-solid fa-phone"></i></label>
        <div style="display: flex; flex: 1; gap: 8px; padding-bottom: 8px; align-items: center;">
            <!-- Country Code Select (reduced width) -->
            <select id="m_phone_1_country_code" name="m_phone_1_country_code"
                style="width: 100px; padding: 8px; border: 1px solid #ced4da; border-radius: 2px; font-size: 14px; height: 38px;">
                <option value="+7">+7</option>
                <option value="+20">+20</option>
                <option value="+27">+27</option>
                <option value="+30">+30</option>
                <option value="+31">+31</option>
                <option value="+32">+32</option>
                <option value="+33">+33</option>
                <option value="+34">+34</option>
                <option value="+36">+36</option>
                <option value="+39">+39</option>
                <option value="+40">+40</option>
                <option value="+41">+41</option>
                <option value="+43">+43</option>
                <option value="+44">+44</option>
                <option value="+45">+45</option>
                <option value="+46">+46</option>
                <option value="+47">+47</option>
                <option value="+48">+48</option>
                <option value="+49">+49</option>
                <option value="+51">+51</option>
                <option value="+52">+52</option>
                <option value="+53">+53</option>
                <option value="+54">+54</option>
                <option value="+55">+55</option>
                <option value="+56">+56</option>
                <option value="+57">+57</option>
                <option value="+58">+58</option>
                <option value="+60">+60</option>
                <option value="+61">+61</option>
                <option value="+62">+62</option>
                <option value="+63">+63</option>
                <option value="+64">+64</option>
                <option value="+65">+65</option>
                <option value="+66">+66</option>
                <option value="+81">+81</option>
                <option value="+82">+82</option>
                <option value="+84">+84</option>
                <option value="+86">+86</option>
                <option value="+90">+90</option>
                <option value="+91">+91</option>
                <option value="+92">+92</option>
                <option value="+93">+93</option>
                <option value="+94" selected>+94</option>
            </select>
            
            <!-- Phone Number Input -->
            <input type="number" class="<?php $__errorArgs = ['m_phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="m_phone_1" name="m_phone_1" placeholder="Phone number*"
                style="flex: 1; border: none; background: transparent; padding: 8px; height: 38px;"
                required>
        </div>
        <?php $__errorArgs = ['m_phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-label" style="flex: 1; display: flex; align-items: center;">
        <div style="flex: 1; padding-bottom: 8px;">
            <textarea id="address" name="address" placeholder="Your Address*"
                style="width: 100%; border: none; background: transparent; padding: 8px 0; resize: none; min-height: 38px;"
                required></textarea>
        </div>
    </div>
</div>
                               


                                <div class="form-row" style="display: flex; gap: 15px;">
                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-lock"></i></label>
                                        <input type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password"
                                            name="password" placeholder="Password*" required autocomplete="new-password">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-label" style="flex: 1;">
                                        <label><i class="fa-solid fa-lock"></i></label>
                                        <input type="password" id="password_confirmation" name="password_confirmation"
                                            placeholder="Confirm Password*" required autocomplete="new-password">
                                    </div>
                                </div>

                                <div id="passwordError" class="invalid-feedback"
                                    style="display: none; color: red; margin-bottom: 15px;">
                                    <strong>Confirmed password does not match.</strong>
                                </div>

                                <button type="submit" class="submit-btn">Register</button>

                                <p
                                    style="text-align: center; margin-top: 15px;font-family:'Times New Roman', Times, serif;">
                                    Already have an account? <a href="<?php echo e(route('login')); ?>">Sign In</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>

    <script type="text/javascript">
        function custom_template(obj) {
            var data = $(obj.element).data();
            var text = $(obj.element).text();
            if (data && data['img_src']) {
                img_src = data['img_src'];
                template = $("<div><img src=\"" + img_src + "\" style=\"width:25%;height:20px;\"/>" + text + "</div>");
                return template;
            }
        }
        var options = {
            'templateSelection': custom_template,
            'templateResult': custom_template,
        }
        $('#id_select2_example').select2(options);
        $('.select2-container--default .select2-selection--single').css({ 'height': '25px' });

    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            function checkPasswords() {
                var password = $('#password').val();
                var passwordConfirmation = $('#password_confirmation').val();

                if (passwordConfirmation && password !== passwordConfirmation) {
                    $('#passwordError').show();
                    return false;
                } else {
                    $('#passwordError').hide();
                    return true;
                }
            }

            $('#password_confirmation').on('keyup', function () {
                checkPasswords();
            });

            $('#registerButton').on('click', function (event) {
                if (!checkPasswords()) {
                    event.preventDefault();
                }
            });
        });
    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', ['main_page' > 'yes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oushadhee\Downloads\front-new (2)\front-new\idea (SLF)\resources\views/auth/register.blade.php ENDPATH**/ ?>